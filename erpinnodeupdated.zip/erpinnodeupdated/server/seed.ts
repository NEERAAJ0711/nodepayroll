import { seedPermissions } from './seed-permissions';
import { seedDemoData } from './seed-demo-data';
import { seedJobs } from './seed-jobs';
import { seedStatesAndDistricts } from './seed-states-districts';

async function main() {
  try {
    console.log('Starting database seeding...');
    
    await seedStatesAndDistricts();
    await seedPermissions();
    await seedDemoData();
    await seedJobs();
    
    console.log('Database seeding completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error during seeding:', error);
    process.exit(1);
  }
}

main();