import type { Express } from "express";
import { createServer, type Server } from "http";
import "./types"; // Import custom type definitions
import { storage } from "./storage";
import { loginSchema, insertEmployeeSchema, insertJobSchema, insertDepartmentSchema, insertEmployeeSalaryStructureSchema, leaveRequests, advanceRequests, clients, complianceSetups, compliancesData, employeeAssignments } from "@shared/schema";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import ExcelJS from "exceljs";
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { createConnection, Socket } from 'net';
import { filterAllowedFields, containsAdminOnlyFields, EMPLOYEE_SELF_EDITABLE_FIELDS, ADMIN_ONLY_FIELDS } from "./policies/employeeProfile";
import { requireRole, requireSelfOrRole, canEditWeeklyOff, canApproveChanges } from "./middleware/auth";

// Helper function to normalize profile fields and compute age server-side
function normalizeProfileFields(data: any): any {
  const normalized = { ...data };
  
  // Handle fullName to firstName/lastName conversion
  if (normalized.fullName && !normalized.firstName && !normalized.lastName) {
    const nameParts = normalized.fullName.trim().split(/\s+/);
    normalized.firstName = nameParts[0] || '';
    normalized.lastName = nameParts.slice(1).join(' ') || '';
    delete normalized.fullName;
  }
  
  // Remove client-sent age - we compute it server-side for integrity
  delete normalized.age;
  
  // Compute age from dateOfBirth if provided
  if (normalized.dateOfBirth) {
    const birthDate = new Date(normalized.dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    normalized.age = age;
  }
  
  // Normalize Aadhaar field names (support both legacy and new)
  if (normalized.aadharNumber) {
    normalized.aadhaarNo = normalized.aadharNumber;
    delete normalized.aadharNumber;
  }
  if (normalized.aadhaarNo) {
    // Ensure Aadhaar is digits only
    normalized.aadhaarNo = normalized.aadhaarNo.replace(/\D/g, '');
  }
  
  // Normalize PAN field names (support both legacy and new)
  if (normalized.panNumber) {
    normalized.panNo = normalized.panNumber;
    delete normalized.panNumber;
  }
  if (normalized.panNo) {
    // Ensure PAN is uppercase
    normalized.panNo = normalized.panNo.toUpperCase();
  }
  
  // Normalize father name field
  if (normalized.fatherName) {
    normalized.fatherHusbandName = normalized.fatherName;
    delete normalized.fatherName;
  }
  
  return normalized;
}

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (process.env.NODE_ENV === 'production') {
    throw new Error('JWT_SECRET environment variable is required for production security');
  }
  // Development fallback - NOT FOR PRODUCTION
  console.warn('⚠️  WARNING: Using development JWT secret. Set JWT_SECRET environment variable for production!');
}
const JWT_SECRET_VALUE = JWT_SECRET || 'dev-secret-key-not-for-production';

// Middleware to verify JWT token and extract user
async function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  // Only log for non-routine requests to reduce noise
  if (req.path !== '/api/auth/me') {
    console.log('Auth check for:', req.method, req.path);
    console.log('Auth header present:', !!authHeader);
    console.log('Token extracted:', !!token);
  }

  if (!token) {
    console.log('No token provided, returning 401');
    return res.status(401).json({ message: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET_VALUE) as any;
    
    const user = await storage.getUser(decoded.userId);
    
    if (!user) {
      console.log('User not found for userId:', decoded.userId);
      return res.status(401).json({ message: 'User not found' });
    }
    
    if (!user.isActive) {
      console.log('User inactive:', user.email);
      return res.status(401).json({ message: 'User account is inactive' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    console.log('Token verification failed:', error.message);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }
}

// Middleware to check company access
function checkCompanyAccess(req: any, res: any, next: any) {
  const rawCompanyId = req.params.companyId || req.body.companyId || req.query.companyId;
  const companyId = Number(rawCompanyId);
  
  // If no company ID is present or it's not a valid number, skip company access check
  // This allows user-scoped endpoints like /api/job-applications/my to work for job seekers
  if (!rawCompanyId || Number.isNaN(companyId)) {
    return next();
  }
  
  if (req.user.role === 'system_admin') {
    return next(); // System admin can access all companies
  }
  
  if (req.user.companyId !== companyId) {
    return res.status(403).json({ message: 'Access denied to this company' });
  }
  
  next();
}

// Machine sync helper function
async function syncMachineData(machine: any, options: { startDate?: string; endDate?: string }) {
  try {
    console.log(`Syncing data from machine ${machine.serialNumber} at ${machine.ipAddress}:${machine.port}`);
    
    const attendanceData = await connectToMachine(machine);
    
    if (attendanceData.length === 0) {
      return {
        success: true,
        message: 'No new attendance data found',
        recordsImported: 0
      };
    }

    // Import the attendance data
    let importedCount = 0;
    for (const record of attendanceData) {
      try {
        // Check if attendance record already exists
        const existingAttendance = await storage.getAttendanceByEmployeeAndDate(record.employeeId, record.date);
        
        if (!existingAttendance) {
          // Create new attendance record from biometric machine data
          await storage.createAttendance({
            employeeId: record.employeeId,
            companyId: machine.companyId,
            date: record.date,
            checkIn: record.checkIn,
            checkOut: record.checkOut,
            isPresent: true,
            status: calculateAttendanceStatus(record),
            hoursWorked: calculateHoursWorked(record.checkIn, record.checkOut),
            faceVerified: record.faceVerified || false,
            verificationType: 'biometric', // Set proper verification type for machine data
            deviceInfo: `${machine.serialNumber} (${machine.ipAddress}:${machine.port})`,
            workLocation: machine.location // Fixed field name to match database schema
          });
          importedCount++;
          console.log(`📋 Created attendance record for employee ${record.employeeId} on ${record.date} from machine ${machine.serialNumber}`);
        }
      } catch (error) {
        console.error(`Error importing record for employee ${record.employeeId}:`, error);
      }
    }

    return {
      success: true,
      message: `Successfully imported ${importedCount} attendance records`,
      recordsImported: importedCount
    };
  } catch (error) {
    console.error(`Failed to sync machine ${machine.serialNumber}:`, error);
    return {
      success: false,
      message: error.message || 'Failed to connect to machine'
    };
  }
}

// Connect to biometric machine and pull attendance data
async function connectToMachine(machine: any): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const timeout = 10000; // 10 second timeout
    const client = new Socket();
    let responseData = '';

    // Set connection timeout
    const timer = setTimeout(() => {
      client.destroy();
      reject(new Error(`Connection timeout after ${timeout}ms`));
    }, timeout);

    client.connect(machine.port || 4370, machine.ipAddress, () => {
      console.log(`Connected to machine ${machine.serialNumber} at ${machine.ipAddress}:${machine.port}`);
      
      // Send command to request attendance logs
      // This is a generic protocol - you may need to adjust for your specific machine
      const command = buildAttendanceLogCommand(machine);
      client.write(command);
    });

    client.on('data', (data) => {
      responseData += data.toString();
    });

    client.on('end', () => {
      clearTimeout(timer);
      try {
        const attendanceRecords = parseAttendanceData(responseData, machine);
        resolve(attendanceRecords);
      } catch (error) {
        reject(new Error('Failed to parse attendance data from machine'));
      }
    });

    client.on('error', (error) => {
      clearTimeout(timer);
      reject(new Error(`Machine connection error: ${error.message}`));
    });

    client.on('close', () => {
      clearTimeout(timer);
    });
  });
}

// Build command to request attendance logs from machine
function buildAttendanceLogCommand(machine: any): Buffer {
  // Generic attendance log request command
  // For ZKTeco and similar machines, this might be different
  // You may need to customize this based on your machine's protocol
  
  if (machine.model && machine.model.toLowerCase().includes('zkteco')) {
    // ZKTeco specific command structure
    return Buffer.from([0x50, 0x50, 0x82, 0x7D, 0x13, 0x00, 0x00, 0x00]);
  } else {
    // Generic TCP request for attendance data
    const command = JSON.stringify({
      command: 'get_attendance_logs',
      machine_id: machine.serialNumber,
      date_from: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Last 7 days
      date_to: new Date().toISOString().split('T')[0]
    });
    return Buffer.from(command + '\n');
  }
}

// Parse attendance data from machine response
function parseAttendanceData(data: string, machine: any): any[] {
  const attendanceRecords = [];
  
  try {
    // Try parsing as JSON first (for modern machines with HTTP/REST APIs)
    const jsonData = JSON.parse(data);
    if (Array.isArray(jsonData)) {
      return jsonData.map(record => ({
        employeeId: record.employee_id || record.empId || record.userId,
        date: formatDate(record.date || record.timestamp),
        checkIn: record.check_in || record.checkIn || formatTime(record.in_time),
        checkOut: record.check_out || record.checkOut || formatTime(record.out_time),
        faceVerified: record.face_verified || record.verified || false
      }));
    }
  } catch {
    // If not JSON, try parsing as fixed-width or delimited format
    const lines = data.split('\n').filter(line => line.trim());
    
    for (const line of lines) {
      // Parse common biometric machine log formats
      // Format: "EMP001,2025-01-25,09:00:00,18:00:00,1"
      const parts = line.trim().split(',');
      if (parts.length >= 3) {
        attendanceRecords.push({
          employeeId: parts[0],
          date: parts[1],
          checkIn: parts[2],
          checkOut: parts[3] || null,
          faceVerified: parts[4] === '1' || parts[4] === 'true'
        });
      }
    }
  }

  return attendanceRecords;
}

// Import employee list from biometric machine
async function importEmployeeListFromMachine(machine: any) {
  try {
    console.log(`Importing employee list from machine ${machine.serialNumber} at ${machine.ipAddress}:${machine.port}`);
    
    const employeeData = await connectToMachineForEmployees(machine);
    
    if (employeeData.length === 0) {
      return {
        success: true,
        message: 'No employees found on machine',
        employeesFound: 0,
        employeesImported: 0,
        employees: []
      };
    }

    let importedCount = 0;
    const employeeList = [];
    
    for (const employeeRecord of employeeData) {
      try {
        // Check if employee already exists in the system
        const existingEmployee = await storage.getEmployeeByCode(employeeRecord.employeeId);
        
        if (!existingEmployee) {
          // Create a placeholder employee record that can be completed later
          const newEmployee = {
            employeeId: employeeRecord.employeeId,
            fullName: employeeRecord.name || `Employee ${employeeRecord.employeeId}`,
            department: 'To Be Assigned',
            designation: 'To Be Assigned',
            phone: employeeRecord.phone || '',
            email: employeeRecord.email || `${employeeRecord.employeeId}@company.com`,
            companyId: machine.companyId,
            status: 'active',
            enrollmentId: employeeRecord.enrollmentId,
            fingerPrintId: employeeRecord.fingerprintId,
            faceTemplateId: employeeRecord.faceTemplateId
          };
          
          // Note: This would need proper employee creation logic
          console.log(`Would create employee: ${JSON.stringify(newEmployee)}`);
          importedCount++;
        }
        
        employeeList.push({
          employeeId: employeeRecord.employeeId,
          name: employeeRecord.name || 'Unknown',
          enrollmentId: employeeRecord.enrollmentId,
          fingerprintId: employeeRecord.fingerprintId,
          faceTemplateId: employeeRecord.faceTemplateId,
          status: existingEmployee ? 'exists' : 'new'
        });
      } catch (error) {
        console.error(`Error processing employee ${employeeRecord.employeeId}:`, error);
      }
    }

    return {
      success: true,
      message: `Found ${employeeData.length} employees on machine. ${importedCount} new employees identified.`,
      employeesFound: employeeData.length,
      employeesImported: importedCount,
      employees: employeeList
    };
  } catch (error) {
    console.error(`Failed to import employees from machine ${machine.serialNumber}:`, error);
    return {
      success: false,
      message: error.message || 'Failed to connect to machine for employee import'
    };
  }
}

// Connect to biometric machine to get employee list
async function connectToMachineForEmployees(machine: any): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const timeout = 15000; // 15 second timeout for employee list
    const client = new Socket();
    let responseData = '';

    const timer = setTimeout(() => {
      client.destroy();
      reject(new Error(`Connection timeout after ${timeout}ms`));
    }, timeout);

    client.connect(machine.port || 4370, machine.ipAddress, () => {
      console.log(`Connected to machine ${machine.serialNumber} for employee list`);
      
      // Send command to request employee list
      const command = buildEmployeeListCommand(machine);
      client.write(command);
    });

    client.on('data', (data) => {
      responseData += data.toString();
    });

    client.on('end', () => {
      clearTimeout(timer);
      try {
        const employees = parseEmployeeData(responseData, machine);
        resolve(employees);
      } catch (error) {
        reject(new Error('Failed to parse employee data from machine'));
      }
    });

    client.on('error', (error) => {
      clearTimeout(timer);
      reject(new Error(`Machine connection error: ${error.message}`));
    });

    client.on('close', () => {
      clearTimeout(timer);
    });
  });
}

// Build command to request employee list from machine
function buildEmployeeListCommand(machine: any): Buffer {
  if (machine.model && machine.model.toLowerCase().includes('miniac')) {
    // MiniAC specific command for employee list
    return Buffer.from([0x50, 0x50, 0x82, 0x7D, 0x88, 0x00, 0x00, 0x00]);
  } else if (machine.model && machine.model.toLowerCase().includes('zkteco')) {
    // ZKTeco specific command for user list
    return Buffer.from([0x50, 0x50, 0x82, 0x7D, 0x88, 0x00, 0x00, 0x00]);
  } else {
    // Generic request for employee/user list
    const command = JSON.stringify({
      command: 'get_user_list',
      machine_id: machine.serialNumber
    });
    return Buffer.from(command + '\n');
  }
}

// Parse employee data from machine response
function parseEmployeeData(data: string, machine: any): any[] {
  const employees = [];
  
  try {
    // Try parsing as JSON first
    const jsonData = JSON.parse(data);
    if (Array.isArray(jsonData)) {
      return jsonData.map(emp => ({
        employeeId: emp.employee_id || emp.user_id || emp.empId,
        name: emp.name || emp.user_name,
        enrollmentId: emp.enrollment_id || emp.enroll_id,
        fingerprintId: emp.fingerprint_id || emp.fp_id,
        faceTemplateId: emp.face_template_id || emp.face_id,
        phone: emp.phone,
        email: emp.email
      }));
    }
  } catch {
    // Parse fixed-width or delimited format
    const lines = data.split('\n').filter(line => line.trim());
    
    for (const line of lines) {
      // Common biometric machine user format
      // Format: "001,John Doe,12345,1,1,john@company.com"
      const parts = line.trim().split(',');
      if (parts.length >= 2) {
        employees.push({
          employeeId: parts[0],
          name: parts[1] || `Employee ${parts[0]}`,
          enrollmentId: parts[2] || null,
          fingerprintId: parts[3] || null,
          faceTemplateId: parts[4] || null,
          phone: parts[5] || null,
          email: parts[6] || null
        });
      }
    }
  }

  return employees;
}

// Check machine connection status with ZKTeco protocol
async function checkMachineConnection(machine: any) {
  return new Promise((resolve) => {
    const timeout = 8000; // 8 second timeout for ZKTeco handshake
    const client = new Socket();
    const startTime = Date.now();
    let handshakeCompleted = false;

    const timer = setTimeout(() => {
      if (!handshakeCompleted) {
        client.destroy();
        resolve({
          isConnected: false,
          status: 'DISCONNECTED',
          error: 'Connection timeout',
          responseTime: null,
          details: `Failed to complete ZKTeco handshake with ${machine.ipAddress}:${machine.port} within ${timeout}ms`,
          lastChecked: new Date().toISOString()
        });
      }
    }, timeout);

    client.connect(machine.port || 4370, machine.ipAddress, () => {
      // ZKTeco CMD_CONNECT command
      // Command structure: [Header(4) + Data(payload)]
      const CMD_CONNECT = 1000;
      const sessionId = 0;
      const replyNumber = 0;
      
      // Create ZKTeco protocol packet
      const packet = Buffer.alloc(16);
      packet.writeUInt16LE(CMD_CONNECT, 0);    // Command
      packet.writeUInt16LE(0, 2);              // Checksum (will calculate)
      packet.writeUInt16LE(sessionId, 4);      // Session ID
      packet.writeUInt16LE(replyNumber, 6);    // Reply Number
      packet.writeUInt32LE(0, 8);              // Data length
      packet.writeUInt32LE(0, 12);             // Reserved
      
      // Calculate checksum
      let checksum = 0;
      for (let i = 0; i < packet.length; i += 2) {
        if (i !== 2) { // Skip checksum field
          checksum += packet.readUInt16LE(i);
        }
      }
      checksum = (65536 - (checksum % 65536)) % 65536;
      packet.writeUInt16LE(checksum, 2);
      
      // Send connection command
      client.write(packet);
    });

    client.on('data', (data) => {
      const responseTime = Date.now() - startTime;
      clearTimeout(timer);
      handshakeCompleted = true;
      
      if (data.length >= 8) {
        const command = data.readUInt16LE(0);
        const CMD_ACK_OK = 2000;
        const CMD_ACK_ERROR = 2001;
        const CMD_ACK_UNAUTH = 2005;
        
        if (command === CMD_ACK_OK) {
          client.destroy();
          resolve({
            isConnected: true,
            status: 'CONNECTED',
            error: null,
            responseTime: `${responseTime}ms`,
            details: `ZKTeco handshake successful with ${machine.ipAddress}:${machine.port}`,
            lastChecked: new Date().toISOString()
          });
        } else if (command === CMD_ACK_UNAUTH) {
          client.destroy();
          resolve({
            isConnected: true,
            status: 'AUTHENTICATION_REQUIRED',
            error: 'Device requires authentication',
            responseTime: `${responseTime}ms`,
            details: `Device responded but requires communication password`,
            lastChecked: new Date().toISOString()
          });
        } else if (command === CMD_ACK_ERROR) {
          client.destroy();
          resolve({
            isConnected: false,
            status: 'PROTOCOL_ERROR',
            error: 'Device protocol error',
            responseTime: `${responseTime}ms`,
            details: `Device rejected connection - check device settings`,
            lastChecked: new Date().toISOString()
          });
        } else {
          client.destroy();
          resolve({
            isConnected: false,
            status: 'UNKNOWN_RESPONSE',
            error: `Unexpected command: ${command}`,
            responseTime: `${responseTime}ms`,
            details: `Device sent unexpected response code ${command}`,
            lastChecked: new Date().toISOString()
          });
        }
      } else {
        client.destroy();
        resolve({
          isConnected: false,
          status: 'INVALID_RESPONSE',
          error: 'Invalid response length',
          responseTime: `${responseTime}ms`,
          details: `Received ${data.length} bytes, expected at least 8`,
          lastChecked: new Date().toISOString()
        });
      }
    });

    client.on('error', (error) => {
      clearTimeout(timer);
      client.destroy();
      
      let errorType = 'CONNECTION_ERROR';
      let errorDetails = error.message;
      
      if (error.code === 'ECONNREFUSED') {
        errorType = 'CONNECTION_REFUSED';
        errorDetails = `Machine refused TCP connection. Check if ZKTeco device is powered on at ${machine.ipAddress}:${machine.port}`;
      } else if (error.code === 'EHOSTUNREACH') {
        errorType = 'HOST_UNREACHABLE';
        errorDetails = `Host unreachable. Check network connection and IP address ${machine.ipAddress}`;
      } else if (error.code === 'ETIMEDOUT') {
        errorType = 'CONNECTION_TIMEOUT';
        errorDetails = `TCP connection timed out. Check network connectivity to ${machine.ipAddress}`;
      }
      
      resolve({
        isConnected: false,
        status: errorType,
        error: error.code || 'UNKNOWN_ERROR',
        responseTime: null,
        details: errorDetails,
        lastChecked: new Date().toISOString()
      });
    });

    client.on('close', () => {
      clearTimeout(timer);
    });
  });
}

// Helper functions
function calculateAttendanceStatus(record: any): string {
  if (!record.checkIn) return 'absent';
  
  const checkInTime = new Date(`1970-01-01T${record.checkIn}`);
  const standardStartTime = new Date(`1970-01-01T09:00:00`); // 9 AM standard
  
  if (checkInTime <= standardStartTime) return 'present';
  if (checkInTime <= new Date(`1970-01-01T09:30:00`)) return 'late';
  return 'half_day';
}

function calculateHoursWorked(checkIn: string, checkOut: string): number {
  if (!checkIn || !checkOut) return 0;
  
  const start = new Date(`1970-01-01T${checkIn}`);
  const end = new Date(`1970-01-01T${checkOut}`);
  const diffMs = end.getTime() - start.getTime();
  return Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100; // Hours with 2 decimal places
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toISOString().split('T')[0];
}

function formatTime(timeStr: string): string {
  if (!timeStr) return null;
  const time = new Date(timeStr);
  return time.toTimeString().split(' ')[0];
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      // Validate request body exists
      if (!req.body || typeof req.body !== 'object') {
        return res.status(400).json({ message: 'Request body is required' });
      }

      // Parse with Zod
      const validationResult = loginSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({ 
          message: 'Validation failed', 
          errors: validationResult.error.errors 
        });
      }
      
      const { email, password } = validationResult.data;
      
      // Test database connection first
      try {
        const user = await storage.authenticateUser(email, password);
        
        if (!user) {
          return res.status(401).json({ message: 'Invalid credentials' });
        }
        
        const token = jwt.sign({ userId: user.id }, JWT_SECRET_VALUE, { expiresIn: '7d' });
        
        res.json({
          user: {
            id: user.id,
            email: user.email,
            username: user.username,
            role: user.role,
            companyId: user.companyId,
          },
          token,
        });
      } catch (dbError) {
        console.error('Database error:', dbError);
        return res.status(500).json({ message: 'Database connection failed' });
      }
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req, res) => {
    res.json({
      user: {
        id: req.user.id,
        email: req.user.email,
        username: req.user.username,
        role: req.user.role,
        companyId: req.user.companyId,
      }
    });
  });

  // Dashboard stats
  app.get("/api/dashboard/stats/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const stats = await storage.getDashboardStats(companyId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch dashboard stats' });
    }
  });

  // Public companies endpoint MUST come before parameterized routes  
  app.get("/api/companies/public", async (req, res) => {
    try {
      const companies = await storage.getAllCompanies();
      // Return only basic info for job browsing
      const publicCompanies = companies.map(c => ({
        id: c.id,
        name: c.name,
        status: c.status
      })).filter(c => c.status === 'active');
      res.json(publicCompanies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch companies' });
    }
  });

  // Company routes
  app.get("/api/companies/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const company = await storage.getCompany(companyId);
      if (!company) {
        return res.status(404).json({ message: 'Company not found' });
      }
      res.json(company);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch company' });
    }
  });

  // Employee routes
  // System Admin: Get all employees across all companies
  app.get("/api/employees/all", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Access denied. System Admin only.' });
      }
      const allEmployees = await storage.getAllEmployees();
      res.json(allEmployees);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch all employees' });
    }
  });

  app.get("/api/employees/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const employees = await storage.getEmployeesByCompany(companyId);
      res.json(employees);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch employees' });
    }
  });

  app.post("/api/employees", authenticateToken, async (req, res) => {
    try {
      const employeeData = insertEmployeeSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employeeData.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      // Check for duplicate Aadhaar within company
      if (employeeData.aadhaarNo) {
        const existingEmployeeByAadhaar = await storage.getEmployeeByAadhaar(employeeData.aadhaarNo, employeeData.companyId);
        if (existingEmployeeByAadhaar) {
          return res.status(400).json({ 
            message: 'Duplicate Aadhaar Number', 
            error: `An employee with Aadhaar number "${employeeData.aadhaarNo}" already exists in this company` 
          });
        }
      }
      
      // Check for duplicate Employee ID/Paycode within company
      const existingEmployeeById = await storage.getEmployeeByCode(employeeData.employeeId, employeeData.companyId);
      if (existingEmployeeById) {
        return res.status(400).json({ 
          message: 'Duplicate Employee ID', 
          error: `Employee with ID "${employeeData.employeeId}" already exists in this company` 
        });
      }
      
      const employee = await storage.createEmployee(employeeData);
      res.status(201).json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid employee data', errors: error.errors });
      }
      console.error('Employee creation error:', error);
      res.status(500).json({ message: 'Failed to create employee', error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.put("/api/employees/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      // Ensure only admins can edit other employees
      if (req.user.role !== 'admin' && req.user.role !== 'system_admin') {
        return res.status(403).json({ 
          message: 'Access denied. Only administrators can edit employee profiles. Regular employees should use their own profile page for self-edits.' 
        });
      }
      
      // Extract payroll data from request body
      const {
        epfEnabled, employeePfLimit, employerPfLimit, esicEnabled, lwfEnabled, otEnabled,
        doubleOt, vpfEnabled, vpfAmount, tdsEnabled, tdsAmount, ptEnabled, ptAmount,
        bonusEnabled, bonusMonthlyPayment, entryType, ctcValue, grossValue,
        earningHead1, earningHead2, earningHead3, earningHead4,
        epfEmployeeAmount, esicEmployeeAmount, lwfEmployeeAmount,
        ...employeeFields
      } = req.body;

      // Use policy-based field filtering for admins (includes weekly off and all admin fields)
      const userRole = req.user.role;
      const allowedEmployeeData = filterAllowedFields(employeeFields, userRole);
      
      // Handle salary from either employeeFields or payroll values
      if (allowedEmployeeData.salary === undefined && (grossValue || ctcValue)) {
        allowedEmployeeData.salary = grossValue || ctcValue;
      }
      
      // Handle date fields properly
      if (allowedEmployeeData.dateOfBirth) {
        allowedEmployeeData.dateOfBirth = new Date(allowedEmployeeData.dateOfBirth);
      }
      if (allowedEmployeeData.hireDate) {
        allowedEmployeeData.hireDate = new Date(allowedEmployeeData.hireDate);
      }
      
      // Remove undefined fields
      Object.keys(allowedEmployeeData).forEach(key => {
        if (allowedEmployeeData[key] === undefined || allowedEmployeeData[key] === null || allowedEmployeeData[key] === '') {
          delete allowedEmployeeData[key];
        }
      });
      
      let updatedEmployee;
      if (Object.keys(allowedEmployeeData).length > 0) {
        updatedEmployee = await storage.updateEmployee(id, allowedEmployeeData);
      } else {
        updatedEmployee = employee; // No employee fields to update
      }
      
      // Handle payroll data separately
      const payrollData = {
        epfEnabled, employeePfLimit, employerPfLimit, esicEnabled, lwfEnabled, otEnabled,
        doubleOt, vpfEnabled, vpfAmount, tdsEnabled, tdsAmount, ptEnabled, ptAmount,
        bonusEnabled, bonusMonthlyPayment, entryType, ctcValue, grossValue,
        earningHead1, earningHead2, earningHead3, earningHead4,
        epfEmployeeAmount, esicEmployeeAmount, lwfEmployeeAmount
      };

      console.log('Raw payroll data received:', payrollData);

      // Clean up payroll data but preserve boolean values (including false)
      const cleanPayrollData = {};
      Object.keys(payrollData).forEach(key => {
        const value = payrollData[key];
        // Keep boolean values (true/false), non-empty strings, and numbers
        if (typeof value === 'boolean' || (value !== undefined && value !== null && value !== '')) {
          cleanPayrollData[key] = value;
        }
      });

      console.log('Cleaned payroll data to save:', cleanPayrollData);

      // Always save payroll data to ensure boolean states are preserved
      if (true) { // Always save payroll data
        try {
          const existingPayroll = await storage.getEmployeePayroll(id);
          
          if (existingPayroll) {
            await storage.updateEmployeePayroll(id, cleanPayrollData);
            console.log('Updated existing payroll for employee:', id);
          } else {
            await storage.createEmployeePayroll({
              ...cleanPayrollData,
              employeeId: id,
              companyId: updatedEmployee.companyId
            });
            console.log('Created new payroll for employee:', id);
          }
        } catch (payrollError) {
          console.error('Error handling payroll data:', payrollError);
        }
      }
      
      // Log admin activity for audit trail (always log, even for payroll-only changes)
      const updatedFields = Object.keys(allowedEmployeeData);
      const payrollKeys = Object.keys(cleanPayrollData || {});
      const allChanges = [
        ...(updatedFields.length > 0 ? [`Profile fields: ${updatedFields.join(', ')}`] : []),
        ...(payrollKeys.length > 0 ? [`Payroll fields: ${payrollKeys.join(', ')}`] : [])
      ];
      
      if (allChanges.length > 0) {
        await storage.createUserActivity({
          userId: req.user.id,
          companyId: req.user.companyId,
          action: 'admin_employee_direct_update',
          entityType: 'employee',
          entityId: id,
          details: `Admin directly updated employee ${employee.firstName} ${employee.lastName} (ID: ${id}). Changes: ${allChanges.join('. ')}.`,
          ipAddress: req.ip,
          userAgent: req.get('User-Agent')
        });
      }
      
      res.json({
        message: 'Employee updated successfully',
        employee: updatedEmployee,
        updatedFields: updatedFields,
        payrollUpdated: true
      });
    } catch (error) {
      console.error('Employee update error:', error);
      res.status(500).json({ message: 'Failed to update employee', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Get employee with payroll data
  app.get("/api/employees/:companyId/:id", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Get payroll data if exists
      const payrollData = await storage.getEmployeePayroll(id);
      
      console.log('Fetched payroll data for employee', id, ':', payrollData);
      
      // Add no-cache headers to prevent stale data
      res.set({
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      
      res.json({
        ...employee,
        payroll: payrollData || null
      });
    } catch (error) {
      console.error('Employee fetch error:', error);
      res.status(500).json({ message: 'Failed to fetch employee' });
    }
  });

  app.delete("/api/employees/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const employee = await storage.getEmployee(id);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access and role
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to delete this employee' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to delete employee' });
      }
      
      await storage.deleteEmployee(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete employee' });
    }
  });

  // Department routes
  app.get("/api/departments/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      res.json(departments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch departments' });
    }
  });

  app.post("/api/departments", authenticateToken, async (req, res) => {
    try {
      const departmentData = insertDepartmentSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== departmentData.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create department' });
      }
      
      const department = await storage.createDepartment(departmentData);
      res.status(201).json(department);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid department data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create department' });
    }
  });

  // Branches routes
  app.get("/api/branches/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const branches = await storage.getBranchesByCompany(companyId);
      res.json(branches);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch branches' });
    }
  });

  app.post("/api/branches", authenticateToken, async (req, res) => {
    try {
      const { name, address, city, state, zipCode, phone, manager, companyId } = req.body;
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create branch' });
      }
      
      const branch = await storage.createBranch({ name, address, city, state, zipCode, phone, manager, companyId });
      res.status(201).json(branch);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create branch' });
    }
  });

  app.put("/api/branches/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      const branch = await storage.updateBranch(id, updateData);
      res.json(branch);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update branch' });
    }
  });

  app.delete("/api/branches/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteBranch(id);
      res.json({ success: true, message: 'Branch deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete branch' });
    }
  });

  // Locations routes
  app.get("/api/locations/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const locations = await storage.getLocationsByCompany(companyId);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch locations' });
    }
  });

  app.post("/api/locations", authenticateToken, async (req, res) => {
    try {
      const { name, address, capacity, branchId, companyId } = req.body;
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create location' });
      }
      
      const location = await storage.createLocation({ name, address, capacity, branchId, companyId });
      res.status(201).json(location);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create location' });
    }
  });

  app.put("/api/locations/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      const location = await storage.updateLocation(id, updateData);
      res.json(location);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update location' });
    }
  });

  app.delete("/api/locations/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteLocation(id);
      res.json({ success: true, message: 'Location deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete location' });
    }
  });

  // Cost Centers routes
  app.get("/api/cost-centers/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const costCenters = await storage.getCostCentersByCompany(companyId);
      res.json(costCenters);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch cost centers' });
    }
  });

  app.post("/api/cost-centers", authenticateToken, async (req, res) => {
    try {
      const { code, name, description, budget, manager, companyId } = req.body;
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create cost center' });
      }
      
      const costCenter = await storage.createCostCenter({ code, name, description, budget, manager, companyId });
      res.status(201).json(costCenter);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create cost center' });
    }
  });

  app.put("/api/cost-centers/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      const costCenter = await storage.updateCostCenter(id, updateData);
      res.json(costCenter);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update cost center' });
    }
  });

  app.delete("/api/cost-centers/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteCostCenter(id);
      res.json({ success: true, message: 'Cost center deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete cost center' });
    }
  });

  // Designations routes
  app.get("/api/designations/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const designations = await storage.getDesignationsByCompany(companyId);
      res.json(designations);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch designations' });
    }
  });

  app.post("/api/designations", authenticateToken, async (req, res) => {
    try {
      const { title, level, description, departmentId, companyId } = req.body;
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create designation' });
      }
      
      const designation = await storage.createDesignation({ title, level, description, departmentId, companyId });
      res.status(201).json(designation);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create designation' });
    }
  });

  app.put("/api/designations/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      const designation = await storage.updateDesignation(id, updateData);
      res.json(designation);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update designation' });
    }
  });

  app.delete("/api/designations/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteDesignation(id);
      res.json({ success: true, message: 'Designation deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete designation' });
    }
  });

  // States and Districts routes
  app.get("/api/states", authenticateToken, async (req, res) => {
    try {
      const statesList = await storage.getStates();
      res.json(statesList);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch states' });
    }
  });

  app.get("/api/districts/:stateId", authenticateToken, async (req, res) => {
    try {
      const stateId = parseInt(req.params.stateId);
      const districtsList = await storage.getDistrictsByState(stateId);
      res.json(districtsList);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch districts' });
    }
  });

  // Enhanced employees route with full details
  app.get("/api/employees-full/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const employees = await storage.getEmployeesWithFullDetails(companyId);
      res.json(employees);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch employees with full details' });
    }
  });

  // Employee Salary Structure routes (month-wise historical tracking)
  
  // Get specific month's salary structure
  app.get("/api/employee-salary-structure/:employeeId/:year/:month", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      // Validate parameters
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      if (month < 1 || month > 12) {
        return res.status(400).json({ message: 'Month must be between 1 and 12' });
      }
      if (year < 2000 || year > 2100) {
        return res.status(400).json({ message: 'Invalid year' });
      }
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const structure = await storage.getEmployeeSalaryStructure(employeeId, year, month);
      if (!structure) {
        return res.status(404).json({ message: 'Salary structure not found for this month' });
      }
      
      res.json(structure);
    } catch (error) {
      console.error('Error fetching salary structure:', error);
      res.status(500).json({ message: 'Failed to fetch salary structure' });
    }
  });

  // Upsert salary structure for specific month
  app.put("/api/employee-salary-structure/:employeeId/:year/:month", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to update salary structure' });
      }
      
      // Validate parameters
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      if (month < 1 || month > 12) {
        return res.status(400).json({ message: 'Month must be between 1 and 12' });
      }
      if (year < 2000 || year > 2100) {
        return res.status(400).json({ message: 'Invalid year' });
      }
      
      // Validate request body - Zod schema now handles empty string transformation
      const structureData = {
        ...req.body,
        employeeId,
        year,
        month,
        companyId: employee.companyId
      };
      
      const validatedData = insertEmployeeSalaryStructureSchema.parse(structureData);
      const updatedStructure = await storage.upsertEmployeeSalaryStructure(validatedData);
      
      res.json(updatedStructure);
    } catch (error) {
      console.error('Error updating salary structure:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid salary structure data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to update salary structure' });
    }
  });

  // Cascade salary structure updates to future months (until next explicit update)
  app.post("/api/employee-salary-structure/:employeeId/:year/:month/cascade", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      console.log('Cascade request received:', { employeeId, year, month });
      
      // Validate parameters
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      if (month < 1 || month > 12) {
        return res.status(400).json({ message: 'Month must be between 1 and 12' });
      }
      
      // Get employee to check company access and verify existence
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - only admins can cascade updates
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to cascade salary structure updates' });
      }
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      // Get the source structure data from the persisted current month (ensures canonical data)
      const sourceStructure = await storage.getEmployeeSalaryStructure(employeeId, year, month);
      if (!sourceStructure) {
        return res.status(404).json({ message: 'Source salary structure not found for the specified month' });
      }
      
      console.log('Source structure found:', { year, month, sourceId: sourceStructure.id });
      
      // Get all existing future salary structures to determine where to stop cascading
      const existingFutureStructures = await storage.getFutureSalaryStructures(employeeId, year, month);
      console.log('Existing future structures:', existingFutureStructures.map(s => ({ year: s.year, month: s.month })));
      
      // Find the next explicit update (earliest future month with existing data)
      let stopYear = year + 2; // Default max 2 years
      let stopMonth = month;
      
      if (existingFutureStructures.length > 0) {
        const earliestFuture = existingFutureStructures[0]; // Already ordered by year, month
        stopYear = earliestFuture.year;
        stopMonth = earliestFuture.month;
        console.log('Found next explicit update, stopping at:', { stopYear, stopMonth });
      }
      
      // Generate future months to cascade (only until next explicit update)
      const futureMonths = [];
      let currentYear = year;
      let currentMonth = month + 1; // Start from next month
      
      // If there are no future structures, cascade for up to 24 months (2 years)
      if (existingFutureStructures.length === 0) {
        console.log('No existing future structures found, cascading for up to 24 months');
        for (let i = 0; i < 24; i++) {
          if (currentMonth > 12) {
            currentMonth = 1;
            currentYear++;
          }
          futureMonths.push({ year: currentYear, month: currentMonth });
          currentMonth++;
        }
      } else {
        console.log('Found existing future structures, cascading until first existing one');
        // Only cascade until the first existing future structure
        while (currentYear < stopYear || (currentYear === stopYear && currentMonth < stopMonth)) {
          if (currentMonth > 12) {
            currentMonth = 1;
            currentYear++;
          }
          
          futureMonths.push({ year: currentYear, month: currentMonth });
          currentMonth++;
          
          // Safety limit to prevent infinite loops
          if (futureMonths.length > 100) {
            console.warn('Cascade safety limit reached (100 months)');
            break;
          }
        }
      }
      
      console.log('Months to cascade:', futureMonths.length, futureMonths);
      
      // Update each future month with the source structure data (excluding id and timestamps)
      const updatedMonths = [];
      for (const { year: futureYear, month: futureMonth } of futureMonths) {
        const futureStructureData = {
          employeeId: sourceStructure.employeeId,
          companyId: sourceStructure.companyId,
          year: futureYear,
          month: futureMonth,
          epfEnabled: sourceStructure.epfEnabled,
          employeePfLimit: sourceStructure.employeePfLimit,
          employerPfLimit: sourceStructure.employerPfLimit,
          esicEnabled: sourceStructure.esicEnabled,
          lwfEnabled: sourceStructure.lwfEnabled,
          otEnabled: sourceStructure.otEnabled,
          doubleOt: sourceStructure.doubleOt,
          vpfEnabled: sourceStructure.vpfEnabled,
          vpfAmount: sourceStructure.vpfAmount,
          tdsEnabled: sourceStructure.tdsEnabled,
          tdsAmount: sourceStructure.tdsAmount,
          ptEnabled: sourceStructure.ptEnabled,
          ptAmount: sourceStructure.ptAmount,
          bonusEnabled: sourceStructure.bonusEnabled,
          bonusMonthlyPayment: sourceStructure.bonusMonthlyPayment,
          entryType: sourceStructure.entryType,
          ctcValue: sourceStructure.ctcValue,
          grossValue: sourceStructure.grossValue,
          earningHead1: sourceStructure.earningHead1,
          earningHead2: sourceStructure.earningHead2,
          earningHead3: sourceStructure.earningHead3,
          earningHead4: sourceStructure.earningHead4,
          epfEmployeeAmount: sourceStructure.epfEmployeeAmount,
          esicEmployeeAmount: sourceStructure.esicEmployeeAmount,
          lwfEmployeeAmount: sourceStructure.lwfEmployeeAmount
        };
        
        try {
          const updatedStructure = await storage.upsertEmployeeSalaryStructure(futureStructureData);
          updatedMonths.push({ year: futureYear, month: futureMonth, success: true });
          console.log(`Updated future month: ${futureYear}-${futureMonth}`);
        } catch (error) {
          console.warn(`Failed to update future month ${futureYear}-${futureMonth}:`, error);
          updatedMonths.push({ year: futureYear, month: futureMonth, success: false, error: error.message });
        }
      }
      
      console.log('Cascade completed:', { 
        total: futureMonths.length, 
        successful: updatedMonths.filter(m => m.success).length,
        failed: updatedMonths.filter(m => !m.success).length
      });
      
      res.json({ 
        message: 'Cascade update completed',
        sourceMonth: { year, month },
        updatedMonths: updatedMonths.filter(m => m.success),
        failedMonths: updatedMonths.filter(m => !m.success),
        stoppedAt: existingFutureStructures.length > 0 ? { year: stopYear, month: stopMonth } : null
      });
    } catch (error) {
      console.error('Error cascading salary structure updates:', error);
      res.status(500).json({ message: 'Failed to cascade salary structure updates', error: error.message });
    }
  });

  // Get latest salary structure for employee
  app.get("/api/employee-salary-structure/:employeeId/latest", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      
      // Validate parameters
      if (isNaN(employeeId)) {
        return res.status(400).json({ message: 'Invalid employee ID' });
      }
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const latestStructure = await storage.getLatestEmployeeSalaryStructure(employeeId);
      if (!latestStructure) {
        return res.status(404).json({ message: 'No salary structure found for this employee' });
      }
      
      res.json(latestStructure);
    } catch (error) {
      console.error('Error fetching latest salary structure:', error);
      res.status(500).json({ message: 'Failed to fetch latest salary structure' });
    }
  });

  // Get salary structure history for employee
  app.get("/api/employee-salary-structure/:employeeId/history", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 12;
      
      // Validate parameters
      if (isNaN(employeeId)) {
        return res.status(400).json({ message: 'Invalid employee ID' });
      }
      if (req.query.limit && (isNaN(limit) || limit < 1 || limit > 24)) {
        return res.status(400).json({ message: 'Limit must be between 1 and 24' });
      }
      
      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const history = await storage.getEmployeeSalaryStructureHistory(employeeId, limit);
      res.json(history);
    } catch (error) {
      console.error('Error fetching salary structure history:', error);
      res.status(500).json({ message: 'Failed to fetch salary structure history' });
    }
  });

  // Generate salary history PDF for employee
  app.get("/api/employee-salary-structure/:employeeId/pdf", authenticateToken, async (req: any, res: any) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 12;
      
      // Validate parameters
      if (isNaN(employeeId)) {
        return res.status(400).json({ message: 'Invalid employee ID' });
      }
      if (req.query.limit && (isNaN(limit) || limit < 1 || limit > 24)) {
        return res.status(400).json({ message: 'Limit must be between 1 and 24' });
      }
      
      // Get employee to check company access and gather info
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check access permissions - employees can only view their own records
      if (req.user.role === 'employee') {
        if (employee.userId !== req.user.id) {
          return res.status(403).json({ message: 'Access denied - employees can only view their own salary records' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      // Get company information for header
      const company = await storage.getCompany(employee.companyId);
      if (!company) {
        return res.status(404).json({ message: 'Company not found' });
      }
      
      // Get complete salary history from date of joining to current month
      const history = await storage.getCompleteSalaryHistoryFromJoining(employeeId);
      if (!history || history.length === 0) {
        return res.status(404).json({ message: 'No salary history found for this employee' });
      }
      
      // Generate PDF
      const pdfDoc = await PDFDocument.create();
      const timesRomanFont = await pdfDoc.embedFont(StandardFonts.TimesRoman);
      const timesRomanBoldFont = await pdfDoc.embedFont(StandardFonts.TimesRomanBold);
      const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica);
      const helveticaBoldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      
      let page = pdfDoc.addPage();
      const { width, height } = page.getSize();
      let currentY = height - 50;
      
      // PDF Header
      page.drawText(company.name, {
        x: 50,
        y: currentY,
        size: 20,
        font: helveticaBoldFont,
        color: rgb(0, 0, 0.5),
      });
      currentY -= 30;
      
      page.drawText('Salary History Report', {
        x: 50,
        y: currentY,
        size: 16,
        font: helveticaBoldFont,
        color: rgb(0.2, 0.2, 0.2),
      });
      currentY -= 40;
      
      // Employee Information
      page.drawText('Employee Information:', {
        x: 50,
        y: currentY,
        size: 14,
        font: helveticaBoldFont,
        color: rgb(0, 0, 0),
      });
      currentY -= 20;
      
      const employeeInfo = [
        `Name: ${employee.firstName} ${employee.lastName}`,
        `Employee ID: ${employee.employeeId}`,
        `Position: ${employee.position || 'N/A'}`,
        `Email: ${employee.email}`,
        `Generated on: ${new Date().toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        })}`
      ];
      
      employeeInfo.forEach(info => {
        page.drawText(info, {
          x: 70,
          y: currentY,
          size: 10,
          font: helveticaFont,
          color: rgb(0.3, 0.3, 0.3),
        });
        currentY -= 15;
      });
      
      currentY -= 20;
      
      // Table Headers
      const tableStartY = currentY;
      const colWidths = [80, 80, 80, 80, 80, 80, 80]; // Adjust as needed
      const headers = ['Period', 'CTC', 'Gross', 'Basic', 'HRA', 'Conveyance', 'Other'];
      
      // Draw table header background
      page.drawRectangle({
        x: 40,
        y: currentY - 20,
        width: width - 80,
        height: 25,
        color: rgb(0.9, 0.9, 0.9),
      });
      
      // Draw table headers
      let currentX = 50;
      headers.forEach((header, index) => {
        page.drawText(header, {
          x: currentX,
          y: currentY - 15,
          size: 9,
          font: helveticaBoldFont,
          color: rgb(0, 0, 0),
        });
        currentX += colWidths[index];
      });
      
      currentY -= 35;
      
      // Table Content
      const monthNames = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ];
      
      // Sort history by year and month (newest first)
      const sortedHistory = history.sort((a, b) => {
        if (a.year !== b.year) return b.year - a.year;
        return b.month - a.month;
      });
      
      sortedHistory.forEach((record, index) => {
        // Check if we need a new page
        if (currentY < 100) {
          page = pdfDoc.addPage();
          currentY = height - 50;
        }
        
        // Alternate row colors
        if (index % 2 === 0) {
          page.drawRectangle({
            x: 40,
            y: currentY - 15,
            width: width - 80,
            height: 20,
            color: rgb(0.98, 0.98, 0.98),
          });
        }
        
        const rowData = [
          `${monthNames[record.month - 1]} ${record.year}`,
          record.ctcValue ? `Rs.${parseFloat(record.ctcValue).toLocaleString('en-IN')}` : 'N/A',
          record.grossValue ? `Rs.${parseFloat(record.grossValue).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead1 ? `Rs.${parseFloat(record.earningHead1).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead2 ? `Rs.${parseFloat(record.earningHead2).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead3 ? `Rs.${parseFloat(record.earningHead3).toLocaleString('en-IN')}` : 'N/A',
          record.earningHead4 ? `Rs.${parseFloat(record.earningHead4).toLocaleString('en-IN')}` : 'N/A',
        ];
        
        currentX = 50;
        rowData.forEach((data, colIndex) => {
          page.drawText(data, {
            x: currentX,
            y: currentY - 10,
            size: 8,
            font: helveticaFont,
            color: rgb(0.2, 0.2, 0.2),
          });
          currentX += colWidths[colIndex];
        });
        
        currentY -= 25;
      });
      
      // Add footer
      const footerY = 30;
      page.drawText('This is a computer-generated document and does not require a signature.', {
        x: 50,
        y: footerY,
        size: 8,
        font: helveticaFont,
        color: rgb(0.5, 0.5, 0.5),
      });
      
      page.drawText(`Generated by ${company.name} HR System`, {
        x: width - 200,
        y: footerY,
        size: 8,
        font: helveticaFont,
        color: rgb(0.5, 0.5, 0.5),
      });
      
      // Generate PDF bytes
      const pdfBytes = await pdfDoc.save();
      
      // Set response headers for PDF download  
      const fileName = `salary_history_${employee.firstName}_${employee.lastName}_${new Date().toISOString().split('T')[0]}.pdf`;
      
      // Clear any existing headers that might interfere
      res.removeHeader('Content-Type');
      
      // Set PDF-specific headers
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${fileName}"`,
        'Content-Length': pdfBytes.length.toString(),
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      });
      
      // Send PDF as buffer (bypass any JSON middleware)
      res.status(200);
      res.end(Buffer.from(pdfBytes));
      
    } catch (error) {
      console.error('Error generating salary history PDF:', error);
      res.status(500).json({ message: 'Failed to generate salary history PDF' });
    }
  });

  // Salary Component Management API Routes
  
  // Get all salary components
  app.get("/api/salary-components", authenticateToken, async (req, res) => {
    try {
      const components = await storage.getSalaryComponents();
      res.json(components);
    } catch (error) {
      console.error('Error fetching salary components:', error);
      res.status(500).json({ message: 'Failed to fetch salary components' });
    }
  });

  // Company salary component configuration routes
  app.get("/api/company-salary-config/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const entryMode = req.query.entryMode as string;
      
      if (isNaN(companyId)) {
        return res.status(400).json({ message: 'Invalid company ID' });
      }

      // Validate entryMode if provided
      if (entryMode && !['gross', 'ctc', 'earning_heads'].includes(entryMode)) {
        return res.status(400).json({ message: 'Invalid entry mode. Must be: gross, ctc, or earning_heads' });
      }

      const config = await storage.getCompanySalaryComponentConfig(companyId, entryMode);
      res.json(config);
    } catch (error) {
      console.error('Error fetching company salary config:', error);
      res.status(500).json({ message: 'Failed to fetch company salary configuration' });
    }
  });

  // Create or update company salary component configuration
  app.post("/api/company-salary-config", authenticateToken, async (req, res) => {
    try {
      const { insertCompanySalaryComponentConfigSchema } = await import("@shared/schema");
      const config = insertCompanySalaryComponentConfigSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== config.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }

      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to modify salary configuration' });
      }

      const result = await storage.upsertCompanySalaryComponentConfig(config);
      res.status(201).json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid configuration data', errors: error.errors });
      }
      console.error('Error saving company salary config:', error);
      res.status(500).json({ message: 'Failed to save company salary configuration' });
    }
  });

  // Salary calculation preview endpoints
  app.post("/api/salary-calculation/preview/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const { mode, amount, compliance, complianceValues } = req.body;
      
      if (isNaN(companyId)) {
        return res.status(400).json({ message: 'Invalid company ID' });
      }

      if (!mode) {
        return res.status(400).json({ message: 'Mode is required' });
      }

      // Validate mode
      if (!['gross', 'ctc', 'earning_heads'].includes(mode)) {
        return res.status(400).json({ message: 'Invalid mode. Must be: gross, ctc, or earning_heads' });
      }

      // For gross and ctc modes, amount is required
      if ((mode === 'gross' || mode === 'ctc') && (!amount || isNaN(parseFloat(amount)))) {
        return res.status(400).json({ message: 'Mode and amount are required' });
      }

      const { SalaryStructureEngine } = await import('./SalaryStructureEngine');
      let result;

      // Prepare compliance settings with defaults
      const complianceSettings = {
        epfEnabled: compliance?.epfEnabled ?? true,
        esicEnabled: compliance?.esicEnabled ?? true,
        lwfEnabled: compliance?.lwfEnabled ?? true,
        otEnabled: compliance?.otEnabled ?? false,
        vpfEnabled: compliance?.vpfEnabled ?? false,
        tdsEnabled: compliance?.tdsEnabled ?? false,
        ptEnabled: compliance?.ptEnabled ?? false,
        bonusEnabled: compliance?.bonusEnabled ?? true,
        pfLimit: compliance?.pfLimit ?? false,
        pfLimitHigher: compliance?.pfLimitHigher ?? false,
        bonusMonthly: compliance?.bonusMonthly ?? false,
      };

      // Prepare compliance values
      const complianceVals = {
        vpfPercentage: complianceValues?.vpfPercentage ? parseFloat(complianceValues.vpfPercentage) : 0,
        tdsPercentage: complianceValues?.tdsPercentage ? parseFloat(complianceValues.tdsPercentage) : 0,
        ptAmount: complianceValues?.ptAmount ? parseFloat(complianceValues.ptAmount) : 0,
      };

      switch (mode) {
        case 'gross':
          result = await SalaryStructureEngine.calculateFromGross(companyId, parseFloat(amount), complianceSettings, complianceVals);
          break;
        case 'ctc':
          result = await SalaryStructureEngine.calculateFromCTC(companyId, parseFloat(amount), complianceSettings, complianceVals);
          break;
        case 'earning_heads':
          // For earning heads mode, expect components array instead of single amount
          if (!req.body.components || !Array.isArray(req.body.components)) {
            return res.status(400).json({ message: 'Components array is required for earning heads mode' });
          }
          result = await SalaryStructureEngine.calculateFromEarningHeads(companyId, req.body.components, complianceSettings, complianceVals);
          break;
        default:
          return res.status(400).json({ message: 'Invalid calculation mode' });
      }

      res.json(result);
    } catch (error) {
      console.error('Error calculating salary preview:', error);
      res.status(500).json({ message: 'Failed to calculate salary preview' });
    }
  });

  // Employee salary component values routes
  app.get("/api/employee-salary-components/:structureId", authenticateToken, async (req, res) => {
    try {
      const structureId = parseInt(req.params.structureId);
      
      if (isNaN(structureId)) {
        return res.status(400).json({ message: 'Invalid structure ID' });
      }

      // Get structure to check access
      const structure = await storage.getEmployeeSalaryStructure(structureId, 0, 0); // Dummy year/month for ID lookup
      if (!structure) {
        return res.status(404).json({ message: 'Salary structure not found' });
      }

      // Check access permissions
      const employee = await storage.getEmployee(structure.employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role === 'employee' && employee.userId !== req.user.id) {
        return res.status(403).json({ message: 'Access denied to this salary structure' });
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }

      const values = await storage.getEmployeeSalaryComponentValues(structureId);
      res.json(values);
    } catch (error) {
      console.error('Error fetching employee salary component values:', error);
      res.status(500).json({ message: 'Failed to fetch employee salary component values' });
    }
  });

  // Public jobs endpoint MUST come before parameterized routes
  app.get("/api/jobs/public", async (req, res) => {
    try {
      const jobs = await storage.getAllPublicJobs();
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch jobs' });
    }
  });

  // Job routes
  app.get("/api/jobs/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const jobs = await storage.getJobsByCompany(companyId);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch jobs' });
    }
  });

  app.get("/api/jobs/:companyId/:id", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.getJob(id);
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      res.json(job);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job' });
    }
  });

  app.post("/api/jobs", authenticateToken, async (req, res) => {
    try {
      const jobData = insertJobSchema.parse(req.body);
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== jobData.companyId) {
        return res.status(403).json({ message: 'Access denied to this company' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to create job' });
      }
      
      const job = await storage.createJob({ ...jobData, postedBy: req.user.id });
      res.status(201).json(job);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid job data', errors: error.errors });
      }
      res.status(500).json({ message: 'Failed to create job' });
    }
  });

  app.put("/api/jobs/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const job = await storage.getJob(id);
      
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== job.companyId) {
        return res.status(403).json({ message: 'Access denied to this job' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions to update job' });
      }
      
      const updatedJob = await storage.updateJob(id, req.body);
      res.json(updatedJob);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update job' });
    }
  });

  // Job Applications routes
  app.get("/api/applications/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const applications = await storage.getApplicationsByCompany(companyId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch applications' });
    }
  });

  app.get("/api/applications/job/:jobId", authenticateToken, async (req, res) => {
    try {
      const jobId = parseInt(req.params.jobId);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== job.companyId) {
        return res.status(403).json({ message: 'Access denied to this job' });
      }
      
      const applications = await storage.getApplicationsByJob(jobId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job applications' });
    }
  });

  // Attendance routes
  app.get("/api/attendance/:employeeId", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const employee = await storage.getEmployee(employeeId);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const date = req.query.date ? new Date(req.query.date as string) : undefined;
      const attendance = await storage.getAttendanceByEmployee(employeeId, date);
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch attendance' });
    }
  });

  app.post("/api/attendance", authenticateToken, async (req, res) => {
    try {
      const attendanceData = req.body;
      const employee = await storage.getEmployee(attendanceData.employeeId);
      
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const attendance = await storage.createAttendance(attendanceData);
      res.status(201).json(attendance);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create attendance record' });
    }
  });

  // Enhanced Attendance Management Routes
  
  // Check-in endpoint with face and location verification
  app.post("/api/attendance/checkin", authenticateToken, async (req, res) => {
    try {
      const employee = await storage.getEmployeeByUserId(req.user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      const { latitude, longitude, faceImage, deviceInfo } = req.body;
      const ipAddress = req.ip || req.connection.remoteAddress;

      const attendance = await storage.markCheckIn(employee.id, {
        latitude,
        longitude,
        faceImage,
        deviceInfo,
        ipAddress
      });

      res.status(201).json({
        success: true,
        message: 'Check-in successful',
        attendance,
        verifications: {
          faceVerified: attendance.faceVerified,
          locationVerified: attendance.locationVerified
        }
      });
    } catch (error) {
      console.error('Check-in error:', error);
      res.status(500).json({ message: 'Failed to mark check-in', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Check-out endpoint
  app.post("/api/attendance/checkout/:attendanceId", authenticateToken, async (req, res) => {
    try {
      const attendanceId = parseInt(req.params.attendanceId);
      const { latitude, longitude } = req.body;

      const attendance = await storage.markCheckOut(attendanceId, {
        latitude,
        longitude
      });

      res.json({
        success: true,
        message: 'Check-out successful',
        attendance,
        hoursWorked: attendance.hoursWorked
      });
    } catch (error) {
      console.error('Check-out error:', error);
      res.status(500).json({ message: 'Failed to mark check-out', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Get today's attendance status for employee
  app.get("/api/attendance/today", authenticateToken, async (req, res) => {
    try {
      const employee = await storage.getEmployeeByUserId(req.user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      const today = new Date();
      const attendance = await storage.getAttendanceByEmployee(employee.id, today);
      
      const todayAttendance = attendance.length > 0 ? attendance[0] : null;
      
      res.json({
        hasCheckedIn: !!todayAttendance?.checkIn,
        hasCheckedOut: !!todayAttendance?.checkOut,
        attendance: todayAttendance,
        canCheckIn: !todayAttendance?.checkIn,
        canCheckOut: todayAttendance?.checkIn && !todayAttendance?.checkOut
      });
    } catch (error) {
      console.error('Today attendance error:', error);
      res.status(500).json({ message: 'Failed to fetch today\'s attendance' });
    }
  });

  // Monthly attendance summary - for specific employee (admin access)
  app.get("/api/attendance/monthly/:employeeId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (isNaN(employeeId) || isNaN(year) || isNaN(month)) {
        return res.status(400).json({ message: 'Invalid parameters' });
      }
      
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      // Check access
      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      let monthlyAttendance = await storage.getMonthlyAttendance(employeeId, year, month);
      
      // Calculate if not exists or if requesting current month (to refresh)
      const currentDate = new Date();
      const isCurrentMonth = year === currentDate.getFullYear() && month === (currentDate.getMonth() + 1);
      
      if (!monthlyAttendance || isCurrentMonth) {
        monthlyAttendance = await storage.calculateMonthlyAttendance(employeeId, employee.companyId, year, month);
      }

      res.json(monthlyAttendance);
    } catch (error) {
      console.error('Monthly attendance error:', error);
      res.status(500).json({ message: 'Failed to fetch monthly attendance' });
    }
  });

  // Monthly attendance summary - for current employee
  app.get("/api/attendance/monthly/me/:year/:month", authenticateToken, async (req, res) => {
    try {
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (isNaN(year) || isNaN(month) || month < 1 || month > 12 || year < 2020 || year > 2030) {
        console.error('Invalid monthly attendance parameters:', { year, month });
        return res.status(400).json({ message: 'Invalid parameters' });
      }

      const employee = await storage.getEmployeeByUserId(req.user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee record not found' });
      }

      let monthlyAttendance = await storage.getMonthlyAttendance(employee.id, year, month);
      
      // Calculate if not exists or if requesting current month (to refresh)
      const currentDate = new Date();
      const isCurrentMonth = year === currentDate.getFullYear() && month === (currentDate.getMonth() + 1);
      
      if (!monthlyAttendance || isCurrentMonth) {
        monthlyAttendance = await storage.calculateMonthlyAttendance(employee.id, employee.companyId, year, month);
      }

      res.json(monthlyAttendance);
    } catch (error) {
      console.error('Monthly attendance error:', error);
      res.status(500).json({ message: 'Failed to fetch monthly attendance' });
    }
  });

  // Test endpoint to trigger monthly calculation (for development)
  app.post("/api/attendance/test-monthly-calculation", async (req, res) => {
    try {
      const { employeeId, companyId, year, month } = req.body;
      
      console.log(`🧪 Starting monthly calculation test`);
      console.log(`📋 Parameters: employee=${employeeId}, company=${companyId}, year=${year}, month=${month}`);
      
      // Check if storage.calculateMonthlyAttendance exists
      if (typeof storage.calculateMonthlyAttendance !== 'function') {
        console.error(`❌ storage.calculateMonthlyAttendance is not a function`);
        return res.status(500).json({ 
          success: false,
          message: 'calculateMonthlyAttendance function not available'
        });
      }
      
      console.log(`🔄 Calling storage.calculateMonthlyAttendance...`);
      const result = await storage.calculateMonthlyAttendance(employeeId, companyId, year, month);
      
      console.log(`✅ Monthly calculation completed successfully`);
      console.log(`📊 Result:`, JSON.stringify(result, null, 2));
      
      res.json({
        success: true,
        message: 'Monthly calculation completed successfully',
        data: result
      });
    } catch (error) {
      console.error(`❌ Test monthly calculation error:`, error);
      console.error(`📋 Error stack:`, error.stack);
      res.status(500).json({ 
        success: false,
        message: 'Failed to calculate monthly attendance',
        error: error.message,
        stack: error.stack
      });
    }
  });

  // Quick attendance entry
  app.post("/api/attendance/quick-entry", authenticateToken, async (req, res) => {
    try {
      const { employeeId, payDays, otHours, month, year } = req.body;
      
      if (!employeeId || payDays === undefined || otHours === undefined || !month || !year) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Store the attendance data in monthly attendance table
      const result = await storage.upsertMonthlyAttendanceQuickEntry({
        employeeId,
        year,
        month,
        payDays,
        otHours: parseFloat(otHours),
        companyId: employee.companyId
      });

      res.json({
        success: true,
        message: 'Attendance data updated successfully',
        data: result
      });
    } catch (error) {
      console.error('Quick entry error:', error);
      res.status(500).json({ message: 'Failed to update attendance data', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Quick daily attendance entry (with in time and out time)
  app.post("/api/attendance/daily-entry", authenticateToken, async (req, res) => {
    try {
      const { employeeId, date, inTime, outTime } = req.body;
      
      if (!employeeId || !date || !inTime || !outTime) {
        return res.status(400).json({ message: 'Missing required fields' });
      }

      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const result = await storage.saveDailyAttendance({
        employeeId,
        companyId: employee.companyId,
        date,
        inTime,
        outTime,
        status: 'present'
      });

      res.json({
        success: true,
        message: 'Daily attendance added successfully',
        data: result
      });
    } catch (error) {
      console.error('Daily entry error:', error);
      res.status(500).json({ message: 'Failed to add daily attendance', error: error instanceof Error ? error.message : String(error) });
    }
  });

  // Get attendance summary for today
  app.get("/api/attendance/summary/today", authenticateToken, async (req, res) => {
    try {
      const companyId = req.user.companyId;
      if (!companyId) {
        return res.status(400).json({ message: 'Company not found' });
      }
      
      const employees = await storage.getEmployeesByCompany(companyId);
      const totalEmployees = employees.length;
      
      const summary = {
        todayPresent: Math.floor(totalEmployees * 0.85) || 1,
        todayAbsent: Math.floor(totalEmployees * 0.15) || 0,
        todayLeave: Math.floor(totalEmployees * 0.08) || 0,
        todayWeeklyOff: Math.floor(totalEmployees * 0.05) || 0,
        continuouslyAbsent: Math.floor(totalEmployees * 0.02) || 0
      };

      res.json(summary);
    } catch (error) {
      console.error('Summary error:', error);
      res.status(500).json({ message: 'Failed to fetch attendance summary' });
    }
  });

  // Get employee attendance data for table
  app.get("/api/attendance/employee-data/:companyId/:year/:month", authenticateToken, async (req, res) => {
    // Disable HTTP caching to prevent 304 responses
    res.set({
      'Cache-Control': 'no-store, no-cache, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    
    try {
      const companyId = parseInt(req.params.companyId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);

      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      const holidayCount = await storage.getHolidayCountForMonth(companyId, year, month);
      
      const attendanceData = [];
      
      for (const emp of employees) {
        let monthlyRecord = await storage.getMonthlyAttendanceByEmployee(emp.id, year, month);
        
        // Only show employees that have actual attendance records
        // If no saved record, skip this employee (don't generate defaults)
        if (!monthlyRecord) {
          continue; // Skip employees without attendance records
        }
        
        const department = departments.find(d => d.id === emp.departmentId);
        const actualLeaveDays = await storage.getApprovedLeaveDaysForMonth(emp.id, year, month);
        
        attendanceData.push({
          id: emp.id,
          payCode: emp.employeeId,
          employeeName: `${emp.firstName} ${emp.lastName}`,
          department: department?.name || 'N/A',
          present: monthlyRecord.presentDays || 0,
          weeklyOff: monthlyRecord.weeklyOffDays || 0,
          leave: actualLeaveDays,
          holidays: holidayCount,
          payDays: monthlyRecord.payableDays || 0,
          otHours: parseFloat(monthlyRecord.totalHoursWorked || '0')
        });
      }

      res.json(attendanceData);
    } catch (error) {
      console.error('Employee attendance data error:', error);
      res.status(500).json({ message: 'Failed to fetch employee attendance data' });
    }
  });

  // In-memory storage for monthly attendance data (in a real app, this would be in the database)
  const monthlyAttendanceStore = new Map<string, any[]>();
  
  // Clear cache when server restarts to ensure fresh data with new calculations
  monthlyAttendanceStore.clear();

  // Delete attendance record
  app.delete("/api/attendance/delete/:companyId/:employeeId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);

      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Get employee to verify it belongs to the company
      const employee = await storage.getEmployee(employeeId);
      if (!employee || employee.companyId !== companyId) {
        return res.status(404).json({ message: 'Employee not found in this company' });
      }

      // Get the attendance data for this company/month
      const key = `${req.user.companyId}-${year}-${month}`;
      let attendanceData = monthlyAttendanceStore.get(key);
      
      if (!attendanceData) {
        // If no stored data, get fresh data from the main API and store it
        const employees = await storage.getEmployeesByCompany(req.user.companyId);
        const departments = await storage.getDepartmentsByCompany(req.user.companyId);
        const holidayCount = await storage.getHolidayCountForMonth(req.user.companyId, year, month);
        
        attendanceData = [];
        for (const emp of employees) {
          // Get monthly attendance record for this employee
          let monthlyRecord;
          try {
            monthlyRecord = await storage.getMonthlyAttendance(emp.id, year, month);
          } catch (error) {
            // If no record exists, generate default data
            const basePresent = 20 + (emp.id % 5);
            const weeklyOff = 4;
            const actualLeaveDays = await storage.getApprovedLeaveDaysForMonth(emp.id, year, month);
            const holidays = holidayCount;
            const payDays = basePresent + weeklyOff + actualLeaveDays + holidays;
            const otHours = (emp.id + 1) * 1.5;
            
            monthlyRecord = {
              presentDays: basePresent,
              payableDays: payDays,
              totalHoursWorked: otHours.toString()
            };
          }
          
          const department = departments.find(d => d.id === emp.departmentId);
          
          const safePresentDays = monthlyRecord?.presentDays || 20;
          const safePayableDays = monthlyRecord?.payableDays || 26;
          const safeTotalHours = monthlyRecord?.totalHoursWorked || '0';
          const actualLeaveDaysForDisplay = await storage.getApprovedLeaveDaysForMonth(emp.id, year, month);
          
          attendanceData.push({
            id: emp.id,
            payCode: emp.employeeId,
            employeeName: `${emp.firstName} ${emp.lastName}`,
            department: department?.name || 'N/A',
            present: safePresentDays,
            weeklyOff: 4,
            leave: actualLeaveDaysForDisplay,
            holidays: holidayCount,
            payDays: safePayableDays,
            otHours: parseFloat(safeTotalHours)
          });
        }
        monthlyAttendanceStore.set(key, attendanceData);
      }

      // First, try to delete from database
      try {
        await storage.deleteMonthlyAttendance(employeeId, year, month);
      } catch (error) {
        // Log error but continue - record might not exist in database
        console.log('No database record to delete for employee', employeeId, year, month);
      }

      // Remove the employee's attendance record from in-memory cache
      const originalLength = attendanceData.length;
      attendanceData = attendanceData.filter((record: any) => record.id !== employeeId);
      
      if (attendanceData.length === originalLength) {
        return res.status(404).json({ message: 'Attendance record not found' });
      }

      // Update the in-memory store
      monthlyAttendanceStore.set(key, attendanceData);
      
      // Clear the cache key to force fresh data fetch on next request
      monthlyAttendanceStore.delete(key);

      res.json({
        success: true,
        message: 'Attendance record deleted successfully'
      });
    } catch (error) {
      console.error('Delete attendance error:', error);
      res.status(500).json({ message: 'Failed to delete attendance record' });
    }
  });

  // In-memory storage for daily records (in a real app, this would be in the database)
  const dailyRecordsStore = new Map<string, any[]>();

  const generateInitialDailyRecords = (employeeId: number, year: number, month: number) => {
    const key = `${employeeId}-${year}-${month}`;
    if (dailyRecordsStore.has(key)) {
      return dailyRecordsStore.get(key)!;
    }

    const daysInMonth = new Date(year, month, 0).getDate();
    const dailyRecords = [];
    
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const statuses = ['Present', 'Present', 'Present', 'Present', 'Late', 'Present', 'Absent'];
    const sources = ['Biometric', 'Biometric', 'Manual', 'Biometric', 'Self', 'Biometric', 'Manual'];

    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month - 1, day);
      const dayOfWeek = date.getDay();
      const dayName = dayNames[dayOfWeek];
      
      // Skip Sundays for most records
      if (dayOfWeek === 0 && Math.random() > 0.2) continue;
      
      const status = statuses[day % statuses.length];
      const isPresent = status !== 'Absent';
      
      const baseInHour = 9 + (day % 3) * 0.5; // 9:00-10:30 range
      const baseOutHour = 18 + (day % 2) * 0.5; // 18:00-18:30 range
      
      const inTime = isPresent ? `${Math.floor(baseInHour).toString().padStart(2, '0')}:${((baseInHour % 1) * 60).toString().padStart(2, '0')}` : '';
      const outTime = isPresent ? `${Math.floor(baseOutHour).toString().padStart(2, '0')}:${((baseOutHour % 1) * 60).toString().padStart(2, '0')}` : '';
      
      const workingHours = isPresent ? baseOutHour - baseInHour : 0;
      const otHours = Math.max(0, workingHours - 8);

      dailyRecords.push({
        id: day + employeeId * 100,
        date: date.toISOString().split('T')[0],
        day: dayName,
        inTime,
        outTime,
        workingHours: Math.round(workingHours * 10) / 10,
        otHours: Math.round(otHours * 10) / 10,
        status,
        source: sources[day % sources.length]
      });
    }

    const sortedRecords = dailyRecords.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    dailyRecordsStore.set(key, sortedRecords);
    return sortedRecords;
  };

  // Get daily attendance log for employee - now using actual attendance data
  app.get("/api/attendance/daily-log/:employeeId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);

      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Get daily logs from database
      const dailyRecords = await storage.getDailyAttendanceRecords(employeeId, year, month);
      console.log(`📅 Retrieved ${dailyRecords.length} daily records from database for employee ${employeeId}`);
      res.json(dailyRecords);
    } catch (error) {
      console.error('Daily log error:', error);
      res.status(500).json({ message: 'Failed to fetch daily attendance log' });
    }
  });

  // Add daily attendance record
  app.post("/api/attendance/daily-record", authenticateToken, async (req, res) => {
    try {
      const { employeeId, date, inTime, outTime, workingHours, otHours, status, source } = req.body;

      // Get employee to check company access
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Create new record in database
      const newRecord = await storage.createDailyAttendanceRecord({
        employeeId,
        companyId: employee.companyId,
        date,
        checkIn: inTime,
        checkOut: outTime,
        status,
        hoursWorked: workingHours,
        verificationType: source?.toLowerCase() || 'manual'
      });

      res.json({
        success: true,
        message: 'Daily attendance record added successfully',
        data: {
          id: newRecord.id,
          date,
          day: new Date(date).toLocaleDateString('en-US', { weekday: 'long' }),
          inTime,
          outTime,
          workingHours,
          otHours,
          status,
          source
        }
      });
    } catch (error) {
      console.error('Add daily record error:', error);
      res.status(500).json({ message: 'Failed to add daily attendance record' });
    }
  });

  // Update daily attendance record
  app.put("/api/attendance/daily-record/:recordId", authenticateToken, async (req, res) => {
    try {
      const recordId = parseInt(req.params.recordId);
      const { date, inTime, outTime, workingHours, otHours, status, source } = req.body;

      // Check if record exists in database
      const existingRecord = await storage.getDailyAttendanceRecord(recordId);
      if (!existingRecord) {
        return res.status(404).json({ message: 'Record not found' });
      }

      // Get employee to check company access
      const employee = await storage.getEmployee(existingRecord.employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Update the record in database
      const updatedRecord = await storage.updateDailyAttendanceRecord(recordId, {
        date,
        checkIn: inTime,
        checkOut: outTime,
        status,
        hoursWorked: workingHours
      });

      res.json({
        success: true,
        message: 'Daily attendance record updated successfully',
        data: {
          id: updatedRecord.id,
          date,
          day: new Date(date).toLocaleDateString('en-US', { weekday: 'long' }),
          inTime,
          outTime,
          workingHours,
          otHours,
          status,
          source
        }
      });
    } catch (error) {
      console.error('Update daily record error:', error);
      res.status(500).json({ message: 'Failed to update daily attendance record' });
    }
  });

  // Delete daily attendance record
  app.delete("/api/attendance/daily-record/:recordId", authenticateToken, async (req, res) => {
    try {
      const recordId = parseInt(req.params.recordId);

      // Check if record exists in database
      const existingRecord = await storage.getDailyAttendanceRecord(recordId);
      if (!existingRecord) {
        return res.status(404).json({ message: 'Record not found' });
      }

      // Get employee to check company access
      const employee = await storage.getEmployee(existingRecord.employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== employee.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Delete the record from database
      const deleted = await storage.deleteDailyAttendanceRecord(recordId);
      
      if (!deleted) {
        return res.status(404).json({ message: 'Record not found' });
      }

      res.json({
        success: true,
        message: 'Daily attendance record deleted successfully',
        data: { recordId, deletedRecord: existingRecord }
      });
    } catch (error) {
      console.error('Delete daily record error:', error);
      res.status(500).json({ message: 'Failed to delete daily attendance record' });
    }
  });

  // User Management Routes (Admin and System Admin only)
  app.get("/api/users", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      let users;
      if (req.user.role === 'system_admin') {
        users = await storage.getAllUsers();
      } else {
        users = await storage.getUsersByCompany(req.user.companyId);
      }
      
      // Remove password from response
      const safeUsers = users.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        companyId: user.companyId,
        isActive: user.isActive,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt,
      }));
      
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch users' });
    }
  });

  app.post("/api/users", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      // System admin can create users for any company, admin only for their company
      if (req.user.role === 'admin' && req.body.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Cannot create users for other companies' });
      }
      
      const userData = req.body;
      const user = await storage.createUser(userData);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'user_created',
        entityType: 'user',
        entityId: user.id,
        details: `Created user: ${user.email}`,
      });
      
      // Remove password from response
      const { password, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create user' });
    }
  });

  app.put("/api/users/:id", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const existingUser = await storage.getUser(userId);
      
      if (!existingUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Permission checks
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      if (req.user.role === 'admin' && existingUser.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Cannot edit users from other companies' });
      }
      
      const updatedUser = await storage.updateUser(userId, req.body);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'user_updated',
        entityType: 'user',
        entityId: userId,
        details: `Updated user: ${updatedUser.email}`,
      });
      
      const { password, ...safeUser } = updatedUser;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update user' });
    }
  });

  app.put("/api/users/:id/password", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { newPassword } = req.body;
      
      if (!newPassword || newPassword.length < 6) {
        return res.status(400).json({ message: 'Password must be at least 6 characters' });
      }
      
      const existingUser = await storage.getUser(userId);
      
      if (!existingUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Only system_admin can reset passwords
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only System Admin can reset passwords' });
      }
      
      // Hash the new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      
      // Update password
      await storage.updateUser(userId, { password: hashedPassword });
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'password_reset',
        entityType: 'user',
        entityId: userId,
        details: `Reset password for user: ${existingUser.email}`,
      });
      
      res.json({ message: 'Password reset successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to reset password' });
    }
  });

  app.delete("/api/users/:id", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const existingUser = await storage.getUser(userId);
      
      if (!existingUser) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Permission checks
      if (req.user.role !== 'system_admin' && req.user.role !== 'admin') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      if (req.user.role === 'admin' && existingUser.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Cannot delete users from other companies' });
      }
      
      await storage.deleteUser(userId);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'user_deleted',
        entityType: 'user',
        entityId: userId,
        details: `Deleted user: ${existingUser.email}`,
      });
      
      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete user' });
    }
  });

  // Company Management Routes (System Admin only)
  app.get("/api/admin/companies", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companies = await storage.getAllCompanies();
      res.json(companies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch companies' });
    }
  });

  app.post("/api/admin/companies", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyData = req.body;
      const company = await storage.createCompany(companyData);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: 'company_created',
        entityType: 'company',
        entityId: company.id,
        details: `Created company: ${company.name}`,
      });
      
      res.status(201).json(company);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create company' });
    }
  });

  app.put("/api/admin/companies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyId = parseInt(req.params.id);
      const updatedCompany = await storage.updateCompany(companyId, req.body);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: 'company_updated',
        entityType: 'company',
        entityId: companyId,
        details: `Updated company: ${updatedCompany.name}`,
      });
      
      res.json(updatedCompany);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update company' });
    }
  });

  // Company profile update for admins
  app.put("/api/companies/:id", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.id);
      
      // Check if user is admin of this company
      if (req.user.role !== 'admin' || req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      // When profile is completed, set status to pending for approval
      const profileData = { ...req.body, status: 'pending' };
      const updatedCompany = await storage.updateCompanyProfile(companyId, profileData);
      
      res.json(updatedCompany);
    } catch (error) {
      console.error('Company profile update error:', error);
      res.status(500).json({ message: 'Failed to update company profile' });
    }
  });

  // Company approval by system admin
  app.put("/api/admin/companies/:id/approve", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyId = parseInt(req.params.id);
      const { action } = req.body; // 'approve' or 'reject'
      
      const status = action === 'approve' ? 'approved' : 'rejected';
      const updatedCompany = await storage.updateCompany(companyId, { status });
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: `company_${action}d`,
        entityType: 'company',
        entityId: companyId,
        details: `${action === 'approve' ? 'Approved' : 'Rejected'} company: ${updatedCompany.name}`,
      });
      
      res.json(updatedCompany);
    } catch (error) {
      console.error('Company approval error:', error);
      res.status(500).json({ message: 'Failed to process company approval' });
    }
  });

  // Delete company by system admin
  app.delete("/api/admin/companies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'System admin access required' });
      }
      
      const companyId = parseInt(req.params.id);
      const company = await storage.getCompany(companyId);
      
      if (!company) {
        return res.status(404).json({ message: 'Company not found' });
      }
      
      await storage.deleteCompany(companyId);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: null,
        action: 'company_deleted',
        entityType: 'company',
        entityId: companyId,
        details: `Deleted company: ${company.name}`,
      });
      
      res.json({ message: 'Company deleted successfully' });
    } catch (error) {
      console.error('Company deletion error:', error);
      res.status(500).json({ message: 'Failed to delete company' });
    }
  });

  // Permission Management Routes
  app.get("/api/permissions", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const permissions = await storage.getPermissions();
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permissions' });
    }
  });

  app.get("/api/permission-requests", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        const userRequests = await storage.getPermissionRequestsByUser(req.user.id);
        return res.json(userRequests);
      }
      
      let requests;
      if (req.user.role === 'system_admin') {
        requests = await storage.getPermissionRequests();
      } else {
        requests = await storage.getPermissionRequests(req.user.companyId);
      }
      
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permission requests' });
    }
  });

  app.post("/api/permission-requests", authenticateToken, async (req, res) => {
    try {
      const { permissionType, reason } = req.body;
      
      if (!permissionType || !reason) {
        return res.status(400).json({ message: 'Permission type and reason are required' });
      }
      
      const requestData = {
        userId: req.user.id,
        requestedBy: req.user.id,
        permissionType: permissionType as any,
        reason,
        companyId: req.user.companyId,
        status: 'pending' as any
      };
      
      const permissionRequest = await storage.createPermissionRequest(requestData);
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'permission_requested',
        entityType: 'permission_request',
        entityId: permissionRequest.id,
        details: `Requested permission: ${permissionRequest.permissionType}`,
      });
      
      res.status(201).json(permissionRequest);
    } catch (error) {
      console.error('Permission request creation error:', error);
      res.status(500).json({ message: 'Failed to create permission request' });
    }
  });

  app.put("/api/permission-requests/:id", authenticateToken, async (req, res) => {
    try {
      const requestId = parseInt(req.params.id);
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const updatedRequest = await storage.updatePermissionRequest(requestId, {
        ...req.body,
        reviewedBy: req.user.id,
        reviewedAt: new Date(),
      });
      
      // Log the activity
      await storage.createUserActivity({
        userId: req.user.id,
        companyId: req.user.companyId,
        action: 'permission_reviewed',
        entityType: 'permission_request',
        entityId: requestId,
        details: `${req.body.status === 'approved' ? 'Approved' : 'Rejected'} permission request`,
      });
      
      res.json(updatedRequest);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update permission request' });
    }
  });

  // User Activities/Audit Trail
  app.get("/api/activities", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        const activities = await storage.getUserActivities(undefined, req.user.id);
        return res.json(activities);
      }
      
      let activities;
      if (req.user.role === 'system_admin') {
        activities = await storage.getUserActivities();
      } else {
        activities = await storage.getUserActivities(req.user.companyId);
      }
      
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch activities' });
    }
  });

  // Public routes for signup

  // Employee profile routes
  app.get("/api/employee/profile", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      // Check if user has an employee profile first
      const profile = await storage.getEmployeeProfileByUserId(user.id);
      if (profile) {
        res.json(profile);
        return;
      }

      // Fallback to old employee record if exists
      const employee = await storage.getEmployeeByUserId(user.id);
      res.json(employee);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch employee profile' });
    }
  });

  app.put("/api/employee/profile", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const profileData = req.body;
      const userRole = user.role;
      
      // Check if user is trying to edit admin-only fields
      const adminOnlyFieldsInPayload = containsAdminOnlyFields(profileData);
      
      if (userRole === 'employee') {
        // Employees cannot edit admin-only fields (weekly off, etc.)
        if (adminOnlyFieldsInPayload.length > 0) {
          return res.status(403).json({ 
            message: `Access denied. You cannot edit admin-only fields: ${adminOnlyFieldsInPayload.join(', ')}. These fields require admin approval.`,
            adminOnlyFields: adminOnlyFieldsInPayload
          });
        }
        
        // Filter to only allow employee self-editable fields
        let allowedData = filterAllowedFields(profileData, userRole);
        
        // Normalize field names and compute age server-side
        allowedData = normalizeProfileFields(allowedData);
        
        if (Object.keys(allowedData).length === 0) {
          return res.status(400).json({ 
            message: 'No valid fields to update. You can only edit personal information.',
            allowedFields: EMPLOYEE_SELF_EDITABLE_FIELDS
          });
        }
        
        // Get current employee profile to find employeeId
        const employeeProfile = await storage.getEmployeeProfileByUserId(user.id);
        if (!employeeProfile) {
          return res.status(404).json({ message: 'Employee profile not found' });
        }
        
        // For change request system, we need to check if there's a company employee record
        const employee = await storage.getEmployeeByUserId(user.id);
        
        // If no company employee record exists, directly update the profile (self-service scenario)
        if (!employee) {
          // Direct update for self-service employees without company association
          const updatedProfile = await storage.updateEmployeeProfile(user.id, allowedData);
          
          // Log user activity only if user has a valid companyId
          if (user.companyId) {
            try {
              await storage.createUserActivity({
                userId: user.id,
                companyId: user.companyId,
                action: 'employee_self_service_update',
                entityType: 'employee_profile',
                entityId: employeeProfile.id,
                details: `Employee self-service updated profile fields: ${Object.keys(allowedData).join(', ')}`,
                ipAddress: req.ip,
                userAgent: req.get('User-Agent')
              });
            } catch (activityLogError) {
              // Silently fail activity logging - profile update is what matters
              console.log('Failed to log user activity:', activityLogError);
            }
          }
          
          return res.json({
            message: 'Profile updated successfully',
            profile: updatedProfile,
            updatedFields: Object.keys(allowedData)
          });
        }
        
        // If company employee exists, create change request for approval
        const changeRequest = await storage.createChangeRequest({
          companyId: user.companyId,
          employeeId: employee.id,
          resource: 'employee_profile',
          changes: JSON.stringify(allowedData),
          requestedBy: user.id,
          status: 'pending'
        });
        
        // Log user activity
        await storage.createUserActivity({
          userId: user.id,
          companyId: user.companyId,
          action: 'employee_profile_change_request',
          entityType: 'change_request',
          entityId: changeRequest.id,
          details: `Employee requested profile changes: ${Object.keys(allowedData).join(', ')}`,
          ipAddress: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        return res.status(202).json({ 
          message: 'Profile update request submitted for admin approval',
          changeRequestId: changeRequest.id,
          requestedChanges: allowedData,
          status: 'pending_approval'
        });
        
      } else if (userRole === 'admin' || userRole === 'system_admin') {
        // Admins can edit all fields directly (including weekly off)
        let allowedData = filterAllowedFields(profileData, userRole);
        
        // Normalize field names and compute age server-side
        allowedData = normalizeProfileFields(allowedData);
        
        if (Object.keys(allowedData).length === 0) {
          return res.status(400).json({ message: 'No valid fields to update' });
        }
        
        // Direct update for admins
        const updatedProfile = await storage.updateEmployeeProfile(user.id, allowedData);
        
        // Log admin activity
        await storage.createUserActivity({
          userId: user.id,
          companyId: user.companyId,
          action: 'admin_profile_direct_update',
          entityType: 'employee_profile',
          entityId: user.id,
          details: `Admin directly updated profile fields: ${Object.keys(allowedData).join(', ')}`,
          ipAddress: req.ip,
          userAgent: req.get('User-Agent')
        });
        
        return res.json({
          message: 'Profile updated successfully',
          profile: updatedProfile,
          updatedFields: Object.keys(allowedData)
        });
        
      } else {
        return res.status(403).json({ message: 'Invalid user role' });
      }
      
    } catch (error) {
      console.error('Error updating employee profile:', error);
      res.status(500).json({ message: 'Failed to update employee profile', error: error.message });
    }
  });

  // KYC details routes
  app.get('/api/employee/kyc', authenticateToken, async (req, res) => {
    try {
      const profile = await storage.getEmployeeProfileByUserId(req.user!.id);
      if (!profile) {
        return res.status(404).json({ error: 'Employee profile not found' });
      }
      
      const kycDetails = await storage.getKycDetailsByProfile(profile.id);
      res.json(kycDetails || {});
    } catch (error) {
      res.status(500).json({ error: 'Failed to get KYC details' });
    }
  });

  app.put('/api/employee/kyc', authenticateToken, async (req, res) => {
    try {
      const profile = await storage.getEmployeeProfileByUserId(req.user!.id);
      if (!profile) {
        return res.status(404).json({ error: 'Employee profile not found' });
      }
      
      const kycDetails = await storage.updateKycDetails(profile.id, req.body);
      res.json(kycDetails);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update KYC details' });
    }
  });

  // Check employee status by Aadhaar after verification
  app.get("/api/employee/aadhaar-status", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      
      if (user.role !== 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      // Get employee profile and KYC details
      const profile = await storage.getEmployeeProfileByUserId(user.id);
      if (!profile) {
        return res.status(404).json({ message: 'Employee profile not found' });
      }

      const kycDetails = await storage.getKycDetailsByProfile(profile.id);
      if (!kycDetails || !kycDetails.aadharNo) {
        return res.json({
          aadhaarVerified: false,
          isEmployeeInCompany: false,
          message: 'Aadhaar verification required'
        });
      }

      // Check if employee exists in any company database by Aadhaar
      const employeeStatus = await storage.getEmployeeStatusByAadhaar(kycDetails.aadharNo);
      
      res.json({
        aadhaarVerified: true,
        isEmployeeInCompany: employeeStatus.isEmployeeInCompany,
        employeeData: employeeStatus.employeeData,
        companyData: employeeStatus.companyData,
        currentUser: user
      });
    } catch (error) {
      console.error('Aadhaar status check error:', error);
      res.status(500).json({ message: 'Failed to check employee status' });
    }
  });

  // Recruitment Management Routes
  
  // Get job applications for company
  app.get('/api/job-applications/:companyId', authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const applications = await storage.getJobApplicationsByCompany(companyId);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job applications' });
    }
  });

  // Update job application status
  app.put('/api/job-applications/:id/status', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      const application = await storage.updateJobApplicationStatus(id, status, req.user!.id);
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update application status' });
    }
  });

  // Get interviews for company
  app.get('/api/interviews/:companyId', authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const interviews = await storage.getInterviewsByCompany(companyId);
      res.json(interviews);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch interviews' });
    }
  });

  // Schedule interview
  app.post('/api/interviews', authenticateToken, async (req, res) => {
    try {
      const interviewData = req.body;
      const interview = await storage.createInterview(interviewData);
      res.status(201).json(interview);
    } catch (error) {
      res.status(500).json({ message: 'Failed to schedule interview' });
    }
  });

  // Update interview status
  app.put('/api/interviews/:id/status', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, notes } = req.body;
      
      const interview = await storage.updateInterviewStatus(id, status, notes);
      res.json(interview);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update interview status' });
    }
  });

  // Create job offer
  app.post('/api/job-offers', authenticateToken, async (req, res) => {
    try {
      const offerData = req.body;
      const offer = await storage.createJobOffer(offerData);
      res.status(201).json(offer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create job offer' });
    }
  });

  // Get job offers for company
  app.get('/api/job-offers/:companyId', authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const offers = await storage.getJobOffersByCompany(companyId);
      res.json(offers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch job offers' });
    }
  });

  // Update job offer status
  app.put('/api/job-offers/:id/status', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      const offer = await storage.updateJobOfferStatus(id, status);
      res.json(offer);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update offer status' });
    }
  });

  // Job seeker specific endpoints (bypass company access checks)
  app.get("/api/jobseeker/applications", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const applications = await storage.getJobApplicationsByEmail(user.email);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch applications' });
    }
  });

  // Employee job applications endpoints  
  app.get("/api/job-applications/my", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const applications = await storage.getJobApplicationsByEmail(user.email);
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch applications' });
    }
  });

  // Create job application (for employees)
  app.post("/api/job-applications", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      const { jobId, coverLetter } = req.body;
      
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      // Check if job exists and is active
      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ message: 'Job not found' });
      }
      
      if (job.status !== 'active') {
        return res.status(400).json({ message: 'Job is no longer active' });
      }

      // Check if already applied
      const existingApplications = await storage.getJobApplicationsByEmail(user.email);
      const alreadyApplied = existingApplications.some(app => app.jobId === jobId);
      
      if (alreadyApplied) {
        return res.status(400).json({ message: 'You have already applied for this job' });
      }

      const application = await storage.createJobApplication({
        jobId,
        applicantEmail: user.email,
        applicantName: user.username || user.email,
        coverLetter: coverLetter || '',
        status: 'pending'
      });
      
      res.status(201).json(application);
    } catch (error) {
      console.error('Error creating job application:', error);
      res.status(500).json({ message: 'Failed to submit job application' });
    }
  });

  // Get my interviews
  app.get("/api/interviews/my", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const interviews = await storage.getInterviewsByEmail(user.email);
      res.json(interviews);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch interviews' });
    }
  });

  // Download resume endpoint
  app.get("/api/employee/resume", authenticateToken, async (req, res) => {
    try {
      const user = req.user;
      if (!user) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      // Get employee profile
      const profile = await storage.getEmployeeProfileByUserId(user.id);
      if (!profile) {
        return res.status(404).json({ message: 'Profile not found' });
      }

      // Generate resume PDF
      const resumePdf = await storage.generateResumePdf(profile);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${profile.firstName}_${profile.lastName}_Resume.pdf"`);
      res.send(resumePdf);
    } catch (error) {
      console.error('Error generating resume:', error);
      res.status(500).json({ message: 'Failed to generate resume' });
    }
  });

  // Zod schemas for leave and advance requests
  const insertLeaveRequestSchema = createInsertSchema(leaveRequests).omit({
    id: true,
    employeeId: true,
    companyId: true,
    createdAt: true,
    updatedAt: true,
    appliedAt: true,
    level1ApproverId: true,
    level1ApprovedAt: true,
    level1Comments: true,
    level2ApproverId: true,
    level2ApprovedAt: true,
    level2Comments: true,
    finalApproverId: true,
    finalApprovedAt: true,
    finalComments: true,
    rejectedById: true,
    rejectedAt: true,
    rejectionReason: true
  });

  const insertAdvanceRequestSchema = createInsertSchema(advanceRequests).omit({
    id: true,
    employeeId: true,
    companyId: true,
    createdAt: true,
    updatedAt: true,
    appliedAt: true,
    level1ApproverId: true,
    level1ApprovedAt: true,
    level1Comments: true,
    level2ApproverId: true,
    level2ApprovedAt: true,
    level2Comments: true,
    finalApproverId: true,
    finalApprovedAt: true,
    finalComments: true,
    rejectedById: true,
    rejectedAt: true,
    rejectionReason: true,
    paidAmount: true,
    paidAt: true,
    paymentMethod: true,
    paymentReference: true
  });

  // Leave Request routes
  app.get('/api/leave-requests/:companyId', authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const user = req.user as { id: number; companyId: number; role: string };
      
      if (user.role !== 'system_admin' && user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      let requests;
      if (user.role === 'employee') {
        // Employees can only see their own requests
        const employee = await storage.getEmployeeByUserId(user.id);
        if (!employee) {
          return res.status(404).json({ message: 'Employee not found' });
        }
        requests = await storage.getLeaveRequestsByEmployee(employee.id);
      } else {
        // Admins and system admins can see all company requests
        requests = await storage.getLeaveRequestsByCompany(companyId);
      }

      res.json(requests);
    } catch (error) {
      console.error('Error fetching leave requests:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post('/api/leave-requests', authenticateToken, async (req, res) => {
    try {
      const user = req.user as { id: number; companyId: number; role: string };
      const requestData = insertLeaveRequestSchema.parse(req.body);
      
      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      // Create leave request
      const leaveRequest = await storage.createLeaveRequest({
        ...requestData,
        employeeId: employee.id,
        companyId: user.companyId
      });

      res.status(201).json(leaveRequest);
    } catch (error) {
      console.error('Error creating leave request:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/leave-requests/:id/approve', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.approveLeaveRequest(id, level, user.id, comments);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error approving leave request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/leave-requests/:id/reject', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { reason } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.rejectLeaveRequest(id, user.id, reason);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error rejecting leave request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Advance Request routes
  app.get('/api/advance-requests/:companyId', authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const user = req.user as { id: number; companyId: number; role: string };
      
      if (user.role !== 'system_admin' && user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      let requests;
      if (user.role === 'employee') {
        // Employees can only see their own requests
        const employee = await storage.getEmployeeByUserId(user.id);
        if (!employee) {
          return res.status(404).json({ message: 'Employee not found' });
        }
        requests = await storage.getAdvanceRequestsByEmployee(employee.id);
      } else {
        // Admins and system admins can see all company requests
        requests = await storage.getAdvanceRequestsByCompany(companyId);
      }

      res.json(requests);
    } catch (error) {
      console.error('Error fetching advance requests:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post('/api/advance-requests', authenticateToken, async (req, res) => {
    try {
      const user = req.user as { id: number; companyId: number; role: string };
      const requestData = insertAdvanceRequestSchema.parse(req.body);
      
      // Get employee record for the user
      const employee = await storage.getEmployeeByUserId(user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }

      // Create advance request
      const advanceRequest = await storage.createAdvanceRequest({
        ...requestData,
        employeeId: employee.id,
        companyId: user.companyId
      });

      res.status(201).json(advanceRequest);
    } catch (error) {
      console.error('Error creating advance request:', error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: 'Invalid request data', errors: error.errors });
      }
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/advance-requests/:id/approve', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.approveAdvanceRequest(id, level, user.id, comments);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error approving advance request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/advance-requests/:id/reject', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { reason } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.rejectAdvanceRequest(id, user.id, reason);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error rejecting advance request:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.put('/api/advance-requests/:id/mark-paid', authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { paidAmount, paymentMethod, paymentReference } = req.body;
      const user = req.user as { id: number; companyId: number; role: string };

      if (user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied' });
      }

      const updatedRequest = await storage.markAdvancePaid(id, paidAmount, paymentMethod, paymentReference);
      res.json(updatedRequest);
    } catch (error) {
      console.error('Error marking advance as paid:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Signup routes
  app.post("/api/companies/signup", async (req, res) => {
    try {
      const companyData = req.body;
      const company = await storage.createCompany({
        ...companyData,
        status: 'active',
      });
      res.status(201).json(company);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create company' });
    }
  });

  // Admin signup endpoint - Aadhaar is optional for admins
  app.post("/api/users/admin-signup", async (req, res) => {
    try {
      const { name, email, password, aadhaarNumber } = req.body;
      
      if (!name || !email || !password) {
        return res.status(400).json({ message: 'Name, email, and password are required' });
      }

      // Validate Aadhaar number format only if provided
      if (aadhaarNumber) {
        if (!/^\d{12}$/.test(aadhaarNumber)) {
          return res.status(400).json({ message: 'Aadhaar number must be exactly 12 digits' });
        }

        // Check if Aadhaar number is already registered
        const aadhaarExists = await storage.isAadhaarAlreadyRegistered(aadhaarNumber);
        if (aadhaarExists) {
          return res.status(409).json({ message: 'This Aadhaar number is already registered. Please use a different Aadhaar number or contact support if this is an error.' });
        }
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ message: 'Email already registered' });
      }

      // Create a default company for the admin (pending approval)
      const company = await storage.createCompany({
        name: `${name}'s Company`,
        email: email,
        phone: '',
        address: '',
        status: 'pending',
      });

      // Create admin user with simplified data
      const username = name.toLowerCase().replace(/\s+/g, '').substring(0, 20);
      const user = await storage.createUser({
        username,
        email,
        password,
        role: 'admin',
        companyId: company.id,
      });

      // Create employee profile for admin - split name into first/last
      const nameParts = name.trim().split(' ');
      const firstName = nameParts[0] || name;
      const lastName = nameParts.slice(1).join(' ') || '';
      
      const employeeProfile = await storage.createEmployeeProfile({
        userId: user.id,
        firstName,
        lastName,
        skills: '',
        experience: '',  
        phone: '',
        address: '',
      });

      // Create KYC details with Aadhaar number only if provided
      if (aadhaarNumber) {
        await storage.createKycDetails({
          employeeProfileId: employeeProfile.id,
          aadharNo: aadhaarNumber,
          panNo: null,
          bankAccountNo: null,
          ifscCode: null,
          uanNo: null,
          esicNo: null,
        });
      }

      // Remove password from response
      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error('Admin signup error:', error);
      res.status(500).json({ message: 'Failed to create admin account' });
    }
  });

  // Employee signup endpoint - with Aadhaar validation
  app.post("/api/users/employee-signup", async (req, res) => {
    try {
      const { name, email, password, aadhaarNumber } = req.body;
      
      if (!name || !email || !password || !aadhaarNumber) {
        return res.status(400).json({ message: 'Name, email, password, and Aadhaar number are required' });
      }

      // Validate Aadhaar number format
      if (!/^\d{12}$/.test(aadhaarNumber)) {
        return res.status(400).json({ message: 'Aadhaar number must be exactly 12 digits' });
      }

      // Check if Aadhaar number is already registered
      const aadhaarExists = await storage.isAadhaarAlreadyRegistered(aadhaarNumber);
      if (aadhaarExists) {
        return res.status(409).json({ message: 'This Aadhaar number is already registered. Please use a different Aadhaar number or contact support if this is an error.' });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(409).json({ message: 'Email already registered' });
      }
      
      // Create user without company association initially
      const username = name.toLowerCase().replace(/\s+/g, '').substring(0, 20);
      const user = await storage.createUser({
        username,
        email,
        password,
        role: 'employee',
        companyId: null, // No company association initially
      });
      
      // Create employee profile with minimal data - split name into first/last
      const nameParts = name.trim().split(' ');
      const firstName = nameParts[0] || name;
      const lastName = nameParts.slice(1).join(' ') || '';
      
      const employeeProfile = await storage.createEmployeeProfile({
        userId: user.id,
        firstName,
        lastName,
        skills: '',
        experience: '',  
        phone: '',
        address: '',
      });

      // Create KYC details with Aadhaar number
      await storage.createKycDetails({
        employeeProfileId: employeeProfile.id,
        aadharNo: aadhaarNumber,
        panNo: null,
        bankAccountNo: null,
        ifscCode: null,
        uanNo: null,
        esicNo: null,
      });
      
      // Remove password from response
      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      console.error('Employee signup error:', error);
      
      // Handle specific database constraint errors
      if (error.code === '23505') {
        if (error.constraint === 'users_email_unique') {
          return res.status(409).json({ message: 'Email already registered' });
        }
      }
      
      res.status(500).json({ message: 'Failed to create employee account' });
    }
  });

  // Payroll Routes
  app.get("/api/payroll/monthly/:companyId", authenticateToken, checkCompanyAccess, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const payrolls = await storage.getMonthlyPayrolls(companyId);
      
      // Add record count and total amount for each payroll
      const enrichedPayrolls = await Promise.all(payrolls.map(async (payroll) => {
        try {
          const records = await storage.getPayrollRecords(payroll.id);
          const totalAmount = records.reduce((sum, record) => {
            const netSalary = parseFloat(record.netSalary || '0');
            return sum + (isNaN(netSalary) ? 0 : netSalary);
          }, 0);
          return {
            ...payroll,
            recordCount: records.length,
            totalAmount
          };
        } catch (error) {
          console.error(`Error processing payroll ${payroll.id}:`, error);
          return {
            ...payroll,
            recordCount: 0,
            totalAmount: 0
          };
        }
      }));
      
      res.json(enrichedPayrolls);
    } catch (error: any) {
      console.error('Error fetching monthly payrolls:', error);
      res.status(500).json({ message: error.message || 'Failed to fetch payrolls' });
    }
  });

  app.get("/api/payroll/records/:payrollId", authenticateToken, async (req, res) => {
    try {
      const payrollId = parseInt(req.params.payrollId);
      
      // First verify the payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      // Check company access for non-system admins
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      const records = await storage.getPayrollRecords(payrollId);
      
      // Enrich records with employee details
      const enrichedRecords = await Promise.all(records.map(async (record) => {
        const employee = await storage.getEmployee(record.employeeId);
        const departments = await storage.getDepartmentsByCompany(payroll.companyId);
        const department = departments.find(d => d.id === employee?.departmentId);
        
        return {
          ...record,
          employeeName: employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown',
          employeeCode: employee?.employeeId || 'N/A',
          department: department?.name || 'N/A'
        };
      }));
      
      res.json(enrichedRecords);
    } catch (error: any) {
      console.error('Error fetching payroll records:', error);
      res.status(500).json({ message: error.message || 'Failed to fetch payroll records' });
    }
  });

  app.post("/api/payroll/generate", authenticateToken, async (req, res) => {
    try {
      const { month, year } = req.body;
      const companyId = req.user.companyId;
      const generatedBy = req.user.id;
      
      if (!month || !year || !companyId) {
        return res.status(400).json({ message: 'Month, year, and company ID are required' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot generate payroll' });
      }
      
      // Use new automated PayrollService instead of legacy method
      const { PayrollService } = await import('./PayrollService');
      const payroll = await PayrollService.generate(companyId, year, month, generatedBy);
      res.json(payroll);
    } catch (error: any) {
      console.error('Error generating payroll:', error);
      res.status(500).json({ message: error.message || 'Failed to generate payroll' });
    }
  });

  app.put("/api/payroll/finalize/:payrollId", authenticateToken, async (req, res) => {
    try {
      const payrollId = parseInt(req.params.payrollId);
      const finalizedBy = req.user.id;
      
      // Verify payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot finalize payroll' });
      }
      
      if (payroll.status === 'finalized') {
        return res.status(400).json({ message: 'Payroll is already finalized' });
      }
      
      const finalizedPayroll = await storage.finalizePayroll(payrollId, finalizedBy);
      res.json(finalizedPayroll);
    } catch (error: any) {
      console.error('Error finalizing payroll:', error);
      res.status(500).json({ message: error.message || 'Failed to finalize payroll' });
    }
  });

  // Delete monthly payroll (only for draft status)
  app.delete("/api/payroll/monthly/:payrollId", authenticateToken, async (req, res) => {
    try {
      const payrollId = parseInt(req.params.payrollId);
      
      // Verify payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot delete payroll' });
      }
      
      if (payroll.status === 'finalized') {
        return res.status(400).json({ message: 'Cannot delete finalized payroll' });
      }
      
      const deleted = await storage.deleteMonthlyPayroll(payrollId);
      if (!deleted) {
        return res.status(404).json({ message: 'Payroll not found or could not be deleted' });
      }
      
      res.status(204).end();
    } catch (error: any) {
      console.error('Error deleting payroll:', error);
      res.status(500).json({ message: error.message || 'Failed to delete payroll' });
    }
  });

  app.put("/api/payroll/payment/:recordId", authenticateToken, async (req, res) => {
    try {
      const recordId = parseInt(req.params.recordId);
      const { status, amount, method, reference } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: 'Payment status is required' });
      }
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Employees cannot update payment status' });
      }
      
      const updatedRecord = await storage.updatePaymentStatus(recordId, status, amount, method, reference);
      res.json(updatedRecord);
    } catch (error: any) {
      console.error('Error updating payment status:', error);
      res.status(500).json({ message: error.message || 'Failed to update payment status' });
    }
  });

  // Enhanced Permission Management API Routes
  
  // Get all permissions with filtering
  app.get("/api/permissions/enhanced", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const { category, module } = req.query;
      let permissions;
      
      if (category) {
        permissions = await storage.getPermissionsByCategory(category as string);
      } else if (module) {
        permissions = await storage.getPermissionsByModule(module as string);
      } else {
        permissions = await storage.getAllPermissions();
      }
      
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permissions' });
    }
  });

  // Create new permission
  app.post("/api/permissions/enhanced", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can create permissions' });
      }
      
      const permission = await storage.createPermission(req.body);
      res.status(201).json(permission);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create permission' });
    }
  });

  // Update permission
  app.put("/api/permissions/enhanced/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can update permissions' });
      }
      
      const id = parseInt(req.params.id);
      const permission = await storage.updatePermission(id, req.body);
      res.json(permission);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update permission' });
    }
  });

  // Delete permission
  app.delete("/api/permissions/enhanced/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can delete permissions' });
      }
      
      const id = parseInt(req.params.id);
      await storage.deletePermission(id);
      res.json({ message: 'Permission deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete permission' });
    }
  });

  // User Permission Routes
  
  // Get user permissions
  app.get("/api/user-permissions/:userId", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const companyId = req.user.companyId;
      
      if (req.user.role === 'employee' && req.user.id !== userId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const permissions = await storage.getUserPermissions(userId, companyId);
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch user permissions' });
    }
  });

  // Check user permission
  app.get("/api/user-permissions/:userId/check/:permissionName", authenticateToken, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const permissionName = req.params.permissionName;
      const companyId = req.user.companyId;
      
      if (req.user.role === 'employee' && req.user.id !== userId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const hasPermission = await storage.hasUserPermission(userId, permissionName, companyId);
      res.json({ hasPermission });
    } catch (error) {
      res.status(500).json({ message: 'Failed to check user permission' });
    }
  });

  // Grant user permission
  app.post("/api/user-permissions", authenticateToken, async (req, res) => {
    try {
      console.log('Grant permission request received:', req.body);
      console.log('User making request:', req.user);
      
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const grantData = {
        ...req.body,
        grantedBy: req.user.id,
        companyId: req.user.companyId,
        isActive: true,
        grantedAt: new Date()
      };
      
      console.log('About to grant permission with data:', grantData);
      const userPermission = await storage.grantUserPermission(grantData);
      console.log('Permission granted successfully:', userPermission);
      
      res.status(201).json(userPermission);
    } catch (error) {
      console.error('Failed to grant permission - ERROR:', error);
      res.status(500).json({ message: 'Failed to grant permission', error: error.message });
    }
  });

  // Revoke user permission
  app.delete("/api/user-permissions/:userId/:permissionId", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const userId = parseInt(req.params.userId);
      const permissionId = parseInt(req.params.permissionId);
      const companyId = req.user.companyId;
      
      await storage.revokeUserPermission(userId, permissionId, companyId);
      res.json({ message: 'Permission revoked successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to revoke permission' });
    }
  });

  // Enhanced Permission Request Routes
  
  // Get permission requests with enhanced filtering
  app.get("/api/permission-requests/enhanced", authenticateToken, async (req, res) => {
    try {
      // Use basic permission requests for now
      const requests = await storage.getPermissionRequests(req.user.companyId);
      res.json(requests);
    } catch (error) {
      console.error('Permission requests error:', error);
      res.status(500).json({ message: 'Failed to fetch permission requests' });
    }
  });

  // Create enhanced permission request
  app.post("/api/permission-requests/enhanced", authenticateToken, async (req, res) => {
    try {
      const request = await storage.createPermissionRequestEnhanced({
        ...req.body,
        userId: req.user.id,
        companyId: req.user.companyId
      });
      
      res.status(201).json(request);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create permission request' });
    }
  });

  // Approve permission request by level
  app.put("/api/permission-requests/enhanced/:id/approve", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      
      const request = await storage.approvePermissionRequestLevel(id, req.user.id, level, comments);
      res.json(request);
    } catch (error) {
      res.status(500).json({ message: 'Failed to approve permission request' });
    }
  });

  // Reject permission request by level
  app.put("/api/permission-requests/enhanced/:id/reject", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const id = parseInt(req.params.id);
      const { level, comments } = req.body;
      
      const request = await storage.rejectPermissionRequestLevel(id, req.user.id, level, comments);
      res.json(request);
    } catch (error) {
      res.status(500).json({ message: 'Failed to reject permission request' });
    }
  });

  // Role Permission Routes
  
  // Get role permissions
  app.get("/api/role-permissions/:role", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const role = req.params.role;
      const companyId = req.user.role === 'system_admin' ? undefined : req.user.companyId;
      
      const permissions = await storage.getRolePermissionsEnhanced(role, companyId);
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch role permissions' });
    }
  });

  // Assign role permission
  app.post("/api/role-permissions", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const rolePermission = await storage.assignRolePermission({
        ...req.body,
        companyId: req.user.role === 'system_admin' ? req.body.companyId : req.user.companyId
      });
      
      res.status(201).json(rolePermission);
    } catch (error) {
      res.status(500).json({ message: 'Failed to assign role permission' });
    }
  });

  // Remove role permission
  app.delete("/api/role-permissions/:role/:permissionId", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const role = req.params.role;
      const permissionId = parseInt(req.params.permissionId);
      const companyId = req.user.role === 'system_admin' ? undefined : req.user.companyId;
      
      await storage.removeRolePermission(role, permissionId, companyId);
      res.json({ message: 'Role permission removed successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to remove role permission' });
    }
  });

  // Permission Template Routes
  
  // Get permission templates
  app.get("/api/permission-templates", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const { role } = req.query;
      const templates = await storage.getPermissionTemplates(role as string);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch permission templates' });
    }
  });

  // Create permission template
  app.post("/api/permission-templates", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can create templates' });
      }
      
      const template = await storage.createPermissionTemplate(req.body);
      res.status(201).json(template);
    } catch (error) {
      res.status(500).json({ message: 'Failed to create permission template' });
    }
  });

  // Update permission template
  app.put("/api/permission-templates/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can update templates' });
      }
      
      const id = parseInt(req.params.id);
      const template = await storage.updatePermissionTemplate(id, req.body);
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update permission template' });
    }
  });

  // Delete permission template
  app.delete("/api/permission-templates/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role !== 'system_admin') {
        return res.status(403).json({ message: 'Only system admins can delete templates' });
      }
      
      const id = parseInt(req.params.id);
      await storage.deletePermissionTemplate(id);
      res.json({ message: 'Permission template deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete permission template' });
    }
  });

  // Apply permission template
  app.post("/api/permission-templates/:id/apply", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      
      const templateId = parseInt(req.params.id);
      const { userId } = req.body;
      
      const permissions = await storage.applyPermissionTemplate(
        templateId, 
        userId, 
        req.user.companyId, 
        req.user.id
      );
      
      res.json(permissions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to apply permission template' });
    }
  });

  // Company Settings API Routes
  // Biometric Machines
  app.get("/api/biometric-machines/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const machines = await storage.getBiometricMachinesByCompany(companyId);
      res.json(machines);
    } catch (error) {
      console.error('Error fetching biometric machines:', error);
      res.status(500).json({ message: 'Failed to fetch biometric machines' });
    }
  });

  app.post("/api/biometric-machines", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const machineData = { ...req.body, companyId: req.user.companyId };
      const machine = await storage.createBiometricMachine(machineData);
      res.json(machine);
    } catch (error) {
      console.error('Error creating biometric machine:', error);
      res.status(500).json({ message: 'Failed to create biometric machine' });
    }
  });

  app.put("/api/biometric-machines/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const machine = await storage.updateBiometricMachine(id, req.body);
      res.json(machine);
    } catch (error) {
      console.error('Error updating biometric machine:', error);
      res.status(500).json({ message: 'Failed to update biometric machine' });
    }
  });

  app.delete("/api/biometric-machines/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteBiometricMachine(id);
      res.json({ message: 'Biometric machine deleted' });
    } catch (error) {
      console.error('Error deleting biometric machine:', error);
      res.status(500).json({ message: 'Failed to delete biometric machine' });
    }
  });

  // Machine Data Import Routes
  app.post("/api/biometric-machines/:machineId/import", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }

      const machineId = parseInt(req.params.machineId);
      const { startDate, endDate, data } = req.body;

      // Verify machine exists and user has access
      const machine = await storage.getBiometricMachine(machineId);
      if (!machine) {
        return res.status(404).json({ message: 'Biometric machine not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== machine.companyId) {
        return res.status(403).json({ message: 'Access denied to this machine' });
      }

      // Validate import data structure
      if (!Array.isArray(data) || data.length === 0) {
        return res.status(400).json({ message: 'Import data must be a non-empty array' });
      }

      // Process and validate each attendance record
      const processedRecords = [];
      const errors = [];
      
      for (let i = 0; i < data.length; i++) {
        const record = data[i];
        
        try {
          // Validate required fields
          if (!record.employeeId || !record.date) {
            errors.push(`Record ${i + 1}: Missing required fields (employeeId, date)`);
            continue;
          }

          // Verify employee exists and belongs to company
          const employee = await storage.getEmployee(record.employeeId);
          if (!employee || employee.companyId !== machine.companyId) {
            errors.push(`Record ${i + 1}: Employee ${record.employeeId} not found or not in company`);
            continue;
          }

          // Parse and validate timestamps
          const attendanceDate = new Date(record.date);
          const checkIn = record.checkIn ? new Date(record.checkIn) : null;
          const checkOut = record.checkOut ? new Date(record.checkOut) : null;

          // Calculate hours worked if both check-in and check-out exist
          let hoursWorked = 0;
          if (checkIn && checkOut) {
            hoursWorked = (checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60);
          }

          // Determine attendance status
          let status = 'absent';
          let isPresent = false;
          if (checkIn) {
            status = 'present';
            isPresent = true;
            
            // Check for late arrival (after 9:30 AM)
            const checkInTime = checkIn.getHours() * 60 + checkIn.getMinutes();
            if (checkInTime > 570) { // 9:30 AM = 570 minutes
              status = 'late';
            }
            
            // Check for early leave (before 6:00 PM and less than 8 hours)
            if (checkOut && hoursWorked < 8) {
              status = 'early_leave';
            }
            
            // Check for half day (less than 4 hours)
            if (hoursWorked > 0 && hoursWorked < 4) {
              status = 'half_day';
            }
          }

          const processedRecord = {
            employeeId: employee.id,
            companyId: machine.companyId,
            date: attendanceDate.toISOString().split('T')[0],
            checkIn: checkIn,
            checkOut: checkOut,
            hoursWorked: hoursWorked.toFixed(2),
            status: status,
            isPresent: isPresent,
            verificationType: 'biometric',
            deviceInfo: `${machine.model || 'Biometric Machine'} - ${machine.serialNumber}`,
            ipAddress: machine.ipAddress,
            notes: `Imported from machine ${machine.serialNumber} on ${new Date().toISOString()}`,
            faceVerified: record.faceVerified || false,
            locationVerified: true, // Machine location is trusted
            workLocation: machine.location || 'Unknown'
          };

          processedRecords.push(processedRecord);

        } catch (error) {
          errors.push(`Record ${i + 1}: Processing error - ${error.message}`);
        }
      }

      if (errors.length > 0 && processedRecords.length === 0) {
        return res.status(400).json({ 
          message: 'No valid records to import',
          errors: errors
        });
      }

      // Import the processed records
      const importResults = {
        imported: 0,
        updated: 0,
        skipped: 0,
        errors: []
      };

      for (const record of processedRecords) {
        try {
          // Check if attendance record already exists for this employee and date
          const existingAttendance = await storage.getAttendanceByEmployeeAndDate(
            record.employeeId, 
            record.date
          );

          if (existingAttendance) {
            // Update existing record if machine data is more recent
            if (record.checkIn || record.checkOut) {
              await storage.updateAttendance(existingAttendance.id, record);
              importResults.updated++;
            } else {
              importResults.skipped++;
            }
          } else {
            // Create new attendance record
            await storage.createAttendance(record);
            importResults.imported++;
          }
        } catch (error) {
          importResults.errors.push(`Failed to save record for employee ${record.employeeId}: ${error.message}`);
        }
      }

      // Update machine last sync time
      await storage.updateBiometricMachine(machineId, { 
        lastSync: new Date(),
        status: 'active'
      });

      res.json({
        message: 'Data import completed',
        machine: {
          id: machine.id,
          serialNumber: machine.serialNumber,
          location: machine.location
        },
        summary: {
          totalRecords: data.length,
          processed: processedRecords.length,
          imported: importResults.imported,
          updated: importResults.updated,
          skipped: importResults.skipped,
          errorCount: errors.length + importResults.errors.length
        },
        validationErrors: errors,
        importErrors: importResults.errors
      });

    } catch (error) {
      console.error('Machine data import error:', error);
      res.status(500).json({ message: 'Failed to import machine data' });
    }
  });

  // Get import history for a machine
  app.get("/api/biometric-machines/:machineId/imports", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }

      const machineId = parseInt(req.params.machineId);
      
      // Verify machine exists and user has access
      const machine = await storage.getBiometricMachine(machineId);
      if (!machine) {
        return res.status(404).json({ message: 'Biometric machine not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== machine.companyId) {
        return res.status(403).json({ message: 'Access denied to this machine' });
      }

      // Get recent attendance records from this machine
      const recentImports = await storage.getAttendanceByDevice(machine.serialNumber, 30); // Last 30 days

      res.json({
        machine: {
          id: machine.id,
          serialNumber: machine.serialNumber,
          location: machine.location,
          lastSync: machine.lastSync,
          status: machine.status
        },
        recentImports: recentImports.length,
        lastImportDate: recentImports.length > 0 ? recentImports[0].createdAt : null
      });

    } catch (error) {
      console.error('Get machine import history error:', error);
      res.status(500).json({ message: 'Failed to get import history' });
    }
  });

  // Sync all active machines (bulk import endpoint)
  app.post("/api/biometric-machines/sync-all", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }

      const companyId = req.user.companyId;
      const { startDate, endDate } = req.body;

      // Get all active machines for the company
      const machines = await storage.getBiometricMachinesByCompany(companyId);
      const activeMachines = machines.filter(m => m.status === 'active');

      if (activeMachines.length === 0) {
        return res.status(400).json({ message: 'No active biometric machines found' });
      }

      const syncResults = {
        totalMachines: activeMachines.length,
        successfulSyncs: 0,
        failedSyncs: 0,
        machineResults: []
      };

      // Attempt to connect to each machine and pull attendance logs
      for (const machine of activeMachines) {
        try {
          const syncResult = await syncMachineData(machine, { startDate, endDate });
          syncResults.machineResults.push({
            machineId: machine.id,
            serialNumber: machine.serialNumber,
            location: machine.location,
            status: syncResult.success ? 'success' : 'failed',
            message: syncResult.message,
            recordsImported: syncResult.recordsImported || 0,
            lastSync: new Date().toISOString()
          });
          
          if (syncResult.success) {
            syncResults.successfulSyncs++;
            // Update machine's last sync time
            await storage.updateBiometricMachine(machine.id, { 
              lastSync: new Date() 
            });
          } else {
            syncResults.failedSyncs++;
          }
        } catch (error) {
          console.error(`Error syncing machine ${machine.serialNumber}:`, error);
          syncResults.machineResults.push({
            machineId: machine.id,
            serialNumber: machine.serialNumber,
            location: machine.location,
            status: 'failed',
            error: error.message || 'Connection failed'
          });
          syncResults.failedSyncs++;
        }
      }

      res.json({
        message: 'Machine data sync completed',
        results: syncResults
      });

    } catch (error) {
      console.error('Sync all machines error:', error);
      res.status(500).json({ message: 'Failed to sync machines' });
    }
  });

  // Check biometric machine connection status
  app.get("/api/biometric-machines/:machineId/status", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }

      const machineId = parseInt(req.params.machineId);

      // Verify machine exists and user has access
      const machine = await storage.getBiometricMachine(machineId);
      if (!machine) {
        return res.status(404).json({ message: 'Biometric machine not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== machine.companyId) {
        return res.status(403).json({ message: 'Access denied to this machine' });
      }

      // Check machine connectivity
      const connectionStatus = await checkMachineConnection(machine);
      
      res.json({
        machine: {
          id: machine.id,
          serialNumber: machine.serialNumber,
          ipAddress: machine.ipAddress,
          port: machine.port,
          location: machine.location,
          model: machine.model,
          status: machine.status,
          lastSync: machine.lastSync
        },
        connectivity: connectionStatus
      });

    } catch (error) {
      console.error('Machine status check error:', error);
      res.status(500).json({ message: 'Failed to check machine status' });
    }
  });

  // Test biometric machine connection
  app.post("/api/biometric-machines/:machineId/test-connection", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }

      const machineId = parseInt(req.params.machineId);
      const machine = await storage.getBiometricMachine(machineId);
      
      if (!machine) {
        return res.status(404).json({ message: 'Machine not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== machine.companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const startTime = Date.now();
      
      try {
        await new Promise((resolve, reject) => {
          const socket = new Socket();
          const timeout = setTimeout(() => {
            socket.destroy();
            reject(new Error('Connection timeout'));
          }, 5000);

          socket.connect(machine.port || 4370, machine.ipAddress, () => {
            clearTimeout(timeout);
            socket.end();
            resolve(null);
          });

          socket.on('error', (error) => {
            clearTimeout(timeout);
            reject(error);
          });
        });

        const latency = Date.now() - startTime;
        res.json({
          success: true,
          latency: `${latency}ms`,
          message: `Connection successful to ${machine.ipAddress}:${machine.port}`
        });

      } catch (error: any) {
        res.status(502).json({
          success: false,
          message: `Unable to reach device: ${error.message}`
        });
      }

    } catch (error) {
      console.error('Test connection error:', error);
      res.status(500).json({ message: 'Failed to test connection' });
    }
  });

  // Import employee list from biometric machine
  app.post("/api/biometric-machines/:machineId/import-employees", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }

      const machineId = parseInt(req.params.machineId);

      // Verify machine exists and user has access
      const machine = await storage.getBiometricMachine(machineId);
      if (!machine) {
        return res.status(404).json({ message: 'Biometric machine not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== machine.companyId) {
        return res.status(403).json({ message: 'Access denied to this machine' });
      }

      if (machine.status !== 'active') {
        return res.status(400).json({ 
          message: `Machine ${machine.serialNumber} is not active. Status: ${machine.status}` 
        });
      }

      // Import employee list from machine
      const importResult = await importEmployeeListFromMachine(machine);
      
      res.json({
        message: importResult.message,
        success: importResult.success,
        machine: {
          id: machine.id,
          serialNumber: machine.serialNumber,
          location: machine.location,
          ipAddress: machine.ipAddress,
          port: machine.port
        },
        employeesFound: importResult.employeesFound || 0,
        employeesImported: importResult.employeesImported || 0,
        employees: importResult.employees || []
      });

    } catch (error) {
      console.error('Employee import error:', error);
      res.status(500).json({ message: 'Failed to import employee list from machine' });
    }
  });

  // Sync individual machine data
  app.post("/api/biometric-machines/:machineId/sync", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }

      const machineId = parseInt(req.params.machineId);
      const { startDate, endDate } = req.body;

      // Verify machine exists and user has access
      const machine = await storage.getBiometricMachine(machineId);
      if (!machine) {
        return res.status(404).json({ message: 'Biometric machine not found' });
      }

      if (req.user.role !== 'system_admin' && req.user.companyId !== machine.companyId) {
        return res.status(403).json({ message: 'Access denied to this machine' });
      }

      if (machine.status !== 'active') {
        return res.status(400).json({ 
          message: `Machine ${machine.serialNumber} is not active. Status: ${machine.status}` 
        });
      }

      // Sync the machine data
      const syncResult = await syncMachineData(machine, { startDate, endDate });
      
      if (syncResult.success) {
        // Update machine's last sync time
        await storage.updateBiometricMachine(machine.id, { 
          lastSync: new Date() 
        });
        
        // Log integration with daily attendance system
        if (syncResult.recordsImported > 0) {
          console.log(`🔄 Machine sync completed - ${syncResult.recordsImported} records imported. Daily logs will automatically reflect new attendance data from machine ${machine.serialNumber}`);
        }
      }

      res.json({
        message: syncResult.message,
        success: syncResult.success,
        machine: {
          id: machine.id,
          serialNumber: machine.serialNumber,
          location: machine.location,
          lastSync: syncResult.success ? new Date().toISOString() : machine.lastSync
        },
        recordsImported: syncResult.recordsImported || 0
      });

    } catch (error) {
      console.error('Individual machine sync error:', error);
      res.status(500).json({ message: 'Failed to sync machine data' });
    }
  });

  // Holidays
  app.get("/api/holidays/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const holidays = await storage.getHolidaysByCompany(companyId);
      res.json(holidays);
    } catch (error) {
      console.error('Error fetching holidays:', error);
      res.status(500).json({ message: 'Failed to fetch holidays' });
    }
  });

  app.post("/api/holidays", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const holidayData = { ...req.body, companyId: req.user.companyId };
      const holiday = await storage.createHoliday(holidayData);
      res.json(holiday);
    } catch (error) {
      console.error('Error creating holiday:', error);
      res.status(500).json({ message: 'Failed to create holiday' });
    }
  });

  app.put("/api/holidays/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const holiday = await storage.updateHoliday(id, req.body);
      res.json(holiday);
    } catch (error) {
      console.error('Error updating holiday:', error);
      res.status(500).json({ message: 'Failed to update holiday' });
    }
  });

  app.delete("/api/holidays/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteHoliday(id);
      res.json({ message: 'Holiday deleted' });
    } catch (error) {
      console.error('Error deleting holiday:', error);
      res.status(500).json({ message: 'Failed to delete holiday' });
    }
  });

  // Shifts Management - Company Settings
  app.get("/api/shifts/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const shifts = await storage.getShiftsByCompany(companyId);
      res.json(shifts);
    } catch (error) {
      console.error('Error fetching shifts:', error);
      res.status(500).json({ message: 'Failed to fetch shifts' });
    }
  });

  app.post("/api/shifts", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const shiftData = { ...req.body, companyId: req.user.companyId };
      const shift = await storage.createShift(shiftData);
      res.json(shift);
    } catch (error) {
      console.error('Error creating shift:', error);
      res.status(500).json({ message: 'Failed to create shift' });
    }
  });

  app.put("/api/shifts/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      
      // Verify shift belongs to user's company
      const existingShift = await storage.getShiftById(id);
      if (!existingShift) {
        return res.status(404).json({ message: 'Shift not found' });
      }
      if (req.user.role !== 'system_admin' && existingShift.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Access denied to this shift' });
      }
      
      // Remove companyId from body to prevent tampering
      const { companyId, ...updateData } = req.body;
      const shift = await storage.updateShift(id, updateData);
      res.json(shift);
    } catch (error) {
      console.error('Error updating shift:', error);
      res.status(500).json({ message: 'Failed to update shift' });
    }
  });

  app.delete("/api/shifts/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      
      // Verify shift belongs to user's company
      const existingShift = await storage.getShiftById(id);
      if (!existingShift) {
        return res.status(404).json({ message: 'Shift not found' });
      }
      if (req.user.role !== 'system_admin' && existingShift.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Access denied to this shift' });
      }
      
      await storage.deleteShift(id);
      res.json({ message: 'Shift deleted' });
    } catch (error) {
      console.error('Error deleting shift:', error);
      res.status(500).json({ message: 'Failed to delete shift' });
    }
  });

  // Employee Shift Assignments
  app.get("/api/employee-shifts/:employeeId", authenticateToken, async (req, res) => {
    try {
      const employeeId = parseInt(req.params.employeeId);
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ message: 'Employee not found' });
      }
      if (req.user.role !== 'system_admin' && employee.companyId !== req.user.companyId) {
        return res.status(403).json({ message: 'Access denied to this employee' });
      }
      
      const employeeShifts = await storage.getEmployeeShifts(employeeId);
      res.json(employeeShifts);
    } catch (error) {
      console.error('Error fetching employee shifts:', error);
      res.status(500).json({ message: 'Failed to fetch employee shifts' });
    }
  });

  app.post("/api/employee-shifts", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const employeeShiftData = { ...req.body, companyId: req.user.companyId };
      const employeeShift = await storage.assignEmployeeShift(employeeShiftData);
      res.json(employeeShift);
    } catch (error) {
      console.error('Error assigning employee shift:', error);
      res.status(500).json({ message: 'Failed to assign employee shift' });
    }
  });

  app.put("/api/employee-shifts/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const employeeShift = await storage.updateEmployeeShift(id, req.body);
      res.json(employeeShift);
    } catch (error) {
      console.error('Error updating employee shift:', error);
      res.status(500).json({ message: 'Failed to update employee shift' });
    }
  });

  app.delete("/api/employee-shifts/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteEmployeeShift(id);
      res.json({ message: 'Employee shift assignment deleted' });
    } catch (error) {
      console.error('Error deleting employee shift:', error);
      res.status(500).json({ message: 'Failed to delete employee shift' });
    }
  });

  // Leave Policies
  app.get("/api/leave-policies/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const policies = await storage.getLeavePoliciesByCompany(companyId);
      res.json(policies);
    } catch (error) {
      console.error('Error fetching leave policies:', error);
      res.status(500).json({ message: 'Failed to fetch leave policies' });
    }
  });

  app.post("/api/leave-policies", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const policyData = { ...req.body, companyId: req.user.companyId };
      const policy = await storage.createLeavePolicy(policyData);
      res.json(policy);
    } catch (error) {
      console.error('Error creating leave policy:', error);
      res.status(500).json({ message: 'Failed to create leave policy' });
    }
  });

  app.put("/api/leave-policies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const policy = await storage.updateLeavePolicy(id, req.body);
      res.json(policy);
    } catch (error) {
      console.error('Error updating leave policy:', error);
      res.status(500).json({ message: 'Failed to update leave policy' });
    }
  });

  app.delete("/api/leave-policies/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteLeavePolicy(id);
      res.json({ message: 'Leave policy deleted' });
    } catch (error) {
      console.error('Error deleting leave policy:', error);
      res.status(500).json({ message: 'Failed to delete leave policy' });
    }
  });

  // Designations
  app.get("/api/designations/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const designations = await storage.getDesignationsByCompany(companyId);
      res.json(designations);
    } catch (error) {
      console.error('Error fetching designations:', error);
      res.status(500).json({ message: 'Failed to fetch designations' });
    }
  });

  app.post("/api/designations", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const designationData = { ...req.body, companyId: req.user.companyId };
      const designation = await storage.createDesignation(designationData);
      res.json(designation);
    } catch (error) {
      console.error('Error creating designation:', error);
      res.status(500).json({ message: 'Failed to create designation' });
    }
  });

  app.put("/api/designations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const designation = await storage.updateDesignation(id, req.body);
      res.json(designation);
    } catch (error) {
      console.error('Error updating designation:', error);
      res.status(500).json({ message: 'Failed to update designation' });
    }
  });

  app.delete("/api/designations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteDesignation(id);
      res.json({ message: 'Designation deleted' });
    } catch (error) {
      console.error('Error deleting designation:', error);
      res.status(500).json({ message: 'Failed to delete designation' });
    }
  });

  // Branches
  app.get("/api/branches/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const branches = await storage.getBranchesByCompany(companyId);
      res.json(branches);
    } catch (error) {
      console.error('Error fetching branches:', error);
      res.status(500).json({ message: 'Failed to fetch branches' });
    }
  });

  app.post("/api/branches", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const branchData = { ...req.body, companyId: req.user.companyId };
      const branch = await storage.createBranch(branchData);
      res.json(branch);
    } catch (error) {
      console.error('Error creating branch:', error);
      res.status(500).json({ message: 'Failed to create branch' });
    }
  });

  app.put("/api/branches/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const branch = await storage.updateBranch(id, req.body);
      res.json(branch);
    } catch (error) {
      console.error('Error updating branch:', error);
      res.status(500).json({ message: 'Failed to update branch' });
    }
  });

  app.delete("/api/branches/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteBranch(id);
      res.json({ message: 'Branch deleted' });
    } catch (error) {
      console.error('Error deleting branch:', error);
      res.status(500).json({ message: 'Failed to delete branch' });
    }
  });

  // Locations
  app.get("/api/locations/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const locations = await storage.getLocationsByCompany(companyId);
      res.json(locations);
    } catch (error) {
      console.error('Error fetching locations:', error);
      res.status(500).json({ message: 'Failed to fetch locations' });
    }
  });

  app.post("/api/locations", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const locationData = { ...req.body, companyId: req.user.companyId };
      const location = await storage.createLocation(locationData);
      res.json(location);
    } catch (error) {
      console.error('Error creating location:', error);
      res.status(500).json({ message: 'Failed to create location' });
    }
  });

  app.put("/api/locations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const location = await storage.updateLocation(id, req.body);
      res.json(location);
    } catch (error) {
      console.error('Error updating location:', error);
      res.status(500).json({ message: 'Failed to update location' });
    }
  });

  app.delete("/api/locations/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteLocation(id);
      res.json({ message: 'Location deleted' });
    } catch (error) {
      console.error('Error deleting location:', error);
      res.status(500).json({ message: 'Failed to delete location' });
    }
  });

  // Cost Centers
  app.get("/api/cost-centers/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const costCenters = await storage.getCostCentersByCompany(companyId);
      res.json(costCenters);
    } catch (error) {
      console.error('Error fetching cost centers:', error);
      res.status(500).json({ message: 'Failed to fetch cost centers' });
    }
  });

  app.post("/api/cost-centers", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const costCenterData = { ...req.body, companyId: req.user.companyId };
      const costCenter = await storage.createCostCenter(costCenterData);
      res.json(costCenter);
    } catch (error) {
      console.error('Error creating cost center:', error);
      res.status(500).json({ message: 'Failed to create cost center' });
    }
  });

  app.put("/api/cost-centers/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const costCenter = await storage.updateCostCenter(id, req.body);
      res.json(costCenter);
    } catch (error) {
      console.error('Error updating cost center:', error);
      res.status(500).json({ message: 'Failed to update cost center' });
    }
  });

  app.delete("/api/cost-centers/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteCostCenter(id);
      res.json({ message: 'Cost center deleted' });
    } catch (error) {
      console.error('Error deleting cost center:', error);
      res.status(500).json({ message: 'Failed to delete cost center' });
    }
  });

  // Client Compliances API Routes
  
  // Get clients by company
  app.get("/api/clients/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const clients = await storage.getClientsByCompany(companyId);
      res.json(clients);
    } catch (error) {
      console.error('Error fetching clients:', error);
      res.status(500).json({ message: 'Failed to fetch clients' });
    }
  });

  // Create client
  app.post("/api/clients", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const clientData = { ...req.body, companyId: req.user.companyId };
      const client = await storage.createClient(clientData);
      res.json(client);
    } catch (error) {
      console.error('Error creating client:', error);
      res.status(500).json({ message: 'Failed to create client' });
    }
  });

  // Update client
  app.put("/api/clients/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const client = await storage.updateClient(id, req.body);
      res.json(client);
    } catch (error) {
      console.error('Error updating client:', error);
      res.status(500).json({ message: 'Failed to update client' });
    }
  });

  // Delete client
  app.delete("/api/clients/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteClient(id);
      res.json({ message: 'Client deleted' });
    } catch (error) {
      console.error('Error deleting client:', error);
      res.status(500).json({ message: 'Failed to delete client' });
    }
  });

  // Compliance Setups API Routes
  
  // Get compliance setups by company
  app.get("/api/compliance-setups/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const setups = await storage.getComplianceSetupsByCompany(companyId);
      res.json(setups);
    } catch (error) {
      console.error('Error fetching compliance setups:', error);
      res.status(500).json({ message: 'Failed to fetch compliance setups' });
    }
  });

  // Create compliance setup
  app.post("/api/compliance-setups", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const setupData = { ...req.body, companyId: req.user.companyId };
      const setup = await storage.createComplianceSetup(setupData);
      
      // Auto-generate compliance data for all projects this employee is assigned to
      const assignments = await storage.getEmployeeAssignmentsByEmployee(setup.employeeId);
      for (const assignment of assignments) {
        if (assignment.deassignDate === null) { // Only active assignments
          await storage.autoGenerateComplianceData(
            req.user.companyId,
            setup.employeeId,
            assignment.projectId
          );
        }
      }
      
      res.json(setup);
    } catch (error) {
      console.error('Error creating compliance setup:', error);
      res.status(500).json({ message: 'Failed to create compliance setup' });
    }
  });

  // Update compliance setup
  app.put("/api/compliance-setups/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const setup = await storage.updateComplianceSetup(id, req.body);
      res.json(setup);
    } catch (error) {
      console.error('Error updating compliance setup:', error);
      res.status(500).json({ message: 'Failed to update compliance setup' });
    }
  });

  // Delete compliance setup
  app.delete("/api/compliance-setups/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteComplianceSetup(id);
      res.json({ message: 'Compliance setup deleted' });
    } catch (error) {
      console.error('Error deleting compliance setup:', error);
      res.status(500).json({ message: 'Failed to delete compliance setup' });
    }
  });

  // Compliances Data API Routes
  
  // Get compliances data by company
  app.get("/api/compliances-data/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      const data = await storage.getCompliancesDataByCompany(companyId);
      res.json(data);
    } catch (error) {
      console.error('Error fetching compliances data:', error);
      res.status(500).json({ message: 'Failed to fetch compliances data' });
    }
  });

  // Get compliances data by project and month
  app.get("/api/compliances-data/:companyId/:projectId/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const projectId = parseInt(req.params.projectId);
      const month = req.params.month;
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }
      
      const data = await storage.getCompliancesDataByProjectAndMonth(companyId, projectId, month);
      res.json(data);
    } catch (error) {
      console.error('Error fetching compliances data by project and month:', error);
      res.status(500).json({ message: 'Failed to fetch compliances data' });
    }
  });

  // Create compliances data
  app.post("/api/compliances-data", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const complianceData = { ...req.body, companyId: req.user.companyId };
      const data = await storage.createCompliancesData(complianceData);
      res.json(data);
    } catch (error) {
      console.error('Error creating compliances data:', error);
      res.status(500).json({ message: 'Failed to create compliances data' });
    }
  });

  // Update compliances data
  app.put("/api/compliances-data/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      const data = await storage.updateCompliancesData(id, req.body);
      res.json(data);
    } catch (error) {
      console.error('Error updating compliances data:', error);
      res.status(500).json({ message: 'Failed to update compliances data' });
    }
  });

  // Delete compliances data
  app.delete("/api/compliances-data/:id", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const id = parseInt(req.params.id);
      await storage.deleteCompliancesData(id);
      res.json({ message: 'Compliances data deleted' });
    } catch (error) {
      console.error('Error deleting compliances data:', error);
      res.status(500).json({ message: 'Failed to delete compliances data' });
    }
  });

  // Auto-generate compliance data for all assignments in a project
  app.post("/api/compliances-data/generate/:projectId", authenticateToken, async (req, res) => {
    try {
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions' });
      }
      const projectId = parseInt(req.params.projectId);
      await storage.generateComplianceDataForProject(req.user.companyId, projectId);
      res.json({ message: 'Compliance data generated successfully for all assigned employees' });
    } catch (error) {
      console.error('Error generating compliance data:', error);
      res.status(500).json({ message: 'Failed to generate compliance data' });
    }
  });

  // Employee Assignment Routes
  app.get("/api/employee-assignments/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const assignments = await storage.getEmployeeAssignmentsByCompany(companyId);
      res.json(assignments);
    } catch (error: any) {
      console.error("Error fetching employee assignments:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/employee-assignments", authenticateToken, async (req, res) => {
    try {
      const assignmentData = { ...req.body, companyId: req.user.companyId };
      const assignment = await storage.createEmployeeAssignment(assignmentData);
      
      res.json(assignment);
    } catch (error: any) {
      console.error("Error creating employee assignment:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/employee-assignments/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const assignment = await storage.updateEmployeeAssignment(id, req.body);
      res.json(assignment);
    } catch (error: any) {
      console.error("Error updating employee assignment:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.put("/api/employee-assignments/:id/deassign", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { deassignDate } = req.body;
      const assignment = await storage.updateEmployeeAssignment(id, { deassignDate });
      res.json(assignment);
    } catch (error: any) {
      console.error("Error de-assigning employee:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/employee-assignments/:id", authenticateToken, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteEmployeeAssignment(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting employee assignment:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Admin Aadhaar Lookup Route  
  app.post("/api/admin/lookup-employee-by-aadhaar", authenticateToken, async (req, res) => {
    try {
      console.log('🔍 Admin Aadhaar lookup request:', {
        user: req.user.email,
        role: req.user.role,
        body: req.body
      });

      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Access denied. Admin access required.' });
      }

      const { aadhaarNo } = req.body;
      
      if (!aadhaarNo || aadhaarNo.length !== 12) {
        console.log('❌ Invalid Aadhaar number:', aadhaarNo);
        return res.status(400).json({ message: 'Valid 12-digit Aadhaar number is required' });
      }

      console.log('🔎 Looking up employee by Aadhaar:', aadhaarNo);
      
      // Look up employee profile by Aadhaar number
      const employeeProfile = await storage.getEmployeeProfileByAadhaar(aadhaarNo);
      console.log('📋 Employee profile found:', employeeProfile ? 'YES' : 'NO');
      
      if (employeeProfile) {
        // Also get KYC details for this profile
        const kycDetails = await storage.getKycDetailsByProfile(employeeProfile.id);
        console.log('🆔 KYC details found:', kycDetails ? 'YES' : 'NO');
        
        // Get user email from users table
        let userEmail = null;
        if (employeeProfile.userId) {
          const user = await storage.getUser(employeeProfile.userId);
          userEmail = user?.email || null;
          console.log('📧 User email found:', userEmail);
        }
        
        const response = {
          found: true,
          employeeProfile,
          kycDetails: kycDetails || { aadharNo: aadhaarNo },
          userEmail: userEmail
        };
        
        console.log('✅ Sending success response:', response);
        res.json(response);
      } else {
        console.log('❌ No employee profile found for Aadhaar:', aadhaarNo);
        res.json({
          found: false,
          message: 'No employee profile found with this Aadhaar number'
        });
      }
    } catch (error) {
      console.error('💥 Error in admin Aadhaar lookup:', error);
      res.status(500).json({ message: 'Failed to lookup employee by Aadhaar' });
    }
  });

  // ========== EXCEL EXPORT ROUTES ==========

  // Employee Export to Excel
  app.get("/api/employees/export/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Employees');
      
      // Define columns
      worksheet.columns = [
        { header: 'Employee ID', key: 'employeeId', width: 15 },
        { header: 'First Name', key: 'firstName', width: 20 },
        { header: 'Last Name', key: 'lastName', width: 20 },
        { header: 'Email', key: 'email', width: 30 },
        { header: 'Phone', key: 'phone', width: 15 },
        { header: 'Department', key: 'department', width: 20 },
        { header: 'Position', key: 'position', width: 25 },
        { header: 'Salary', key: 'salary', width: 15 },
        { header: 'Hire Date', key: 'hireDate', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Address', key: 'address', width: 40 },
        { header: 'Date of Birth', key: 'dateOfBirth', width: 15 },
        { header: 'Emergency Contact', key: 'emergencyContact', width: 25 },
        { header: 'Emergency Phone', key: 'emergencyPhone', width: 20 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Add data rows
      employees.forEach(emp => {
        const department = departments.find(d => d.id === emp.departmentId);
        worksheet.addRow({
          employeeId: emp.employeeId,
          firstName: emp.firstName,
          lastName: emp.lastName,
          email: emp.email,
          phone: emp.phone,
          department: department?.name || 'N/A',
          position: emp.position,
          salary: emp.salary,
          hireDate: emp.hireDate ? new Date(emp.hireDate).toLocaleDateString() : '',
          status: emp.status,
          address: emp.address,
          dateOfBirth: emp.dateOfBirth ? new Date(emp.dateOfBirth).toLocaleDateString() : '',
          emergencyContact: emp.emergencyContact,
          emergencyPhone: emp.emergencyPhone
        });
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=employees_${new Date().toISOString().split('T')[0]}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Employee export error:', error);
      res.status(500).json({ message: 'Failed to export employees' });
    }
  });

  // Payroll Export to Excel
  app.get("/api/payroll/export/:companyId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Payroll');
      
      // Define columns
      worksheet.columns = [
        { header: 'Month', key: 'month', width: 12 },
        { header: 'Employee ID', key: 'employeeId', width: 15 },
        { header: 'Employee Name', key: 'employeeName', width: 25 },
        { header: 'Department', key: 'department', width: 20 },
        { header: 'Basic Salary', key: 'basicSalary', width: 15 },
        { header: 'HRA', key: 'hra', width: 15 },
        { header: 'Special Allowance', key: 'specialAllowance', width: 20 },
        { header: 'Transport Allowance', key: 'transportAllowance', width: 20 },
        { header: 'Medical Allowance', key: 'medicalAllowance', width: 18 },
        { header: 'Gross Salary', key: 'grossSalary', width: 15 },
        { header: 'EPF Deduction', key: 'epfDeduction', width: 15 },
        { header: 'ESIC Deduction', key: 'esicDeduction', width: 15 },
        { header: 'TDS Deduction', key: 'tdsDeduction', width: 15 },
        { header: 'PT Deduction', key: 'ptDeduction', width: 15 },
        { header: 'Net Salary', key: 'netSalary', width: 15 },
        { header: 'Payment Status', key: 'paymentStatus', width: 15 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Get actual payroll records for the specified month/year
      const monthlyPayrolls = await storage.getMonthlyPayrolls(companyId);
      const monthlyPayroll = monthlyPayrolls.find(mp => mp.month === month && mp.year === year);
      
      if (!monthlyPayroll) {
        return res.status(404).json({ message: `No payroll found for ${year}-${month.toString().padStart(2, '0')}` });
      }

      const payrollRecords = await storage.getPayrollRecords(monthlyPayroll.id);
      
      // Format month as MMMYY (e.g., "Feb25" for February 2025)
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthStr = monthNames[month - 1] + year.toString().slice(-2);
      
      // Guard against empty records
      if (!payrollRecords || payrollRecords.length === 0) {
        return res.status(404).json({ message: `No payroll records found for ${year}-${month.toString().padStart(2, '0')}` });
      }

      console.log('Payroll records count:', payrollRecords.length);
      console.log('First record sample:', JSON.stringify(payrollRecords[0], null, 2));

      // Add data rows using actual payroll records with proper INR formatting
      payrollRecords.forEach((record, index) => {
        // Use actual values from payroll records (already correctly calculated)
        const basicSal = parseFloat(record.basicSalary || '0');
        const hraAmount = parseFloat(record.hra || '0');
        const conveyanceAllowance = parseFloat(record.conveyanceAllowance || '0');
        const otherAllowances = parseFloat(record.otherAllowances || '0');
        const grossSal = parseFloat(record.grossSalary || '0');
        const epfDed = parseFloat(record.epfEmployee || '0');
        const esicDed = parseFloat(record.esicEmployee || '0');
        const tdsDed = parseFloat(record.tdsAmount || '0');
        const ptDed = parseFloat(record.ptAmount || '0');
        const netSal = parseFloat(record.netSalary || '0');

        console.log(`Record ${index + 1}: ${record.employeeName} - Basic: ${basicSal}, Gross: ${grossSal}`);
        
        const row = worksheet.addRow({
          month: monthStr,
          employeeId: record.employeeCode,
          employeeName: record.employeeName,
          department: record.department || 'N/A',
          basicSalary: basicSal,
          hra: hraAmount,
          specialAllowance: conveyanceAllowance,
          transportAllowance: otherAllowances,
          medicalAllowance: 0,
          grossSalary: grossSal,
          epfDeduction: epfDed,
          esicDeduction: esicDed,
          tdsDeduction: tdsDed,
          ptDeduction: ptDed,
          netSalary: netSal,
          paymentStatus: record.paymentStatus === 'paid' ? 'Paid' : 'Pending'
        });

        // Apply INR currency formatting to all money columns
        row.getCell('basicSalary').numFmt = '₹#,##0.00';
        row.getCell('hra').numFmt = '₹#,##0.00';
        row.getCell('specialAllowance').numFmt = '₹#,##0.00';
        row.getCell('transportAllowance').numFmt = '₹#,##0.00';
        row.getCell('medicalAllowance').numFmt = '₹#,##0.00';
        row.getCell('grossSalary').numFmt = '₹#,##0.00';
        row.getCell('epfDeduction').numFmt = '₹#,##0.00';
        row.getCell('esicDeduction').numFmt = '₹#,##0.00';
        row.getCell('tdsDeduction').numFmt = '₹#,##0.00';
        row.getCell('ptDeduction').numFmt = '₹#,##0.00';
        row.getCell('netSalary').numFmt = '₹#,##0.00';
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=payroll_${year}_${month.toString().padStart(2, '0')}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Payroll export error:', error);
      res.status(500).json({ message: 'Failed to export payroll' });
    }
  });

  // Compliances Data Export to Excel
  app.get("/api/compliances/export/:companyId", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const compliancesData = await storage.getCompliancesDataByCompany(companyId);
      const clients = await storage.getClientsByCompany(companyId);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Compliances Data');
      
      // Define columns
      worksheet.columns = [
        { header: 'Client Name', key: 'clientName', width: 25 },
        { header: 'Compliance Type', key: 'complianceType', width: 20 },
        { header: 'Period', key: 'period', width: 15 },
        { header: 'Due Date', key: 'dueDate', width: 15 },
        { header: 'Filing Date', key: 'filingDate', width: 15 },
        { header: 'Status', key: 'status', width: 15 },
        { header: 'Amount', key: 'amount', width: 15 },
        { header: 'Penalty', key: 'penalty', width: 15 },
        { header: 'Total Amount', key: 'totalAmount', width: 15 },
        { header: 'Filed By', key: 'filedBy', width: 20 },
        { header: 'Remarks', key: 'remarks', width: 30 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Add data rows
      compliancesData.forEach(compliance => {
        const client = clients.find(c => c.id === compliance.clientId);
        worksheet.addRow({
          clientName: client?.projectName || 'N/A',
          complianceType: compliance.complianceType,
          period: compliance.period,
          dueDate: compliance.dueDate ? new Date(compliance.dueDate).toLocaleDateString() : '',
          filingDate: compliance.filingDate ? new Date(compliance.filingDate).toLocaleDateString() : '',
          status: compliance.status,
          amount: compliance.amount || '',
          penalty: compliance.penalty || '',
          totalAmount: compliance.totalAmount || '',
          filedBy: compliance.filedBy || '',
          remarks: compliance.remarks || ''
        });
      });

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=compliances_${new Date().toISOString().split('T')[0]}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Compliances export error:', error);
      res.status(500).json({ message: 'Failed to export compliances data' });
    }
  });

  // Attendance Export to Excel
  app.get("/api/attendance/export/:companyId/:year/:month", authenticateToken, async (req, res) => {
    try {
      const companyId = parseInt(req.params.companyId);
      const year = parseInt(req.params.year);
      const month = parseInt(req.params.month);
      
      if (req.user.role !== 'system_admin' && req.user.companyId !== companyId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const employees = await storage.getEmployeesByCompany(companyId);
      const departments = await storage.getDepartmentsByCompany(companyId);
      const holidayCount = await storage.getHolidayCountForMonth(companyId, year, month);
      
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Attendance');
      
      // Define columns
      worksheet.columns = [
        { header: 'Employee ID', key: 'employeeId', width: 15 },
        { header: 'Employee Name', key: 'employeeName', width: 25 },
        { header: 'Department', key: 'department', width: 20 },
        { header: 'Present Days', key: 'presentDays', width: 15 },
        { header: 'Absent Days', key: 'absentDays', width: 15 },
        { header: 'Leave Days', key: 'leaveDays', width: 15 },
        { header: 'Weekly Off', key: 'weeklyOff', width: 15 },
        { header: 'Holidays', key: 'holidays', width: 15 },
        { header: 'Pay Days', key: 'payDays', width: 15 },
        { header: 'OT Hours', key: 'otHours', width: 15 },
        { header: 'Total Hours', key: 'totalHours', width: 15 },
        { header: 'Late Coming', key: 'lateComing', width: 15 },
        { header: 'Early Going', key: 'earlyGoing', width: 15 }
      ];

      // Style header row
      worksheet.getRow(1).font = { bold: true };
      worksheet.getRow(1).fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };

      // Add data rows
      for (const emp of employees) {
        const department = departments.find(d => d.id === emp.departmentId);
        let monthlyRecord = await storage.getMonthlyAttendanceByEmployee(emp.id, year, month);
        
        // If no saved record, calculate defaults
        if (!monthlyRecord) {
          const basePresent = 20 + (emp.id % 5);
          const weeklyOff = 4;
          const actualLeaveForDefaults = await storage.getApprovedLeaveDaysForMonth(emp.id, year, month);
          const holidays = holidayCount;
          const payDays = basePresent + weeklyOff + actualLeaveForDefaults + holidays;
          const otHours = (emp.id + 1) * 1.5;
          
          monthlyRecord = {
            presentDays: basePresent,
            payableDays: payDays,
            totalHoursWorked: otHours.toString()
          };
        }

        const presentDays = monthlyRecord.presentDays || 20;
        const weeklyOff = 4;
        const holidays = holidayCount;
        const actualLeaveDaysForExport = await storage.getApprovedLeaveDaysForMonth(emp.id, year, month);
        const absentDays = 30 - presentDays - actualLeaveDaysForExport - weeklyOff - holidays;
        const otHours = parseFloat(monthlyRecord.totalHoursWorked || '0');

        worksheet.addRow({
          employeeId: emp.employeeId,
          employeeName: `${emp.firstName} ${emp.lastName}`,
          department: department?.name || 'N/A',
          presentDays: presentDays,
          absentDays: Math.max(0, absentDays),
          leaveDays: actualLeaveDaysForExport,
          weeklyOff: weeklyOff,
          holidays: holidays,
          payDays: monthlyRecord.payableDays || 26,
          otHours: otHours.toFixed(1),
          totalHours: (presentDays * 8 + otHours).toFixed(1),
          lateComing: Math.floor(Math.random() * 5), // Random for demo
          earlyGoing: Math.floor(Math.random() * 3) // Random for demo
        });
      }

      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename=attendance_${year}_${month.toString().padStart(2, '0')}.xlsx`);
      
      await workbook.xlsx.write(res);
      res.end();
    } catch (error) {
      console.error('Attendance export error:', error);
      res.status(500).json({ message: 'Failed to export attendance' });
    }
  });

  // Payslip Management Routes
  
  // Generate payslips for a monthly payroll
  app.post("/api/payslips/generate", authenticateToken, async (req, res) => {
    try {
      // Validate request body
      if (typeof req.body.payrollId !== 'number' || !req.body.payrollId) {
        return res.status(400).json({ message: 'Valid payroll ID is required' });
      }
      
      const { payrollId, employeeIds } = req.body;
      
      // Check authorization - only admins or users with payroll_generate permission
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions - payroll generation requires admin access' });
      }
      
      // Verify the payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      // Check specific permission for payroll operations
      if (req.user.role !== 'system_admin') {
        const hasPermission = await storage.hasUserPermission(req.user.id, 'payroll_generate', req.user.companyId);
        if (!hasPermission) {
          return res.status(403).json({ message: 'Insufficient permissions - payroll_generate permission required' });
        }
      }
      
      // Check if payroll is finalized
      if (payroll.status !== 'finalized') {
        return res.status(400).json({ message: 'Can only generate payslips for finalized payroll' });
      }
      
      // Get payroll records to generate payslips for
      let payrollRecords = await storage.getPayrollRecords(payrollId);
      
      // Filter by employee IDs if specified
      if (employeeIds && employeeIds.length > 0) {
        payrollRecords = payrollRecords.filter(record => employeeIds.includes(record.employeeId));
      }
      
      const generatedPayslips = [];
      
      for (const record of payrollRecords) {
        // Check if payslip already exists for this record
        const existingPayslip = await storage.getPayslipByPayrollRecord(record.id);
        if (existingPayslip) {
          generatedPayslips.push(existingPayslip);
          continue;
        }
        
        // Generate unique payslip number
        const payslipNumber = `PS-${payroll.companyId}-${payroll.year}-${payroll.month.toString().padStart(2, '0')}-${record.employeeId}`;
        
        // Create payslip record
        const payslip = await storage.createPayslip({
          payrollRecordId: record.id,
          employeeId: record.employeeId,
          companyId: payroll.companyId,
          monthlyPayrollId: payrollId,
          month: payroll.month,
          year: payroll.year,
          payslipNumber,
          version: 1,
          status: 'generated',
          generatedBy: req.user.id,
          templateVersion: 'v1'
        });
        
        generatedPayslips.push(payslip);
      }
      
      res.status(201).json({
        message: `Generated ${generatedPayslips.length} payslips`,
        payslips: generatedPayslips
      });
      
    } catch (error) {
      console.error('Payslip generation error:', error);
      res.status(500).json({ message: 'Failed to generate payslips' });
    }
  });
  
  // Get payslips for a specific payroll  
  app.get("/api/payslips/:payrollId", authenticateToken, async (req, res) => {
    try {
      const payrollId = parseInt(req.params.payrollId);
      
      if (isNaN(payrollId)) {
        return res.status(400).json({ message: 'Valid payroll ID is required' });
      }
      
      // Check authorization - only admins or users with payroll_view permission
      if (req.user.role === 'employee') {
        return res.status(403).json({ message: 'Insufficient permissions - payroll viewing requires admin access' });
      }
      
      // Verify the payroll exists and user has access
      const payroll = await storage.getMonthlyPayroll(payrollId);
      if (!payroll) {
        return res.status(404).json({ message: 'Payroll not found' });
      }
      
      // Check company access
      if (req.user.role !== 'system_admin' && req.user.companyId !== payroll.companyId) {
        return res.status(403).json({ message: 'Access denied to this payroll' });
      }
      
      // Check specific permission for payroll viewing
      if (req.user.role !== 'system_admin') {
        const hasPermission = await storage.hasUserPermission(req.user.id, 'payroll_view', req.user.companyId);
        if (!hasPermission) {
          return res.status(403).json({ message: 'Insufficient permissions - payroll_view permission required' });
        }
      }
      
      const payslips = await storage.getPayslipsByPayroll(payrollId);
      
      // Enrich payslips with employee details
      const enrichedPayslips = await Promise.all(payslips.map(async (payslip) => {
        const employee = await storage.getEmployee(payslip.employeeId);
        return {
          ...payslip,
          employeeName: employee ? `${employee.firstName} ${employee.lastName}` : 'Unknown',
          employeeCode: employee?.employeeId || 'N/A'
        };
      }));
      
      res.json(enrichedPayslips);
      
    } catch (error) {
      console.error('Get payslips error:', error);
      res.status(500).json({ message: 'Failed to fetch payslips' });
    }
  });
  
  // Download payslip PDF
  app.get("/api/payslips/download/:payslipId", authenticateToken, async (req, res) => {
    try {
      const payslipId = parseInt(req.params.payslipId);
      
      if (isNaN(payslipId)) {
        return res.status(400).json({ message: 'Valid payslip ID is required' });
      }
      
      const payslip = await storage.getPayslip(payslipId);
      if (!payslip) {
        return res.status(404).json({ message: 'Payslip not found' });
      }
      
      // Check access - employees can only access their own payslips
      if (req.user.role === 'employee') {
        const employee = await storage.getEmployeeByUserId(req.user.id);
        if (!employee || employee.id !== payslip.employeeId) {
          return res.status(403).json({ message: 'Access denied - you can only access your own payslips' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== payslip.companyId) {
        return res.status(403).json({ message: 'Access denied to this payslip' });
      } else if (req.user.role === 'admin') {
        // Admins need payroll_view permission
        const hasPermission = await storage.hasUserPermission(req.user.id, 'payroll_view', req.user.companyId);
        if (!hasPermission) {
          return res.status(403).json({ message: 'Insufficient permissions - payroll_view permission required' });
        }
      }
      
      // Generate PDF if not already generated
      if (!payslip.pdfPath) {
        // TODO: Implement PDF generation
        return res.status(501).json({ message: 'PDF generation not implemented yet' });
      }
      
      // Update download tracking
      await storage.updatePayslipStatus(payslipId, {
        downloadedAt: new Date(),
        status: 'downloaded'
      });
      
      // For now, return a placeholder response
      res.json({ message: 'PDF generation will be implemented in next step', payslipId });
      
    } catch (error) {
      console.error('Download payslip error:', error);
      res.status(500).json({ message: 'Failed to download payslip' });
    }
  });
  
  // Get employee's own payslips
  app.get("/api/payslips/employee/my-payslips", authenticateToken, async (req, res) => {
    try {
      // This endpoint is specifically for employees to access their own payslips
      const employee = await storage.getEmployeeByUserId(req.user.id);
      if (!employee) {
        return res.status(404).json({ message: 'Employee profile not found' });
      }
      
      const payslips = await storage.getPayslipsByEmployee(employee.id);
      
      // Enrich with basic employee info (they're viewing their own data)
      const enrichedPayslips = payslips.map(payslip => ({
        ...payslip,
        employeeName: `${employee.firstName} ${employee.lastName}`,
        employeeCode: employee.employeeId
      }));
      
      res.json(enrichedPayslips);
      
    } catch (error) {
      console.error('Get employee payslips error:', error);
      res.status(500).json({ message: 'Failed to fetch your payslips' });
    }
  });

  // Update payslip status  
  app.put("/api/payslips/:payslipId/status", authenticateToken, async (req, res) => {
    try {
      const payslipId = parseInt(req.params.payslipId);
      
      if (isNaN(payslipId)) {
        return res.status(400).json({ message: 'Valid payslip ID is required' });
      }
      
      const { status, emailedTo } = req.body;
      
      const payslip = await storage.getPayslip(payslipId);
      if (!payslip) {
        return res.status(404).json({ message: 'Payslip not found' });
      }
      
      // Check access - employees can only update their own payslips (limited operations)
      if (req.user.role === 'employee') {
        const employee = await storage.getEmployeeByUserId(req.user.id);
        if (!employee || employee.id !== payslip.employeeId) {
          return res.status(403).json({ message: 'Access denied - you can only access your own payslips' });
        }
        // Employees can only mark as viewed, not change other statuses
        if (status && status !== 'viewed') {
          return res.status(403).json({ message: 'Insufficient permissions - employees can only mark payslips as viewed' });
        }
      } else if (req.user.role !== 'system_admin' && req.user.companyId !== payslip.companyId) {
        return res.status(403).json({ message: 'Access denied to this payslip' });
      } else if (req.user.role === 'admin') {
        // Admins need payroll_manage permission for status updates
        const hasPermission = await storage.hasUserPermission(req.user.id, 'payroll_manage', req.user.companyId);
        if (!hasPermission) {
          return res.status(403).json({ message: 'Insufficient permissions - payroll_manage permission required' });
        }
      }
      
      const updateData: any = { status };
      
      // Set appropriate timestamps based on status
      if (status === 'viewed') {
        updateData.viewedAt = new Date();
      } else if (status === 'downloaded') {
        updateData.downloadedAt = new Date();
      } else if (status === 'delivered') {
        updateData.emailedAt = new Date();
        if (emailedTo) updateData.emailedTo = emailedTo;
      }
      
      const updatedPayslip = await storage.updatePayslipStatus(payslipId, updateData);
      res.json(updatedPayslip);
      
    } catch (error) {
      console.error('Update payslip status error:', error);
      res.status(500).json({ message: 'Failed to update payslip status' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
