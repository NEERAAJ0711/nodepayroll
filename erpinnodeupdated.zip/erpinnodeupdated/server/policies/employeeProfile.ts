// Field-level permissions for employee profile editing
// Defines what fields employees can edit vs admin-only fields

// Fields that employees can edit themselves (require admin approval)
export const EMPLOYEE_SELF_EDITABLE_FIELDS = [
  // Personal Information
  'firstName',
  'lastName',
  'fullName', // Comprehensive profile field
  'phone',
  'address',
  'dateOfBirth',
  'age', // Auto-calculated from dateOfBirth
  'gender', // Comprehensive profile field
  'emergencyContact',
  'emergencyPhone',
  
  // Enhanced Address Information
  'state',
  'district', 
  'pinCode',
  'presentAddress',
  'permanentAddress',
  
  // Employment Details (some)
  'skills',
  'experience',
  'qualifications',
  'maritalStatus',
  'bloodGroup',
  'nationality',
  'speciality',
  'currentSalary',
  'expectedSalary',
  'noticePeriod',
  'totalExperience',
  
  // Personal Interests
  'hobbies',
  'strength',
  'profilePhoto',
  
  // KYC and Family (employee updates, admin approval)
  'aadharNumber',
  'aadhaarNo', // Support both naming conventions
  'panNumber',
  'panNo', // Support both naming conventions
  'passportNumber',
  'bankAccountNumber',
  'ifscCode',
  'fatherName',
  'fatherHusbandName', // Comprehensive profile field
  'motherName',
  'spouseName',
  'children'
];

// Fields that only admins can edit directly (no approval needed)
export const ADMIN_ONLY_FIELDS = [
  // Time Office Policy (Weekly off configuration)
  'firstWeeklyOffDay',
  'secondWeeklyOffDay',
  'dutyStartTime',
  'dutyEndTime',
  'permissibleLateArrival',
  'permissibleEarlyDeparture',
  'overtimeApplicable',
  'presentMarkingDuration',
  
  // Employment Status & Management
  'employeeId',
  'departmentId',
  'position',
  'salary',
  'hireDate',
  'status',
  'managerId',
  'jobTitle',
  'designation',
  'grade',
  'reportingManager',
  
  // Payroll Configuration
  'epfEnabled',
  'employeePfLimit',
  'employerPfLimit',
  'esicEnabled',
  'lwfEnabled',
  'otEnabled',
  'doubleOt',
  'vpfEnabled',
  'vpfAmount',
  'tdsEnabled',
  'tdsAmount',
  'ptEnabled',
  'ptAmount',
  'bonusEnabled',
  'bonusMonthlyPayment',
  'entryType',
  'ctcValue',
  'grossValue',
  'earningHead1',
  'earningHead2',
  'earningHead3',
  'earningHead4',
  
  // Company Assignment
  'companyId',
  'branchId',
  'costCenterId',
  'locationId'
];

// System admin can edit everything
export const SYSTEM_ADMIN_ALL_FIELDS = [
  ...EMPLOYEE_SELF_EDITABLE_FIELDS,
  ...ADMIN_ONLY_FIELDS
];

// Helper function to validate if a field can be edited by the given role
export function canEditField(field: string, userRole: string): boolean {
  if (userRole === 'system_admin') {
    return true; // System admin can edit everything
  }
  
  if (userRole === 'admin') {
    return EMPLOYEE_SELF_EDITABLE_FIELDS.includes(field) || ADMIN_ONLY_FIELDS.includes(field);
  }
  
  if (userRole === 'employee') {
    return EMPLOYEE_SELF_EDITABLE_FIELDS.includes(field);
  }
  
  return false;
}

// Get allowed fields for a user role
export function getAllowedFields(userRole: string): string[] {
  if (userRole === 'system_admin') {
    return SYSTEM_ADMIN_ALL_FIELDS;
  }
  
  if (userRole === 'admin') {
    return [...EMPLOYEE_SELF_EDITABLE_FIELDS, ...ADMIN_ONLY_FIELDS];
  }
  
  if (userRole === 'employee') {
    return EMPLOYEE_SELF_EDITABLE_FIELDS;
  }
  
  return [];
}

// Filter payload to only include allowed fields for the user role
export function filterAllowedFields(payload: any, userRole: string): any {
  const allowedFields = getAllowedFields(userRole);
  const filtered: any = {};
  
  for (const [key, value] of Object.entries(payload)) {
    if (allowedFields.includes(key)) {
      filtered[key] = value;
    }
  }
  
  return filtered;
}

// Check if payload contains admin-only fields (for employee requests)
export function containsAdminOnlyFields(payload: any): string[] {
  const adminOnlyFieldsInPayload: string[] = [];
  
  for (const key of Object.keys(payload)) {
    if (ADMIN_ONLY_FIELDS.includes(key)) {
      adminOnlyFieldsInPayload.push(key);
    }
  }
  
  return adminOnlyFieldsInPayload;
}