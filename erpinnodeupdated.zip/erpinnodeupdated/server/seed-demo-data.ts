import { db } from './db';
import { companies, users, departments, employees } from '@shared/schema';
import bcrypt from 'bcrypt';

export async function seedDemoData() {
  try {
    console.log('Seeding demo companies, users, and basic data...');
    
    // Check if demo data already exists
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      console.log('Demo users already exist, skipping demo data seeding');
      return;
    }

    // Create TechCorp company (for system admin)
    const [techCorp] = await db.insert(companies).values({
      name: 'TechCorp Systems',
      email: 'system@techcorp.com',
      phone: '+1-555-0100',
      address: '123 Technology Drive, Silicon Valley, CA 94000',
      type: 'private_limited',
      industry: 'Technology',
      size: 'Large (500+ employees)',
      status: 'approved',
      profileComplete: true,
    }).returning();

    // Create Demo Company (for admin and employee)
    const [demoCompany] = await db.insert(companies).values({
      name: 'Demo Corporation',
      email: 'admin@demo.com',
      phone: '+1-555-0200',
      address: '456 Business Blvd, Demo City, NY 10001',
      type: 'private_limited',
      industry: 'Professional Services',
      size: 'Medium (50-500 employees)',
      status: 'approved',
      profileComplete: true,
    }).returning();

    console.log(`Created companies: ${techCorp.name} (ID: ${techCorp.id}) and ${demoCompany.name} (ID: ${demoCompany.id})`);

    // Create system admin user
    const hashedSysAdminPassword = await bcrypt.hash('sysadmin123', 10);
    const [systemAdmin] = await db.insert(users).values({
      username: 'system_admin',
      email: 'system@techcorp.com',
      password: hashedSysAdminPassword,
      role: 'system_admin',
      companyId: techCorp.id,
      isActive: true,
    }).returning();

    // Create company admin user
    const hashedAdminPassword = await bcrypt.hash('admin123', 10);
    const [companyAdmin] = await db.insert(users).values({
      username: 'demo_admin',
      email: 'admin@demo.com',
      password: hashedAdminPassword,
      role: 'admin',
      companyId: demoCompany.id,
      isActive: true,
    }).returning();

    // Create employee user
    const hashedEmployeePassword = await bcrypt.hash('emp123', 10);
    const [employeeUser] = await db.insert(users).values({
      username: 'demo_employee',
      email: 'employee@demo.com',
      password: hashedEmployeePassword,
      role: 'employee',
      companyId: demoCompany.id,
      isActive: true,
    }).returning();

    console.log(`Created users: System Admin (${systemAdmin.email}), Company Admin (${companyAdmin.email}), Employee (${employeeUser.email})`);

    // Create departments for TechCorp
    const techCorpDepartments = await db.insert(departments).values([
      {
        name: 'Information Technology',
        description: 'System administration and IT infrastructure',
        companyId: techCorp.id,
      },
      {
        name: 'Operations',
        description: 'Business operations and process management',
        companyId: techCorp.id,
      }
    ]).returning();

    // Create departments for Demo Company
    const demoDepartments = await db.insert(departments).values([
      {
        name: 'Engineering',
        description: 'Software development and technical operations',
        companyId: demoCompany.id,
      },
      {
        name: 'Human Resources',
        description: 'Employee relations and talent management',
        companyId: demoCompany.id,
      },
      {
        name: 'Marketing',
        description: 'Marketing and customer acquisition',
        companyId: demoCompany.id,
      },
      {
        name: 'Sales',
        description: 'Sales and business development',
        companyId: demoCompany.id,
      }
    ]).returning();

    console.log(`Created ${techCorpDepartments.length} departments for TechCorp and ${demoDepartments.length} departments for Demo Company`);

    // Create employee profiles for the users
    const engineeringDept = demoDepartments.find(d => d.name === 'Engineering');
    const hrDept = demoDepartments.find(d => d.name === 'Human Resources');
    const itDept = techCorpDepartments.find(d => d.name === 'Information Technology');

    // Create employee record for system admin
    await db.insert(employees).values({
      userId: systemAdmin.id,
      companyId: techCorp.id,
      employeeId: 'SYS001',
      fullName: 'System Administrator',
      firstName: 'System',
      lastName: 'Administrator',
      email: systemAdmin.email,
      phone: '+1-555-0101',
      departmentId: itDept?.id,
      position: 'System Administrator',
      salary: '120000.00',
      hireDate: new Date('2023-01-15'),
      status: 'active',
      address: '123 Tech Street, Silicon Valley, CA',
    });

    // Create employee record for company admin
    await db.insert(employees).values({
      userId: companyAdmin.id,
      companyId: demoCompany.id,
      employeeId: 'ADM001',
      fullName: 'Demo Admin',
      firstName: 'Demo',
      lastName: 'Admin',
      email: companyAdmin.email,
      phone: '+1-555-0201',
      departmentId: hrDept?.id,
      position: 'HR Manager / Company Admin',
      salary: '85000.00',
      hireDate: new Date('2023-03-01'),
      status: 'active',
      address: '456 Admin Ave, Demo City, NY',
    });

    // Create employee record for regular employee
    await db.insert(employees).values({
      userId: employeeUser.id,
      companyId: demoCompany.id,
      employeeId: 'EMP001',
      fullName: 'Demo Employee',
      firstName: 'Demo',
      lastName: 'Employee',
      email: employeeUser.email,
      phone: '+1-555-0301',
      departmentId: engineeringDept?.id,
      position: 'Software Developer',
      salary: '70000.00',
      hireDate: new Date('2023-06-15'),
      status: 'active',
      address: '789 Employee St, Demo City, NY',
    });

    console.log('Created employee records for all demo users');
    console.log('✅ Demo data seeding completed successfully!');
    console.log('\nDemo Login Credentials:');
    console.log('System Admin: system@techcorp.com / sysadmin123');
    console.log('Company Admin: admin@demo.com / admin123');
    console.log('Employee: employee@demo.com / emp123');

  } catch (error) {
    console.error('Error seeding demo data:', error);
    throw error;
  }
}