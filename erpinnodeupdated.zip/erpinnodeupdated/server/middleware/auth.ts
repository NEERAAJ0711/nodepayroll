// Enhanced authentication and authorization middleware

import jwt from "jsonwebtoken";
import { storage } from "../storage";

const JWT_SECRET_VALUE = process.env.JWT_SECRET || 'dev-secret-key-not-for-production';

// Middleware to require specific roles
export function requireRole(allowedRoles: string[]) {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ 
        message: `Access denied. Required role: ${allowedRoles.join(' or ')}. Your role: ${req.user.role}` 
      });
    }
    
    next();
  };
}

// Middleware to require user to be accessing their own data OR have admin role
export function requireSelfOrRole(allowedRoles: string[]) {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    // Check if user is accessing their own data
    const targetUserId = parseInt(req.params.userId || req.params.employeeId);
    const currentUserId = req.user.id;
    
    // Allow if accessing own data
    if (targetUserId === currentUserId) {
      req.isSelfAccess = true;
      return next();
    }
    
    // Allow if user has required admin role
    if (allowedRoles.includes(req.user.role)) {
      req.isSelfAccess = false;
      return next();
    }
    
    return res.status(403).json({ 
      message: `Access denied. You can only access your own data or need role: ${allowedRoles.join(' or ')}` 
    });
  };
}

// Middleware to require admin access to company data
export function requireCompanyAdmin() {
  return (req: any, res: any, next: any) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Authentication required' });
    }
    
    const companyId = parseInt(req.params.companyId || req.body.companyId);
    
    // System admin can access all companies
    if (req.user.role === 'system_admin') {
      return next();
    }
    
    // Company admin can only access their own company
    if (req.user.role === 'admin' && req.user.companyId === companyId) {
      return next();
    }
    
    return res.status(403).json({ 
      message: 'Access denied. Admin access required for this company.' 
    });
  };
}

// Helper to check if user can edit weekly off (admin-only permission)
export function canEditWeeklyOff(userRole: string): boolean {
  return ['admin', 'system_admin'].includes(userRole);
}

// Helper to check if user can approve change requests
export function canApproveChanges(userRole: string): boolean {
  return ['admin', 'system_admin'].includes(userRole);
}

// Middleware to log user actions for audit trail
export function logUserAction(action: string) {
  return (req: any, res: any, next: any) => {
    // Store action info for logging after successful operation
    req.auditAction = {
      action,
      userId: req.user?.id,
      userRole: req.user?.role,
      companyId: req.user?.companyId,
      timestamp: new Date(),
      ip: req.ip,
      userAgent: req.get('User-Agent')
    };
    next();
  };
}