import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { Users, Briefcase, Calendar, TrendingUp, UserPlus, FileText, Shield, Building, Search, Download, UserCheck, Clock, CheckCircle, XCircle, Eye, Plus } from "lucide-react";
import { useAuth } from "@/lib/auth";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  
  const { data: company } = useQuery({
    queryKey: [`/api/companies/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  // Redirect to appropriate page based on company status
  useEffect(() => {
    if (company) {
      if (!company.profileComplete) {
        setLocation('/company-profile-setup');
      } else if (company.status === 'pending' || company.status === 'rejected') {
        setLocation('/company-approval-pending');
      }
    }
  }, [company, setLocation]);

  const { data: stats } = useQuery({
    queryKey: [`/api/dashboard/stats/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: employees = [] } = useQuery({
    queryKey: [`/api/employees/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: jobs = [] } = useQuery({
    queryKey: [`/api/jobs/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: companyUsers = [] } = useQuery({
    queryKey: ['/api/users'],
  });

  const { data: permissionRequests = [] } = useQuery({
    queryKey: ['/api/permission-requests'],
  });

  const { data: jobApplications = [] } = useQuery({
    queryKey: [`/api/job-applications/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: interviews = [] } = useQuery({
    queryKey: [`/api/interviews/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const recentEmployees = employees.slice(0, 5);
  const activeJobs = jobs.filter((job: any) => job.status === 'active');
  const pendingPermissions = permissionRequests.filter((req: any) => req.status === 'pending').length;

  // Show loading while checking company profile
  if (!company) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Manage {company?.name} - Complete HR administration
          </p>
          {company?.status === 'approved' && (
            <div className="flex items-center gap-2 mt-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-700 font-medium">Company Status Verified</span>
            </div>
          )}
        </div>
        <div className="flex gap-2">
          <Link href="/employees">
            <Button>
              <UserPlus className="mr-2 h-4 w-4" />
              Add Employee
            </Button>
          </Link>
          <Link href="/jobs">
            <Button variant="outline">
              <Briefcase className="mr-2 h-4 w-4" />
              Post Job
            </Button>
          </Link>
        </div>
      </div>

      {/* Recruitment Hub - Improved Design */}
      <Card className="mb-6 border-l-4 border-l-hr-primary">
        <CardHeader className="bg-gradient-to-r from-hr-primary/5 to-transparent">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-xl">
                <UserCheck className="h-6 w-6 text-hr-primary" />
                Recruitment Management
              </CardTitle>
              <CardDescription className="mt-1">
                Complete hiring solution - Post jobs, manage applications, conduct interviews, and make offers
              </CardDescription>
            </div>
            <Link href="/recruitment">
              <Button size="lg" className="bg-hr-primary hover:bg-hr-primary/90">
                <Eye className="mr-2 h-5 w-5" />
                Open Recruitment Center
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid gap-6 md:grid-cols-4">
            {/* Active Jobs */}
            <div className="text-center p-4 rounded-lg bg-blue-50 dark:bg-blue-950/20">
              <div className="text-2xl font-bold text-blue-600">{activeJobs.length}</div>
              <p className="text-sm font-medium text-blue-600">Active Jobs</p>
              <p className="text-xs text-muted-foreground">Ready for applications</p>
            </div>

            {/* New Applications */}
            <div className="text-center p-4 rounded-lg bg-green-50 dark:bg-green-950/20">
              <div className="text-2xl font-bold text-green-600">{jobApplications.filter((app: any) => app.status === 'applied').length}</div>
              <p className="text-sm font-medium text-green-600">New Applications</p>
              <p className="text-xs text-muted-foreground">Awaiting review</p>
            </div>

            {/* Today's Interviews */}
            <div className="text-center p-4 rounded-lg bg-yellow-50 dark:bg-yellow-950/20">
              <div className="text-2xl font-bold text-yellow-600">{interviews.filter((int: any) => new Date(int.scheduledAt).toDateString() === new Date().toDateString()).length}</div>
              <p className="text-sm font-medium text-yellow-600">Today's Interviews</p>
              <p className="text-xs text-muted-foreground">Scheduled meetings</p>
            </div>

            {/* Pending Offers */}
            <div className="text-center p-4 rounded-lg bg-purple-50 dark:bg-purple-950/20">
              <div className="text-2xl font-bold text-purple-600">{jobApplications.filter((app: any) => app.status === 'offered').length}</div>
              <p className="text-sm font-medium text-purple-600">Pending Offers</p>
              <p className="text-xs text-muted-foreground">Awaiting response</p>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t">
            <div className="flex items-center justify-between">
              <div className="grid grid-cols-3 gap-8 text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span>Post & Manage Jobs</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-blue-500" />
                  <span>Schedule Interviews</span>
                </div>
                <div className="flex items-center gap-2">
                  <Download className="h-4 w-4 text-purple-500" />
                  <span>Download Resumes</span>
                </div>
              </div>
              <Link href="/recruitment">
                <Button variant="outline">
                  View Full Dashboard →
                </Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalEmployees || 0}</div>
            <p className="text-xs text-muted-foreground">
              +{employees.filter((e: any) => new Date(e.createdAt) > new Date(Date.now() - 30*24*60*60*1000)).length} this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.activeJobs || 0}</div>
            <p className="text-xs text-muted-foreground">
              {jobs.filter((j: any) => j.status === 'draft').length} in draft
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Applications</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.pendingApplications || 0}</div>
            <p className="text-xs text-muted-foreground">
              Pending review
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats?.totalEmployees ? Math.round((stats.todayAttendance / stats.totalEmployees) * 100) : 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              {stats?.todayAttendance || 0} present today
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Management Quick Actions */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              User Management
            </CardTitle>
            <CardDescription>
              Manage user accounts and permissions
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span>Total Users</span>
              <Badge>{companyUsers.length}</Badge>
            </div>
            <div className="flex justify-between">
              <span>Pending Requests</span>
              <Badge variant="secondary">{pendingPermissions}</Badge>
            </div>
            <div className="flex gap-2 pt-2">
              <Link href="/admin/users">
                <Button size="sm" className="flex-1">Manage Users</Button>
              </Link>
              <Link href="/admin/permissions">
                <Button size="sm" variant="outline">Permissions</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Company Settings
            </CardTitle>
            <CardDescription>
              Configure company information and policies
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span>Company Status</span>
              <Badge className="bg-green-100 text-green-800">Active</Badge>
            </div>
            <div className="flex justify-between">
              <span>Subscription</span>
              <Badge variant="outline">{company?.subscriptionPlan || 'Basic'}</Badge>
            </div>
            <Link href="/admin/company-settings">
              <Button size="sm" className="w-full">Configure Settings</Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Performance Overview
            </CardTitle>
            <CardDescription>
              Company metrics and insights
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Employee Satisfaction</span>
                <span>85%</span>
              </div>
              <Progress value={85} className="h-2" />
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Recruitment Progress</span>
                <span>72%</span>
              </div>
              <Progress value={72} className="h-2" />
            </div>
            <Link href="/admin/reports">
              <Button size="sm" variant="outline" className="w-full">View Reports</Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Recent Employees</CardTitle>
            <CardDescription>
              Latest team members added to your company
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentEmployees.length > 0 ? (
              recentEmployees.map((employee: any) => (
                <div key={employee.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{employee.firstName} {employee.lastName}</p>
                    <p className="text-sm text-muted-foreground">{employee.position}</p>
                  </div>
                  <Badge variant={
                    employee.status === 'active' ? 'default' : 
                    employee.status === 'probation' ? 'secondary' : 'destructive'
                  }>
                    {employee.status}
                  </Badge>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-4">
                No employees found
              </p>
            )}
            <div className="text-center pt-2">
              <Link href="/employees">
                <Button variant="outline" size="sm">
                  View All Employees
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active Job Postings</CardTitle>
            <CardDescription>
              Current open positions in your company
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {activeJobs.length > 0 ? (
              activeJobs.slice(0, 5).map((job: any) => (
                <div key={job.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{job.title}</p>
                    <p className="text-sm text-muted-foreground">{job.location}</p>
                  </div>
                  <Badge className="bg-green-100 text-green-800">
                    {job.employmentType}
                  </Badge>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-4">
                No active job postings
              </p>
            )}
            <div className="text-center pt-2">
              <Link href="/jobs">
                <Button variant="outline" size="sm">
                  Manage Jobs
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}