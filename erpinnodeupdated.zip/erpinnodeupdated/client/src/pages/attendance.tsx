import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Users, UserCheck, UserX, Coffee, AlertTriangle, Search, Plus, Edit, Trash2, Calendar, Filter, Download, ShieldAlert } from "lucide-react";
import { format } from "date-fns";
import { authService, usePermission } from "@/lib/auth";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { MoreVertical, Eye, FileText } from "lucide-react";

interface AttendanceSummary {
  todayPresent: number;
  todayAbsent: number;
  todayLeave: number;
  todayWeeklyOff: number;
  continuouslyAbsent: number;
}

interface EmployeeAttendanceData {
  id: number;
  payCode: string;
  employeeName: string;
  department: string;
  present: number;
  weeklyOff: number;
  leave: number;
  holidays: number;
  payDays: number;
  otHours: number;
}

export default function AttendancePage() {
  const user = authService.getUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Check for attendance permission (using correct permission names)
  const { hasPermission: canViewAttendance, loading: permissionLoading } = usePermission('attendance_view_all');
  const { hasPermission: canEditAttendance } = usePermission('attendance_edit');
  
  // State for filters and search
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [searchTerm, setSearchTerm] = useState("");
  const [isQuickEntryOpen, setIsQuickEntryOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState("");
  const [payDays, setPayDays] = useState("");
  const [otHours, setOtHours] = useState("");
  
  // Quick Daily Entry state
  const [isQuickDailyEntryOpen, setIsQuickDailyEntryOpen] = useState(false);
  const [quickDailyDate, setQuickDailyDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [quickDailyEmployee, setQuickDailyEmployee] = useState("");
  const [quickDailyInTime, setQuickDailyInTime] = useState("");
  const [quickDailyOutTime, setQuickDailyOutTime] = useState("");
  
  // Card details modal state
  const [isCardDetailsOpen, setIsCardDetailsOpen] = useState(false);
  const [selectedCardType, setSelectedCardType] = useState<string>("");
  const [cardModalTitle, setCardModalTitle] = useState<string>("");
  
  // Edit dialog state
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<EmployeeAttendanceData | null>(null);
  const [editPayDays, setEditPayDays] = useState("");
  const [editOtHours, setEditOtHours] = useState("");
  
  // View dialog state
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [viewingEmployee, setViewingEmployee] = useState<EmployeeAttendanceData | null>(null);

  // Get employees for the company
  const { data: employees = [] } = useQuery({
    queryKey: [`/api/employees/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  // Get departments
  const { data: departments = [] } = useQuery({
    queryKey: [`/api/departments/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  // Get attendance summary data from API
  const { data: summaryData } = useQuery<AttendanceSummary>({
    queryKey: ['/api/attendance/summary/today'],
    enabled: !!user?.companyId,
  });

  const defaultSummary: AttendanceSummary = {
    todayPresent: 0,
    todayAbsent: 0,
    todayLeave: 0,
    todayWeeklyOff: 0,
    continuouslyAbsent: 0
  };

  // Get real employee attendance data from API
  const { data: attendanceData = [] } = useQuery<EmployeeAttendanceData[]>({
    queryKey: [`/api/attendance/employee-data/${user?.companyId}/${selectedYear}/${selectedMonth}`],
    enabled: !!user?.companyId,
  });

  // Card click handler - open modal with filtered data
  const handleCardClick = (cardType: string, title: string) => {
    setSelectedCardType(cardType);
    setCardModalTitle(title);
    setIsCardDetailsOpen(true);
  };

  // Get filtered data based on card type
  const getCardFilteredData = () => {
    return attendanceData.filter(emp => {
      switch (selectedCardType) {
        case 'present':
          return emp.present > 0;
        case 'absent':
          return emp.present === 0 && emp.leave === 0;
        case 'leave':
          return emp.leave > 0;
        case 'weeklyOff':
          return emp.weeklyOff > 0;
        case 'continuouslyAbsent':
          const totalWorkingDays = emp.present + emp.leave + emp.weeklyOff + emp.holidays;
          return emp.present < 3 || (totalWorkingDays > 0 && emp.present / totalWorkingDays < 0.3);
        default:
          return true;
      }
    });
  };

  // Export to Excel functionality for card data
  const handleExportCardToExcel = async () => {
    const ExcelJS = await import('exceljs');
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet(cardModalTitle);

    worksheet.columns = [
      { header: 'Pay Code', key: 'payCode', width: 15 },
      { header: 'Employee Name', key: 'employeeName', width: 30 },
      { header: 'Department', key: 'department', width: 20 },
      { header: 'Present', key: 'present', width: 12 },
      { header: 'Weekly Off', key: 'weeklyOff', width: 12 },
      { header: 'Leave', key: 'leave', width: 12 },
      { header: 'Holidays', key: 'holidays', width: 12 },
      { header: 'Pay Days', key: 'payDays', width: 12 },
      { header: 'OT Hours', key: 'otHours', width: 12 },
    ];

    const filteredEmployees = getCardFilteredData();
    worksheet.addRows(filteredEmployees);

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${cardModalTitle.replace(/ /g, '_')}_${format(new Date(), 'yyyy-MM-dd')}.xlsx`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    toast({
      title: "Success",
      description: "Data exported to Excel successfully",
    });
  };

  // Export to PDF functionality for card data
  const handleExportCardToPDF = async () => {
    const { PDFDocument, rgb, StandardFonts } = await import('pdf-lib');
    const pdfDoc = await PDFDocument.create();
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    
    const filteredEmployees = getCardFilteredData();
    const headers = ['Pay Code', 'Name', 'Dept', 'Present', 'Leave', 'Pay Days'];
    const columnWidths = [70, 120, 80, 50, 45, 55];
    
    const addPageHeader = (page: any) => {
      let y = 800;
      
      page.drawText(cardModalTitle, {
        x: 50,
        y,
        size: 18,
        font: boldFont,
        color: rgb(0, 0, 0),
      });
      
      y -= 30;
      page.drawText(`Date: ${format(new Date(), 'MMMM dd, yyyy')}`, {
        x: 50,
        y,
        size: 10,
        font,
        color: rgb(0.4, 0.4, 0.4),
      });
      
      y -= 30;
      
      let x = 50;
      headers.forEach((header, index) => {
        page.drawText(header, {
          x,
          y,
          size: 9,
          font: boldFont,
          color: rgb(0, 0, 0),
        });
        x += columnWidths[index];
      });
      
      return y - 20;
    };
    
    let currentPage = pdfDoc.addPage([595, 842]);
    let y = addPageHeader(currentPage);
    
    // Table Rows with pagination
    filteredEmployees.forEach((emp) => {
      if (y < 50) {
        currentPage = pdfDoc.addPage([595, 842]);
        y = addPageHeader(currentPage);
      }
      
      let x = 50;
      const rowData = [
        emp.payCode,
        emp.employeeName.substring(0, 20),
        emp.department.substring(0, 12),
        emp.present.toString(),
        emp.leave.toString(),
        emp.payDays.toString(),
      ];
      
      rowData.forEach((text, index) => {
        currentPage.drawText(text, {
          x,
          y,
          size: 8,
          font,
          color: rgb(0, 0, 0),
        });
        x += columnWidths[index];
      });
      
      y -= 15;
    });
    
    const pdfBytes = await pdfDoc.save();
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${cardModalTitle.replace(/ /g, '_')}_${format(new Date(), 'yyyy-MM-dd')}.pdf`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    toast({
      title: "Success",
      description: "Data exported to PDF successfully",
    });
  };

  // Filter employees based on search term only (not card filter)
  const filteredData = attendanceData.filter(emp =>
    emp.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.payCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Quick Entry mutation
  const quickEntryMutation = useMutation({
    mutationFn: async (data: { employeeId: string; payDays: string; otHours: string }) => {
      const token = authService.getToken();
      if (!token) {
        throw new Error('Authentication required');
      }
      
      const response = await fetch('/api/attendance/quick-entry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          employeeId: parseInt(data.employeeId),
          payDays: parseInt(data.payDays),
          otHours: parseFloat(data.otHours),
          month: selectedMonth,
          year: selectedYear
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update attendance');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Attendance data updated successfully",
      });
      setIsQuickEntryOpen(false);
      setSelectedEmployee("");
      setPayDays("");
      setOtHours("");
      queryClient.invalidateQueries({ queryKey: [`/api/employees/${user?.companyId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/attendance/summary/today'] });
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/employee-data/${user?.companyId}/${selectedYear}/${selectedMonth}`] });
    },
    onError: (error: any) => {
      console.error('Quick entry error:', error);
      if (error.message?.includes('Invalid or expired token') || error.message?.includes('401') || error.message?.includes('403')) {
        toast({
          title: "Session Expired",
          description: "Please refresh the page and log in again",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: error.message || "Failed to update attendance data",
          variant: "destructive",
        });
      }
    },
  });

  const handleQuickEntry = () => {
    if (!selectedEmployee || !payDays || !otHours) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      });
      return;
    }
    quickEntryMutation.mutate({ employeeId: selectedEmployee, payDays, otHours });
  };

  // Quick Daily Entry mutation
  const quickDailyEntryMutation = useMutation({
    mutationFn: async (data: { employeeId: string; date: string; inTime: string; outTime: string }) => {
      const token = authService.getToken();
      if (!token) {
        throw new Error('Authentication required');
      }
      
      const response = await fetch('/api/attendance/daily-entry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          employeeId: parseInt(data.employeeId),
          date: data.date,
          inTime: data.inTime,
          outTime: data.outTime
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to add daily attendance');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Daily attendance added successfully",
      });
      setIsQuickDailyEntryOpen(false);
      setQuickDailyEmployee("");
      setQuickDailyDate(format(new Date(), 'yyyy-MM-dd'));
      setQuickDailyInTime("");
      setQuickDailyOutTime("");
      queryClient.invalidateQueries({ queryKey: [`/api/employees/${user?.companyId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/attendance/summary/today'] });
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/employee-data/${user?.companyId}/${selectedYear}/${selectedMonth}`] });
    },
    onError: (error: any) => {
      console.error('Quick daily entry error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to add daily attendance",
        variant: "destructive",
      });
    },
  });

  const handleQuickDailyEntry = () => {
    if (!quickDailyEmployee || !quickDailyDate || !quickDailyInTime || !quickDailyOutTime) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      });
      return;
    }
    quickDailyEntryMutation.mutate({ 
      employeeId: quickDailyEmployee, 
      date: quickDailyDate, 
      inTime: quickDailyInTime, 
      outTime: quickDailyOutTime 
    });
  };

  // Edit Employee mutation
  const editEmployeeMutation = useMutation({
    mutationFn: async (data: { employeeId: number; payDays: string; otHours: string }) => {
      const token = authService.getToken();
      if (!token) {
        throw new Error('Authentication required');
      }
      
      const response = await fetch('/api/attendance/quick-entry', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          employeeId: data.employeeId,
          payDays: parseInt(data.payDays),
          otHours: parseFloat(data.otHours),
          month: selectedMonth,
          year: selectedYear
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update attendance');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Employee attendance updated successfully",
      });
      setIsEditDialogOpen(false);
      setEditingEmployee(null);
      setEditPayDays("");
      setEditOtHours("");
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/employee-data/${user?.companyId}/${selectedYear}/${selectedMonth}`] });
    },
    onError: (error: any) => {
      console.error('Edit employee error:', error);
      if (error.message?.includes('Invalid or expired token') || error.message?.includes('401') || error.message?.includes('403')) {
        toast({
          title: "Session Expired",
          description: "Please refresh the page and log in again",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: error.message || "Failed to update attendance data",
          variant: "destructive",
        });
      }
    },
  });

  // Delete Employee mutation
  const deleteEmployeeMutation = useMutation({
    mutationFn: async (employeeId: number) => {
      const token = authService.getToken();
      if (!token) {
        throw new Error('Authentication required');
      }
      
      const response = await fetch(`/api/attendance/delete/${user?.companyId}/${employeeId}/${selectedYear}/${selectedMonth}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete attendance record');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Attendance record deleted successfully",
      });
      // Invalidate both specific and broader attendance queries to ensure refresh
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/employee-data/${user?.companyId}/${selectedYear}/${selectedMonth}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/employee-data`], exact: false });
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/summary`], exact: false });
      // Force immediate refetch to ensure data is updated
      queryClient.refetchQueries({ queryKey: [`/api/attendance/employee-data/${user?.companyId}/${selectedYear}/${selectedMonth}`] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete attendance record",
        variant: "destructive",
      });
    },
  });

  const handleEditEmployee = (employee: EmployeeAttendanceData) => {
    setEditingEmployee(employee);
    setEditPayDays(employee.payDays.toString());
    setEditOtHours(employee.otHours.toString());
    setIsEditDialogOpen(true);
  };

  const handleViewEmployee = (employee: EmployeeAttendanceData) => {
    setViewingEmployee(employee);
    setIsViewDialogOpen(true);
  };

  const handleDeleteEmployee = (employee: EmployeeAttendanceData) => {
    if (window.confirm(`Are you sure you want to delete attendance record for ${employee.employeeName}?`)) {
      deleteEmployeeMutation.mutate(employee.id);
    }
  };

  const submitQuickEntry = () => {
    if (!selectedEmployee || !payDays || !otHours) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      });
      return;
    }
    quickEntryMutation.mutate({ employeeId: selectedEmployee, payDays, otHours });
  };

  const submitEdit = () => {
    if (!editingEmployee || !editPayDays || !editOtHours) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields",
        variant: "destructive",
      });
      return;
    }
    editEmployeeMutation.mutate({ 
      employeeId: editingEmployee.id, 
      payDays: editPayDays, 
      otHours: editOtHours 
    });
  };

  const handleExportToExcel = () => {
    const token = localStorage.getItem('token');
    const url = `/api/attendance/export/${user?.companyId}/${selectedYear}/${selectedMonth}`;
    
    // Create a temporary link with auth header
    fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `attendance_${selectedYear}_${selectedMonth}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    })
    .catch(error => {
      toast({
        title: "Error",
        description: "Failed to export attendance data",
        variant: "destructive",
      });
    });
  };

  const months = [
    { value: 1, label: "January" },
    { value: 2, label: "February" },
    { value: 3, label: "March" },
    { value: 4, label: "April" },
    { value: 5, label: "May" },
    { value: 6, label: "June" },
    { value: 7, label: "July" },
    { value: 8, label: "August" },
    { value: 9, label: "September" },
    { value: 10, label: "October" },
    { value: 11, label: "November" },
    { value: 12, label: "December" },
  ];

  const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - 2 + i);

  // Permission guard - show access denied if user doesn't have permission
  if (permissionLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6 max-w-7xl">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
            <p className="mt-2 text-gray-600">Checking permissions...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!canViewAttendance && user?.role === 'employee') {
    return (
      <div className="container mx-auto p-6 space-y-6 max-w-7xl">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <ShieldAlert className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-4">You don't have permission to access attendance management.</p>
            <p className="text-sm text-gray-500">Please request the "attendance_view_all" permission from your administrator.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Attendance Management</h1>
          <p className="text-muted-foreground">Monitor and manage employee attendance records</p>
        </div>
        <div className="flex gap-4 items-center">
          <Button 
            onClick={handleExportToExcel} 
            variant="outline"
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export to Excel
          </Button>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Today</p>
            <p className="text-lg font-semibold">{format(new Date(), 'EEEE, MMM dd, yyyy')}</p>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card 
          className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100 cursor-pointer transition-all duration-200 hover:border-green-400 hover:shadow-md"
          onClick={() => handleCardClick('present', 'Today Present Employees')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700">Today Present</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-800">{summaryData?.todayPresent || defaultSummary.todayPresent}</div>
            <p className="text-xs text-green-600">Active employees</p>
          </CardContent>
        </Card>

        <Card 
          className="border-2 border-red-200 bg-gradient-to-br from-red-50 to-red-100 cursor-pointer transition-all duration-200 hover:border-red-400 hover:shadow-md"
          onClick={() => handleCardClick('absent', 'Today Absent Employees')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-red-700">Today Absent</CardTitle>
            <UserX className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-800">{summaryData?.todayAbsent || defaultSummary.todayAbsent}</div>
            <p className="text-xs text-red-600">Missing today</p>
          </CardContent>
        </Card>

        <Card 
          className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100 cursor-pointer transition-all duration-200 hover:border-blue-400 hover:shadow-md"
          onClick={() => handleCardClick('leave', 'Employees on Leave')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700">Today Leave</CardTitle>
            <Coffee className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-800">{summaryData?.todayLeave || defaultSummary.todayLeave}</div>
            <p className="text-xs text-blue-600">On planned leave</p>
          </CardContent>
        </Card>

        <Card 
          className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-purple-100 cursor-pointer transition-all duration-200 hover:border-purple-400 hover:shadow-md"
          onClick={() => handleCardClick('weeklyOff', 'Employees on Weekly Off')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-700">Today Weekly Off</CardTitle>
            <Calendar className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-800">{summaryData?.todayWeeklyOff || defaultSummary.todayWeeklyOff}</div>
            <p className="text-xs text-purple-600">Weekly off day</p>
          </CardContent>
        </Card>

        <Card 
          className="border-2 border-orange-200 bg-gradient-to-br from-orange-50 to-orange-100 cursor-pointer transition-all duration-200 hover:border-orange-400 hover:shadow-md"
          onClick={() => handleCardClick('continuouslyAbsent', 'Continuously Absent Employees')}
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-orange-700">Continuously Absent</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-800">{summaryData?.continuouslyAbsent || defaultSummary.continuouslyAbsent}</div>
            <p className="text-xs text-orange-600">Since last 7 days</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Quick Entry */}
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between bg-gray-50 p-4 rounded-lg">
        <div className="flex flex-col sm:flex-row gap-4 items-center">
          {/* Month Selection */}
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-gray-600" />
            <Select value={selectedMonth.toString()} onValueChange={(value) => setSelectedMonth(parseInt(value))}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Month" />
              </SelectTrigger>
              <SelectContent>
                {months.map((month) => (
                  <SelectItem key={month.value} value={month.value.toString()}>
                    {month.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Year Selection */}
          <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
            <SelectTrigger className="w-24">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              {years.map((year) => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Search Filter */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
        </div>

        {/* Quick Entry Buttons */}
        <div className="flex gap-2">
          <Dialog open={isQuickEntryOpen} onOpenChange={setIsQuickEntryOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Quick Entry
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Quick Attendance Entry</DialogTitle>
              <DialogDescription>
                Add attendance data for an employee quickly
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="employee">Employee</Label>
                <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee..." />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((emp: any) => (
                      <SelectItem key={emp.id} value={emp.id.toString()}>
                        {emp.firstName} {emp.lastName} ({emp.employeeId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="payDays">Pay Days</Label>
                <Input
                  id="payDays"
                  type="number"
                  placeholder="Enter pay days"
                  value={payDays}
                  onChange={(e) => setPayDays(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="otHours">OT Hours</Label>
                <Input
                  id="otHours"
                  type="number"
                  step="0.1"
                  placeholder="Enter OT hours"
                  value={otHours}
                  onChange={(e) => setOtHours(e.target.value)}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setIsQuickEntryOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleQuickEntry} disabled={quickEntryMutation.isPending}>
                  {quickEntryMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Quick Daily Entry Button */}
        <Dialog open={isQuickDailyEntryOpen} onOpenChange={setIsQuickDailyEntryOpen}>
          <DialogTrigger asChild>
            <Button className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              Quick Daily Entry
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Quick Daily Attendance Entry</DialogTitle>
              <DialogDescription>
                Add daily attendance with in/out time for an employee
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="dailyDate">Date</Label>
                <Input
                  id="dailyDate"
                  type="date"
                  value={quickDailyDate}
                  onChange={(e) => setQuickDailyDate(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="dailyEmployee">Employee</Label>
                <Select value={quickDailyEmployee} onValueChange={setQuickDailyEmployee}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select employee..." />
                  </SelectTrigger>
                  <SelectContent>
                    {employees.map((emp: any) => (
                      <SelectItem key={emp.id} value={emp.id.toString()}>
                        {emp.fullName} ({emp.employeeId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="inTime">In Time</Label>
                <Input
                  id="inTime"
                  type="time"
                  value={quickDailyInTime}
                  onChange={(e) => setQuickDailyInTime(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="outTime">Out Time</Label>
                <Input
                  id="outTime"
                  type="time"
                  value={quickDailyOutTime}
                  onChange={(e) => setQuickDailyOutTime(e.target.value)}
                />
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setIsQuickDailyEntryOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleQuickDailyEntry} disabled={quickDailyEntryMutation.isPending}>
                  {quickDailyEntryMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Employee Attendance Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-blue-600" />
            Employee Attendance Data - {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
          </CardTitle>
          <CardDescription>
            Detailed attendance information for all employees
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pay Code</TableHead>
                  <TableHead>Employee Name</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead className="text-center">Present</TableHead>
                  <TableHead className="text-center">Weekly Off</TableHead>
                  <TableHead className="text-center">Leave</TableHead>
                  <TableHead className="text-center">Holidays</TableHead>
                  <TableHead className="text-center">Pay Days</TableHead>
                  <TableHead className="text-center">OT Hours</TableHead>
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={10} className="text-center py-8 text-muted-foreground">
                      No employees found matching your search criteria
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell className="font-medium">{employee.payCode}</TableCell>
                      <TableCell>{employee.employeeName}</TableCell>
                      <TableCell>{employee.department}</TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          {employee.present}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                          {employee.weeklyOff}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {employee.leave}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                          {employee.holidays}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-800 font-semibold">
                          {employee.payDays}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                          {employee.otHours}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewEmployee(employee)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleEditEmployee(employee)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Record
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => window.open(`/admin/attendance/daily-log/${employee.id}/${selectedYear}/${selectedMonth}`, '_blank')}>
                              <FileText className="h-4 w-4 mr-2" />
                              Daily Log
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="text-red-600"
                              onClick={() => handleDeleteEmployee(employee)}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete Record
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Quick Entry Dialog */}
      <Dialog open={isQuickEntryOpen} onOpenChange={setIsQuickEntryOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Quick Entry</DialogTitle>
            <DialogDescription>
              Add attendance data for an employee
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="employee">Employee</Label>
              <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
                <SelectTrigger>
                  <SelectValue placeholder="Select employee" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map((emp: any) => (
                    <SelectItem key={emp.id} value={emp.id.toString()}>
                      {emp.firstName} {emp.lastName} ({emp.employeeId})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="payDays">Pay Days</Label>
              <Input
                id="payDays"
                type="number"
                placeholder="Enter pay days"
                value={payDays}
                onChange={(e) => setPayDays(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="otHours">OT Hours</Label>
              <Input
                id="otHours"
                type="number"
                step="0.1"
                placeholder="Enter OT hours"
                value={otHours}
                onChange={(e) => setOtHours(e.target.value)}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setIsQuickEntryOpen(false)}>
                Cancel
              </Button>
              <Button onClick={submitQuickEntry} disabled={quickEntryMutation.isPending}>
                {quickEntryMutation.isPending ? "Saving..." : "Save"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Employee Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Attendance Record</DialogTitle>
            <DialogDescription>
              Update attendance data for {editingEmployee?.employeeName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="editPayDays">Pay Days</Label>
              <Input
                id="editPayDays"
                type="number"
                placeholder="Enter pay days"
                value={editPayDays}
                onChange={(e) => setEditPayDays(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="editOtHours">OT Hours</Label>
              <Input
                id="editOtHours"
                type="number"
                step="0.1"
                placeholder="Enter OT hours"
                value={editOtHours}
                onChange={(e) => setEditOtHours(e.target.value)}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={submitEdit} disabled={editEmployeeMutation.isPending}>
                {editEmployeeMutation.isPending ? "Saving..." : "Update"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Employee Details Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Employee Attendance Details</DialogTitle>
            <DialogDescription>
              Detailed view for {viewingEmployee?.employeeName} - {months.find(m => m.value === selectedMonth)?.label} {selectedYear}
            </DialogDescription>
          </DialogHeader>
          {viewingEmployee && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">Pay Code</Label>
                  <p className="text-lg font-semibold">{viewingEmployee.payCode}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">Department</Label>
                  <p className="text-lg font-semibold">{viewingEmployee.department}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">Present Days</Label>
                  <p className="text-2xl font-bold text-green-600">{viewingEmployee.present}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">Weekly Off</Label>
                  <p className="text-2xl font-bold text-purple-600">{viewingEmployee.weeklyOff}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">Leave Days</Label>
                  <p className="text-2xl font-bold text-blue-600">{viewingEmployee.leave}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">Holidays</Label>
                  <p className="text-2xl font-bold text-orange-600">{viewingEmployee.holidays}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">Total Pay Days</Label>
                  <p className="text-2xl font-bold text-gray-800">{viewingEmployee.payDays}</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm font-medium text-gray-600">OT Hours</Label>
                  <p className="text-2xl font-bold text-indigo-600">{viewingEmployee.otHours}</p>
                </div>
              </div>
              
              <div className="flex justify-end pt-4">
                <Button onClick={() => setIsViewDialogOpen(false)}>Close</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Card Details Modal with Export Functions */}
      <Dialog open={isCardDetailsOpen} onOpenChange={setIsCardDetailsOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh]">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <div>
                <DialogTitle className="text-2xl">{cardModalTitle}</DialogTitle>
                <DialogDescription>
                  {months.find(m => m.value === selectedMonth)?.label} {selectedYear} - {getCardFilteredData().length} employees
                </DialogDescription>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleExportCardToExcel}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <Download className="h-4 w-4" />
                  Export to Excel
                </Button>
                <Button
                  onClick={handleExportCardToPDF}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <FileText className="h-4 w-4" />
                  Download PDF
                </Button>
              </div>
            </div>
          </DialogHeader>
          
          <div className="overflow-auto max-h-[calc(90vh-200px)]">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pay Code</TableHead>
                  <TableHead>Employee Name</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead className="text-center">Present</TableHead>
                  <TableHead className="text-center">Weekly Off</TableHead>
                  <TableHead className="text-center">Leave</TableHead>
                  <TableHead className="text-center">Holidays</TableHead>
                  <TableHead className="text-center">Pay Days</TableHead>
                  <TableHead className="text-center">OT Hours</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {getCardFilteredData().length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8 text-gray-500">
                      No employees found in this category
                    </TableCell>
                  </TableRow>
                ) : (
                  getCardFilteredData().map((emp) => (
                    <TableRow key={emp.id}>
                      <TableCell className="font-medium">{emp.payCode}</TableCell>
                      <TableCell>{emp.employeeName}</TableCell>
                      <TableCell>{emp.department}</TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-green-100 text-green-800 font-semibold">
                          {emp.present}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-purple-100 text-purple-800 font-semibold">
                          {emp.weeklyOff}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-blue-100 text-blue-800 font-semibold">
                          {emp.leave}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-orange-100 text-orange-800 font-semibold">
                          {emp.holidays}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gray-100 text-gray-800 font-semibold">
                          {emp.payDays}
                        </span>
                      </TableCell>
                      <TableCell className="text-center font-semibold text-indigo-600">
                        {emp.otHours}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          
          <div className="flex justify-end pt-4 border-t">
            <Button onClick={() => setIsCardDetailsOpen(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}