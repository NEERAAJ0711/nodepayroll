import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Calendar, Clock, User, CheckCircle, XCircle, Eye, ShieldAlert } from "lucide-react";
import { usePermission } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { LeaveRequest, InsertLeaveRequest } from "@shared/schema";

const leaveApplicationSchema = z.object({
  leaveType: z.enum(['casual', 'sick', 'earned', 'maternity', 'paternity', 'comp_off', 'lwp']),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  reason: z.string().min(10, "Reason must be at least 10 characters"),
});

type LeaveApplicationForm = z.infer<typeof leaveApplicationSchema>;

const LeaveTypeLabels = {
  casual: "Casual Leave",
  sick: "Sick Leave",
  earned: "Earned Leave",
  maternity: "Maternity Leave",
  paternity: "Paternity Leave",
  comp_off: "Compensatory Off",
  lwp: "Leave Without Pay"
};

const StatusBadges = {
  pending: { color: "bg-yellow-100 text-yellow-800", label: "Pending" },
  approved: { color: "bg-green-100 text-green-800", label: "Approved" },
  rejected: { color: "bg-red-100 text-red-800", label: "Rejected" },
  cancelled: { color: "bg-gray-100 text-gray-800", label: "Cancelled" }
};

export default function LeaveApplication() {
  const { toast } = useToast();
  const [applicationDialogOpen, setApplicationDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedLeave, setSelectedLeave] = useState<LeaveRequest | null>(null);
  
  // Check for leave permission
  const { hasPermission: canManageLeave, loading: permissionLoading } = usePermission('leave_request_submit');

  const form = useForm<LeaveApplicationForm>({
    resolver: zodResolver(leaveApplicationSchema),
    defaultValues: {
      leaveType: 'casual',
      startDate: '',
      endDate: '',
      reason: '',
    },
  });

  // Get current user
  const { data: user } = useQuery<{ id: number; companyId: number; role: string }>({
    queryKey: ['/api/auth/me'],
  });

  const companyId = user?.companyId;

  // Fetch leave requests
  const { data: leaveRequests = [], isLoading } = useQuery<LeaveRequest[]>({
    queryKey: ['leave-requests', companyId],
    queryFn: async () => {
      if (!companyId) throw new Error('No company ID');
      
      const token = localStorage.getItem('auth_token');
      const response = await fetch(`/api/leave-requests/${companyId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      return response.json();
    },
    enabled: !!companyId,
  });

  // Submit leave application
  const submitMutation = useMutation({
    mutationFn: async (data: LeaveApplicationForm) => {
      const startDate = new Date(data.startDate);
      const endDate = new Date(data.endDate);
      const timeDiff = endDate.getTime() - startDate.getTime();
      const totalDays = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;

      const leaveData: InsertLeaveRequest = {
        ...data,
        companyId: companyId!,
        employeeId: user!.id,
        totalDays: totalDays.toString(),
      };

      const response = await apiRequest('POST', '/api/leave-requests', leaveData);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Leave application submitted successfully",
      });
      setApplicationDialogOpen(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['leave-requests', companyId] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit leave application",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: LeaveApplicationForm) => {
    // Validate dates
    const startDate = new Date(data.startDate);
    const endDate = new Date(data.endDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (startDate < today) {
      form.setError("startDate", { message: "Start date cannot be in the past" });
      return;
    }

    if (endDate < startDate) {
      form.setError("endDate", { message: "End date cannot be before start date" });
      return;
    }

    submitMutation.mutate(data);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getApprovalStatus = (leave: LeaveRequest) => {
    if (leave.status === 'rejected') return 'Rejected';
    if (leave.status === 'approved') return 'Fully Approved';
    
    // Check approval levels
    if (leave.finalApprovedAt) return 'Final Approved';
    if (leave.level2ApprovedAt) return 'Level 2 Approved';
    if (leave.level1ApprovedAt) return 'Level 1 Approved';
    
    return 'Pending Approval';
  };

  // Permission guard - show access denied if user doesn't have permission
  if (permissionLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
            <p className="mt-2 text-gray-600">Checking permissions...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!canManageLeave && user?.role === 'employee') {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <ShieldAlert className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-4">You don't have permission to access leave management.</p>
            <p className="text-sm text-gray-500">Please request the "leave_request_submit" permission from your administrator.</p>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Loading leave applications...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Leave Applications</h1>
          <p className="text-gray-600">Apply for leave and track approval status</p>
        </div>
        <Dialog open={applicationDialogOpen} onOpenChange={setApplicationDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Apply for Leave
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Apply for Leave</DialogTitle>
              <DialogDescription>
                Submit your leave application for approval
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="leaveType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Leave Type</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select leave type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Object.entries(LeaveTypeLabels).map(([value, label]) => (
                            <SelectItem key={value} value={value}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="endDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="reason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reason</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Please provide reason for leave..." 
                          className="min-h-[80px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setApplicationDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={submitMutation.isPending}>
                    {submitMutation.isPending ? "Submitting..." : "Submit Application"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Leave Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{leaveRequests.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {leaveRequests.filter(req => req.status === 'pending').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {leaveRequests.filter(req => req.status === 'approved').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Rejected</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              {leaveRequests.filter(req => req.status === 'rejected').length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Leave Applications List */}
      <Card>
        <CardHeader>
          <CardTitle>My Leave Applications</CardTitle>
          <CardDescription>Track your leave application status and approval progress</CardDescription>
        </CardHeader>
        <CardContent>
          {leaveRequests.length === 0 ? (
            <div className="text-center py-8">
              <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No leave applications found</p>
              <p className="text-sm text-gray-400">Apply for your first leave to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {leaveRequests.map((leave) => (
                <div key={leave.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <div>
                          <h3 className="font-semibold text-lg">
                            {LeaveTypeLabels[leave.leaveType as keyof typeof LeaveTypeLabels]}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {formatDate(leave.startDate)} to {formatDate(leave.endDate)} • {leave.totalDays} day(s)
                          </p>
                        </div>
                      </div>
                      <p className="text-gray-700 mt-2 line-clamp-2">{leave.reason}</p>
                      <div className="mt-2 flex items-center space-x-4">
                        <Badge className={StatusBadges[leave.status as keyof typeof StatusBadges].color}>
                          {StatusBadges[leave.status as keyof typeof StatusBadges].label}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          Applied: {formatDate(leave.appliedAt.toString())}
                        </span>
                        <span className="text-sm text-gray-600">
                          Status: {getApprovalStatus(leave)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedLeave(leave);
                          setViewDialogOpen(true);
                        }}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Leave Details Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Leave Application Details</DialogTitle>
          </DialogHeader>
          {selectedLeave && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Leave Type</label>
                  <p>{LeaveTypeLabels[selectedLeave.leaveType as keyof typeof LeaveTypeLabels]}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Duration</label>
                  <p>{selectedLeave.totalDays} day(s)</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Start Date</label>
                  <p>{formatDate(selectedLeave.startDate)}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">End Date</label>
                  <p>{formatDate(selectedLeave.endDate)}</p>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500">Reason</label>
                <p className="mt-1 p-3 bg-gray-50 rounded-md">{selectedLeave.reason}</p>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500">Approval Status</label>
                <div className="mt-2 space-y-2">
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Level 1 Approval</span>
                    <Badge className={selectedLeave.level1ApprovedAt ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                      {selectedLeave.level1ApprovedAt ? "Approved" : "Pending"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Level 2 Approval</span>
                    <Badge className={selectedLeave.level2ApprovedAt ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                      {selectedLeave.level2ApprovedAt ? "Approved" : "Pending"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Final Approval</span>
                    <Badge className={selectedLeave.finalApprovedAt ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                      {selectedLeave.finalApprovedAt ? "Approved" : "Pending"}
                    </Badge>
                  </div>
                </div>
              </div>

              {selectedLeave.rejectionReason && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Rejection Reason</label>
                  <p className="mt-1 p-3 bg-red-50 border border-red-200 rounded-md text-red-800">
                    {selectedLeave.rejectionReason}
                  </p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}