import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { UserPlus, Edit, Trash2, Search, KeyRound } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

export default function UserManagement() {
  const { user: currentUser } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [deleteConfirmDialog, setDeleteConfirmDialog] = useState<{open: boolean, userId: number, userName: string}>({
    open: false,
    userId: 0,
    userName: ''
  });
  const [passwordResetDialog, setPasswordResetDialog] = useState<{open: boolean, userId: number, userName: string}>({
    open: false,
    userId: 0,
    userName: ''
  });
  const [newPassword, setNewPassword] = useState("");

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['/api/users'],
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['/api/admin/companies'],
    enabled: currentUser?.role === 'system_admin',
  });

  const createUserMutation = useMutation({
    mutationFn: (userData: any) => apiRequest('POST', '/api/users', userData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setIsCreateDialogOpen(false);
      toast({ title: "User created successfully" });
    },
    onError: () => {
      toast({ title: "Failed to create user", variant: "destructive" });
    },
  });

  const updateUserMutation = useMutation({
    mutationFn: ({ id, ...data }: any) => apiRequest('PUT', `/api/users/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({ title: "User updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update user", variant: "destructive" });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/users/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({ title: "User deleted successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Failed to delete user", description: error.message || "Unknown error", variant: "destructive" });
    },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: ({ userId, newPassword }: { userId: number, newPassword: string }) => 
      apiRequest('PUT', `/api/users/${userId}/password`, { newPassword }),
    onSuccess: () => {
      setPasswordResetDialog({ open: false, userId: 0, userName: '' });
      setNewPassword('');
      toast({ title: "Password reset successfully" });
    },
    onError: (error: any) => {
      toast({ title: "Failed to reset password", description: error.message || "Unknown error", variant: "destructive" });
    },
  });

  const filteredUsers = users.filter((u: any) =>
    u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCreateUser = (formData: FormData) => {
    const userData = {
      username: formData.get('username'),
      email: formData.get('email'),
      password: formData.get('password'),
      role: formData.get('role'),
      companyId: currentUser?.role === 'system_admin' ? 
        parseInt(formData.get('companyId') as string) : 
        currentUser?.companyId,
    };
    createUserMutation.mutate(userData);
  };

  const toggleUserStatus = (userId: number, isActive: boolean) => {
    updateUserMutation.mutate({ id: userId, isActive: !isActive });
  };

  if (isLoading) {
    return <div>Loading users...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">User Management</h1>
          <p className="text-muted-foreground">
            Manage user accounts and permissions
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <UserPlus className="mr-2 h-4 w-4" />
              Add User
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New User</DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => {
              e.preventDefault();
              handleCreateUser(new FormData(e.currentTarget));
            }} className="space-y-4">
              <div>
                <label className="text-sm font-medium">Username</label>
                <Input name="username" required />
              </div>
              <div>
                <label className="text-sm font-medium">Email</label>
                <Input name="email" type="email" required />
              </div>
              <div>
                <label className="text-sm font-medium">Password</label>
                <Input name="password" type="password" required />
              </div>
              <div>
                <label className="text-sm font-medium">Role</label>
                <Select name="role" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    {currentUser?.role === 'system_admin' && (
                      <SelectItem value="system_admin">System Admin</SelectItem>
                    )}
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="employee">Employee</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {currentUser?.role === 'system_admin' && (
                <div>
                  <label className="text-sm font-medium">Company</label>
                  <Select name="companyId" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select company" />
                    </SelectTrigger>
                    <SelectContent>
                      {companies.map((company: any) => (
                        <SelectItem key={company.id} value={company.id.toString()}>
                          {company.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="flex gap-2">
                <Button type="submit" disabled={createUserMutation.isPending}>
                  {createUserMutation.isPending ? 'Creating...' : 'Create User'}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={deleteConfirmDialog.open} onOpenChange={(open) => 
        setDeleteConfirmDialog(prev => ({ ...prev, open }))
      }>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Delete User</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>Are you sure you want to delete user <strong>{deleteConfirmDialog.userName}</strong>?</p>
            <p className="text-sm text-red-600">This action cannot be undone.</p>
            <div className="flex gap-2">
              <Button 
                variant="destructive"
                onClick={() => {
                  deleteUserMutation.mutate(deleteConfirmDialog.userId);
                  setDeleteConfirmDialog({ open: false, userId: 0, userName: '' });
                }}
                disabled={deleteUserMutation.isPending}
              >
                {deleteUserMutation.isPending ? 'Deleting...' : 'Delete User'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setDeleteConfirmDialog({ open: false, userId: 0, userName: '' })}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Password Reset Dialog */}
      <Dialog open={passwordResetDialog.open} onOpenChange={(open) => {
        setPasswordResetDialog(prev => ({ ...prev, open }));
        if (!open) setNewPassword('');
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>Reset password for user <strong>{passwordResetDialog.userName}</strong></p>
            <div>
              <label className="text-sm font-medium">New Password</label>
              <Input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new password (min 6 characters)"
                minLength={6}
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => {
                  if (newPassword.length < 6) {
                    toast({ title: "Password must be at least 6 characters", variant: "destructive" });
                    return;
                  }
                  resetPasswordMutation.mutate({ 
                    userId: passwordResetDialog.userId, 
                    newPassword 
                  });
                }}
                disabled={resetPasswordMutation.isPending || !newPassword}
              >
                {resetPasswordMutation.isPending ? 'Resetting...' : 'Reset Password'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setPasswordResetDialog({ open: false, userId: 0, userName: '' });
                  setNewPassword('');
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle>Users</CardTitle>
          <div className="flex items-center space-x-2">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search users..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((userItem: any) => (
                <TableRow key={userItem.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{userItem.username}</div>
                      <div className="text-sm text-muted-foreground">{userItem.email}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={
                      userItem.role === 'system_admin' ? 'destructive' :
                      userItem.role === 'admin' ? 'default' : 'secondary'
                    }>
                      {userItem.role.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {userItem.companyId 
                      ? companies.find((c: any) => c.id === userItem.companyId)?.name || `Company ${userItem.companyId}`
                      : 'System User'}
                  </TableCell>
                  <TableCell>
                    <Badge variant={userItem.isActive ? 'default' : 'secondary'}>
                      {userItem.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {new Date(userItem.createdAt).toLocaleDateString()}
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleUserStatus(userItem.id, userItem.isActive)}
                        disabled={updateUserMutation.isPending}
                      >
                        {userItem.isActive ? 'Deactivate' : 'Activate'}
                      </Button>
                      {/* System Admin can reset password for any user */}
                      {currentUser?.role === 'system_admin' && userItem.id !== currentUser?.id && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setPasswordResetDialog({
                            open: true,
                            userId: userItem.id,
                            userName: userItem.username
                          })}
                          disabled={resetPasswordMutation.isPending}
                        >
                          <KeyRound className="h-3 w-3" />
                        </Button>
                      )}
                      {/* System admin can delete any user, admin can delete users in same company */}
                      {(currentUser?.role === 'system_admin' || 
                        (currentUser?.role === 'admin' && userItem.companyId === currentUser?.companyId)) && 
                        userItem.id !== currentUser?.id && (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => setDeleteConfirmDialog({
                            open: true,
                            userId: userItem.id,
                            userName: userItem.username
                          })}
                          disabled={deleteUserMutation.isPending}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}