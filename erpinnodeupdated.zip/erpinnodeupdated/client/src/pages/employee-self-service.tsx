import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Edit, Save, User, MapPin, Phone, Mail, Briefcase, Calendar, 
  Search, FileText, Download, Clock, Building2, Star, CheckCircle, 
  AlertCircle, BookOpen, Award, GraduationCap, PlusCircle, X,
  Camera, Heart, Target, CreditCard, UserCheck
} from "lucide-react";
import { useAuth, apiRequestWithAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import type { EmployeeProfile } from "@shared/schema";

// Split schemas for separate sections
const basicInfoSchema = z.object({
  fullName: z.string().min(1, "Full name is required"),
  fatherHusbandName: z.string().optional(),
  aadhaarNo: z.string().refine(
    (val) => !val || /^\d{12}$/.test(val.replace(/\s/g, "")),
    "Aadhaar number must be 12 digits"
  ).optional(),
  panNo: z.string().refine(
    (val) => !val || /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(val.toUpperCase()),
    "PAN number format: ABCDE1234F"
  ).optional(),
  dateOfBirth: z.string().optional(),
  gender: z.union([z.enum(["male", "female", "other"]), z.literal("")]).optional(),
  maritalStatus: z.union([z.enum(["single", "married", "divorced", "widowed"]), z.literal("")]).optional(),
  address: z.string().optional(),
  state: z.string().optional(),
  district: z.string().optional(),
  pinCode: z.string().refine(
    (val) => !val || /^\d{6}$/.test(val),
    "Pin code must be 6 digits"
  ).optional(),
  phone: z.string().optional(),
  hobbies: z.string().optional(),
  strength: z.string().optional(),
  profilePhoto: z.string().optional(),
});

const professionalInfoSchema = z.object({
  speciality: z.string().optional(),
  currentSalary: z.string().optional(),
  expectedSalary: z.string().optional(),
  noticePeriod: z.string().optional(),
  totalExperience: z.string().optional(),
  skills: z.string().optional(),
  experience: z.string().optional(),
});

type BasicInfoFormData = z.infer<typeof basicInfoSchema>;
type ProfessionalInfoFormData = z.infer<typeof professionalInfoSchema>;

// Helper function to calculate age from date of birth
const calculateAge = (dateOfBirth: string): number => {
  if (!dateOfBirth) return 0;
  const today = new Date();
  const birthDate = new Date(dateOfBirth);
  let age = today.getFullYear() - birthDate.getFullYear();
  const monthDiff = today.getMonth() - birthDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age;
};

export default function EmployeeSelfService() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditingBasic, setIsEditingBasic] = useState(false);
  const [isEditingProfessional, setIsEditingProfessional] = useState(false);

  // Fetch employee profile
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/employee/profile"],
    queryFn: async () => {
      const response = await apiRequestWithAuth("GET", "/api/employee/profile");
      if (!response.ok) {
        throw new Error('Failed to fetch profile');
      }
      return response.json();
    },
  });

  // Basic Information Form
  const basicForm = useForm<BasicInfoFormData>({
    resolver: zodResolver(basicInfoSchema),
  });

  const { register: registerBasic, handleSubmit: handleSubmitBasic, watch: watchBasic, setValue: setValueBasic, formState: { errors: errorsBasic } } = basicForm;

  // Professional Information Form  
  const professionalForm = useForm<ProfessionalInfoFormData>({
    resolver: zodResolver(professionalInfoSchema),
  });

  const { register: registerProfessional, handleSubmit: handleSubmitProfessional, watch: watchProfessional, setValue: setValueProfessional, formState: { errors: errorsProfessional } } = professionalForm;

  // Watch dateOfBirth to auto-calculate age
  const dateOfBirth = watchBasic('dateOfBirth');
  const [calculatedAge, setCalculatedAge] = React.useState<number>(0);
  
  React.useEffect(() => {
    if (dateOfBirth) {
      const age = calculateAge(dateOfBirth);
      setCalculatedAge(age);
    }
  }, [dateOfBirth]);

  // Initialize forms when profile loads
  React.useEffect(() => {
    if (profile) {
      // Map server data to Basic Info form
      const basicData = {
        fullName: profile.fullName || [profile.firstName, profile.lastName].filter(Boolean).join(' '),
        fatherHusbandName: profile.fatherHusbandName || profile.fatherName || '',
        aadhaarNo: profile.aadhaarNo || profile.aadharNumber || '',
        panNo: profile.panNo || profile.panNumber || '',
        dateOfBirth: profile.dateOfBirth || '',
        gender: profile.gender || '',
        maritalStatus: profile.maritalStatus || '',
        address: profile.address || profile.presentAddress || '',
        state: profile.state || '',
        district: profile.district || '',
        pinCode: profile.pinCode || '',
        phone: profile.phone || profile.primaryContact || '',
        hobbies: profile.hobbies || '',
        strength: profile.strength || '',
        profilePhoto: profile.profilePhoto || '',
      };
      basicForm.reset(basicData);

      // Map server data to Professional Info form
      const professionalData = {
        speciality: profile.speciality || '',
        currentSalary: profile.currentSalary || '',
        expectedSalary: profile.expectedSalary || '',
        noticePeriod: profile.noticePeriod || '',
        totalExperience: profile.totalExperience || '',
        skills: profile.skills || '',
        experience: profile.experience || '',
      };
      professionalForm.reset(professionalData);
    }
  }, [profile, basicForm, professionalForm]);

  // Basic Information Save Mutation
  const updateBasicInfoMutation = useMutation({
    mutationFn: async (data: BasicInfoFormData) => {
      // Split fullName into firstName and lastName for backend
      const nameParts = data.fullName.trim().split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || '';
      
      // Prepare the data with firstName, lastName, and age
      const updateData = {
        firstName,
        lastName,
        fatherHusbandName: data.fatherHusbandName,
        aadhaarNo: data.aadhaarNo,
        panNo: data.panNo,
        dateOfBirth: data.dateOfBirth,
        age: data.dateOfBirth ? calculateAge(data.dateOfBirth).toString() : undefined,
        gender: data.gender,
        maritalStatus: data.maritalStatus,
        address: data.address,
        state: data.state,
        district: data.district,
        pinCode: data.pinCode,
        phone: data.phone,
        hobbies: data.hobbies,
        strength: data.strength,
        profilePhoto: data.profilePhoto,
      };

      const response = await apiRequestWithAuth("PUT", "/api/employee/profile", updateData);
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Update failed' }));
        throw new Error(errorData.message || 'Failed to update profile');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employee/profile"] });
      setIsEditingBasic(false);
      toast({
        title: "Success",
        description: "Basic information updated successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update basic information",
        variant: "destructive",
      });
    },
  });

  // Professional Information Save Mutation
  const updateProfessionalInfoMutation = useMutation({
    mutationFn: async (data: ProfessionalInfoFormData) => {
      const response = await apiRequestWithAuth("PUT", "/api/employee/profile", data);
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Update failed' }));
        throw new Error(errorData.message || 'Failed to update profile');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employee/profile"] });
      setIsEditingProfessional(false);
      toast({
        title: "Success",
        description: "Professional information updated successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update professional information",
        variant: "destructive",
      });
    },
  });

  // Submit Handlers
  const onSubmitBasic = (data: BasicInfoFormData) => {
    updateBasicInfoMutation.mutate(data);
  };

  const onSubmitProfessional = (data: ProfessionalInfoFormData) => {
    updateProfessionalInfoMutation.mutate(data);
  };

  const downloadResume = async () => {
    try {
      const response = await apiRequestWithAuth("GET", "/api/employee/resume");
      
      if (!response.ok) {
        throw new Error('Failed to download resume');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      const fullName = profile?.fullName || (profile?.firstName && profile?.lastName ? `${profile.firstName}_${profile.lastName}` : 'User');
      const fileName = fullName.replace(/\s+/g, '_').replace(/[^\w\-_\.]/g, '');
      a.download = `${fileName}_Resume.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download resume",
        variant: "destructive",
      });
    }
  };

  if (profileLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Employee Self Service</h1>
          <p className="text-gray-600 mt-1">Manage your complete profile information across all areas</p>
        </div>
        <Avatar className="h-16 w-16">
          {profile?.profilePhoto ? (
            <img src={profile.profilePhoto} alt="Profile" className="h-16 w-16 rounded-full object-cover" />
          ) : (
            <AvatarFallback className="bg-primary text-primary-foreground text-xl">
              {profile?.fullName?.[0] || profile?.firstName?.[0] || "U"}
            </AvatarFallback>
          )}
        </Avatar>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            My Profile
          </TabsTrigger>
          <TabsTrigger value="professional" className="flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            Professional Information
          </TabsTrigger>
          <TabsTrigger value="education" className="flex items-center gap-2">
            <GraduationCap className="h-4 w-4" />
            Educational Qualification
          </TabsTrigger>
          <TabsTrigger value="family" className="flex items-center gap-2">
            <UserCheck className="h-4 w-4" />
            Family Details
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Basic Information
                  </CardTitle>
                  <CardDescription>Update your personal details</CardDescription>
                </div>
                <div className="flex gap-2">
                  {isEditingBasic ? (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setIsEditingBasic(false);
                          basicForm.reset();
                        }}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Cancel
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={handleSubmitBasic(onSubmitBasic)}
                        disabled={updateBasicInfoMutation.isPending}
                      >
                        {updateBasicInfoMutation.isPending ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-1"></div>
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="h-4 w-4 mr-1" />
                            Save
                          </>
                        )}
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => setIsEditingBasic(true)}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isEditingBasic ? (
                <form className="space-y-6">
                  {/* Personal Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Personal Information
                    </h3>
                    
                    <div>
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input {...registerBasic("fullName")} placeholder="Enter your full name" />
                      {errorsBasic.fullName && (
                        <p className="text-sm text-red-500">{errorsBasic.fullName.message}</p>
                      )}
                    </div>

                    <div>
                      <Label htmlFor="fatherHusbandName">Father/Husband Name</Label>
                      <Input {...registerBasic("fatherHusbandName")} placeholder="Enter father or husband name" />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="dateOfBirth">Date of Birth</Label>
                        <Input type="date" {...registerBasic("dateOfBirth")} />
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Age (Auto Calculated)</Label>
                        <Input 
                          type="number" 
                          value={calculatedAge || ''} 
                          readOnly 
                          className="bg-gray-50 text-gray-700" 
                          placeholder="Auto calculated"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="gender">Gender</Label>
                        <Select 
                          value={watchBasic("gender")} 
                          onValueChange={(value) => setValueBasic("gender", value as "male" | "female" | "other", { shouldDirty: true })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select gender" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="maritalStatus">Marital Status</Label>
                        <Select 
                          value={watchBasic("maritalStatus")} 
                          onValueChange={(value) => setValueBasic("maritalStatus", value as "single" | "married" | "divorced" | "widowed", { shouldDirty: true })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select marital status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="single">Single</SelectItem>
                            <SelectItem value="married">Married</SelectItem>
                            <SelectItem value="divorced">Divorced</SelectItem>
                            <SelectItem value="widowed">Widowed</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>

                  {/* Government IDs */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Government IDs
                    </h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="aadhaarNo">Aadhaar Number</Label>
                        <Input {...registerBasic("aadhaarNo")} placeholder="1234 5678 9012" maxLength={14} />
                        {errorsBasic.aadhaarNo && (
                          <p className="text-sm text-red-500">{errorsBasic.aadhaarNo.message}</p>
                        )}
                      </div>
                      <div>
                        <Label htmlFor="panNo">PAN Number</Label>
                        <Input {...registerBasic("panNo")} placeholder="ABCDE1234F" maxLength={10} style={{textTransform: 'uppercase'}} />
                        {errorsBasic.panNo && (
                          <p className="text-sm text-red-500">{errorsBasic.panNo.message}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Address Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <MapPin className="h-5 w-5" />
                      Address Information
                    </h3>
                    
                    <div>
                      <Label htmlFor="address">Complete Address</Label>
                      <Textarea {...registerBasic("address")} placeholder="House/Flat No, Street, Area, City" rows={2} />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="state">State</Label>
                        <Input {...registerBasic("state")} placeholder="Enter state" />
                      </div>
                      <div>
                        <Label htmlFor="district">District</Label>
                        <Input {...registerBasic("district")} placeholder="Enter district" />
                      </div>
                      <div>
                        <Label htmlFor="pinCode">Pin Code</Label>
                        <Input {...registerBasic("pinCode")} placeholder="123456" maxLength={6} />
                        {errorsBasic.pinCode && (
                          <p className="text-sm text-red-500">{errorsBasic.pinCode.message}</p>
                        )}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input {...registerBasic("phone")} placeholder="Enter phone number" />
                    </div>
                  </div>

                  {/* Personal Interests */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <Heart className="h-5 w-5" />
                      Personal Interests
                    </h3>
                    
                    <div>
                      <Label htmlFor="hobbies">Hobbies</Label>
                      <Textarea {...registerBasic("hobbies")} placeholder="Reading, Cricket, Music, Traveling..." rows={2} />
                    </div>

                    <div>
                      <Label htmlFor="strength">Strengths</Label>
                      <Textarea {...registerBasic("strength")} placeholder="Leadership, Communication, Problem Solving..." rows={2} />
                    </div>
                  </div>
                </form>
              ) : (
                <div className="space-y-6">
                  {/* Personal Information */}
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <User className="h-5 w-5" />
                      Personal Information
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm text-gray-500">Full Name</Label>
                        <p className="font-medium">{profile?.fullName || profile?.firstName + " " + (profile?.lastName || "") || "Not specified"}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Father/Husband Name</Label>
                        <p className="font-medium">{profile?.fatherHusbandName || "Not specified"}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm text-gray-500">Date of Birth</Label>
                        <p className="font-medium">{profile?.dateOfBirth ? new Date(profile.dateOfBirth).toLocaleDateString() : "Not specified"}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Age</Label>
                        <p className="font-medium">{profile?.dateOfBirth ? calculateAge(profile.dateOfBirth) + " years" : "Not calculated"}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm text-gray-500">Gender</Label>
                        <p className="font-medium capitalize">{profile?.gender || "Not specified"}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Marital Status</Label>
                        <p className="font-medium capitalize">{profile?.maritalStatus || "Not specified"}</p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Government IDs */}
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <CreditCard className="h-5 w-5" />
                      Government IDs
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm text-gray-500">Aadhaar Number</Label>
                        <p className="font-medium">{profile?.aadhaarNo ? profile.aadhaarNo.replace(/(\d{4})(?=\d)/g, '$1 ') : "Not provided"}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">PAN Number</Label>
                        <p className="font-medium uppercase">{profile?.panNo || "Not provided"}</p>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Address Information */}
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <MapPin className="h-5 w-5" />
                      Address Information
                    </h3>
                    <div>
                      <Label className="text-sm text-gray-500">Complete Address</Label>
                      <p className="font-medium">{profile?.address || "Not provided"}</p>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label className="text-sm text-gray-500">State</Label>
                        <p className="font-medium">{profile?.state || "Not specified"}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">District</Label>
                        <p className="font-medium">{profile?.district || "Not specified"}</p>
                      </div>
                      <div>
                        <Label className="text-sm text-gray-500">Pin Code</Label>
                        <p className="font-medium">{profile?.pinCode || "Not specified"}</p>
                      </div>
                    </div>
                    <div>
                      <Label className="text-sm text-gray-500">Phone Number</Label>
                      <p className="font-medium">{profile?.phone || "Not provided"}</p>
                    </div>
                  </div>

                  <Separator />

                  {/* Personal Interests */}
                  <div className="space-y-3">
                    <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                      <Heart className="h-5 w-5" />
                      Personal Interests
                    </h3>
                    <div>
                      <Label className="text-sm text-gray-500">Hobbies</Label>
                      <p className="font-medium">{profile?.hobbies || "Not specified"}</p>
                    </div>
                    <div>
                      <Label className="text-sm text-gray-500">Strengths</Label>
                      <p className="font-medium">{profile?.strength || "Not specified"}</p>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Professional Information Tab */}
        <TabsContent value="professional">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Briefcase className="h-5 w-5" />
                    Professional Information
                  </CardTitle>
                  <CardDescription>Your career details and experience</CardDescription>
                </div>
                <div className="flex gap-2">
                  {isEditingProfessional ? (
                    <>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setIsEditingProfessional(false);
                          professionalForm.reset();
                        }}
                      >
                        <X className="h-4 w-4 mr-1" />
                        Cancel
                      </Button>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={handleSubmitProfessional(onSubmitProfessional)}
                        disabled={updateProfessionalInfoMutation.isPending}
                      >
                        {updateProfessionalInfoMutation.isPending ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-1"></div>
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="h-4 w-4 mr-1" />
                            Save
                          </>
                        )}
                      </Button>
                    </>
                  ) : (
                    <Button
                      variant="default"
                      size="sm"
                      onClick={() => setIsEditingProfessional(true)}
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Edit
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {isEditingProfessional ? (
                <form className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="speciality">Specialization</Label>
                      <Input {...registerProfessional("speciality")} placeholder="Enter your specialization" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="currentSalary">Current Salary</Label>
                        <Input {...registerProfessional("currentSalary")} placeholder="Enter current salary" />
                      </div>
                      <div>
                        <Label htmlFor="expectedSalary">Expected Salary</Label>
                        <Input {...registerProfessional("expectedSalary")} placeholder="Enter expected salary" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="totalExperience">Total Experience</Label>
                        <Input {...registerProfessional("totalExperience")} placeholder="e.g., 5 years" />
                      </div>
                      <div>
                        <Label htmlFor="noticePeriod">Notice Period</Label>
                        <Input {...registerProfessional("noticePeriod")} placeholder="e.g., 30 days" />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="skills">Skills (comma separated)</Label>
                      <Textarea {...registerProfessional("skills")} placeholder="React, Node.js, Python, etc." rows={2} />
                    </div>

                    <div>
                      <Label htmlFor="experience">Experience Details</Label>
                      <Textarea {...registerProfessional("experience")} placeholder="Describe your work experience..." rows={4} />
                    </div>
                  </div>
                </form>
              ) : (
                <>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <Label className="text-sm text-gray-500">Specialization</Label>
                        <p className="font-medium">{profile?.speciality || "Not specified"}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-sm text-gray-500">Current Salary</Label>
                          <p className="font-medium">{profile?.currentSalary || "Not specified"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Expected Salary</Label>
                          <p className="font-medium">{profile?.expectedSalary || "Not specified"}</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-sm text-gray-500">Experience</Label>
                          <p className="font-medium">{profile?.totalExperience || "Not specified"}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Notice Period</Label>
                          <p className="font-medium">{profile?.noticePeriod || "Not specified"}</p>
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <Button variant="outline" onClick={downloadResume} className="flex items-center gap-2">
                        <Download className="h-4 w-4" />
                        Download Resume
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm text-gray-500">Skills</Label>
                      {profile?.skills ? (
                        <div className="flex flex-wrap gap-2 mt-1">
                          {profile.skills.split(',').map((skill: string, index: number) => (
                            <Badge key={index} variant="secondary">{skill.trim()}</Badge>
                          ))}
                        </div>
                      ) : (
                        <p className="font-medium">Not specified</p>
                      )}
                    </div>
                    <div>
                      <Label className="text-sm text-gray-500">Experience Details</Label>
                      <p className="font-medium">{profile?.experience || "Not specified"}</p>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Educational Qualification Tab */}
        <TabsContent value="education">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="h-5 w-5" />
                    Educational Qualification
                  </CardTitle>
                  <CardDescription>Your academic background and certifications</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add Education
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <GraduationCap className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="font-medium text-gray-900 mb-2">No educational qualifications added yet.</h3>
                <p className="text-gray-500">Click "Add Education" to get started.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Family Details Tab */}
        <TabsContent value="family">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <UserCheck className="h-5 w-5" />
                    Family Details
                  </CardTitle>
                  <CardDescription>Information about your family members</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Add Family Member
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <UserCheck className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="font-medium text-gray-900 mb-2">No family details added yet.</h3>
                <p className="text-gray-500">Click "Add Family Member" to get started.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Documents
                  </CardTitle>
                  <CardDescription>Upload and manage your important documents</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  Upload Document
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card className="border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <FileText className="h-8 w-8 text-gray-400 mb-3" />
                    <p className="font-medium text-sm">Resume</p>
                    <p className="text-xs text-gray-500 mb-3">PDF, DOC, DOCX</p>
                    <Button variant="outline" size="sm">Upload</Button>
                  </CardContent>
                </Card>
                
                <Card className="border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <FileText className="h-8 w-8 text-gray-400 mb-3" />
                    <p className="font-medium text-sm">Aadhaar Card</p>
                    <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                    <Button variant="outline" size="sm">Upload</Button>
                  </CardContent>
                </Card>
                
                <Card className="border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <FileText className="h-8 w-8 text-gray-400 mb-3" />
                    <p className="font-medium text-sm">PAN Card</p>
                    <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                    <Button variant="outline" size="sm">Upload</Button>
                  </CardContent>
                </Card>
                
                <Card className="border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <FileText className="h-8 w-8 text-gray-400 mb-3" />
                    <p className="font-medium text-sm">Educational Certificates</p>
                    <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                    <Button variant="outline" size="sm">Upload</Button>
                  </CardContent>
                </Card>
                
                <Card className="border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <FileText className="h-8 w-8 text-gray-400 mb-3" />
                    <p className="font-medium text-sm">Experience Letters</p>
                    <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                    <Button variant="outline" size="sm">Upload</Button>
                  </CardContent>
                </Card>
                
                <Card className="border-dashed border-2">
                  <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                    <FileText className="h-8 w-8 text-gray-400 mb-3" />
                    <p className="font-medium text-sm">Other Documents</p>
                    <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                    <Button variant="outline" size="sm">Upload</Button>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
