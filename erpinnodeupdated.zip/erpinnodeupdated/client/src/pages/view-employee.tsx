import { useQuery } from "@tanstack/react-query";
import { authService, apiRequestWithAuth } from "@/lib/auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, User, Briefcase, MapPin, CreditCard, Clock, Users, Edit, Phone, Mail, Shield, UserCheck, FileText } from "lucide-react";
import { type Employee, type Department } from "@shared/schema";

interface ViewEmployeePageProps {
  params: { id: string };
}

export default function ViewEmployeePage({ params }: ViewEmployeePageProps) {
  const [, setLocation] = useLocation();
  const employeeId = parseInt(params.id);
  
  const user = authService.getUser();
  const companyId = user?.companyId;

  // Fetch employee data
  const { data: employee, isLoading: employeeLoading } = useQuery<Employee>({
    queryKey: [`/api/employees/${companyId}/${employeeId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/employees/${companyId}/${employeeId}`);
      return response.json();
    },
    enabled: !!companyId && !!employeeId,
  });

  // Fetch departments
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: [`/api/departments/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/departments/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch designations
  const { data: designations = [] } = useQuery<any[]>({
    queryKey: [`/api/designations/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/designations/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch branches
  const { data: branches = [] } = useQuery<any[]>({
    queryKey: [`/api/branches/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/branches/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch locations
  const { data: locations = [] } = useQuery<any[]>({
    queryKey: [`/api/locations/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/locations/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch cost centers
  const { data: costCenters = [] } = useQuery<any[]>({
    queryKey: [`/api/cost-centers/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/cost-centers/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch all employees for manager name
  const { data: allEmployees = [] } = useQuery<any[]>({
    queryKey: [`/api/employees/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/employees/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch states
  const { data: states = [] } = useQuery<any[]>({
    queryKey: ['/api/states'],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', '/api/states');
      return response.json();
    },
  });

  // Fetch shifts
  const { data: shifts = [] } = useQuery<any[]>({
    queryKey: [`/api/shifts/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/shifts/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch biometric machines
  const { data: biometricMachines = [] } = useQuery<any[]>({
    queryKey: [`/api/biometric-machines/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/biometric-machines/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch leave policies
  const { data: leavePolicies = [] } = useQuery<any[]>({
    queryKey: [`/api/leave-policies/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/leave-policies/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch attendance locations
  const { data: attendanceLocations = [] } = useQuery<any[]>({
    queryKey: [`/api/attendance-locations/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/attendance-locations/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  const getDepartmentName = (departmentId: number | null) => {
    if (!departmentId) return 'Not assigned';
    const department = departments.find(d => d.id === departmentId);
    return department?.name || 'Unknown Department';
  };

  const getDesignationName = (designationId: number | null | string) => {
    if (!designationId) return 'Not assigned';
    const designation = designations.find(d => d.id.toString() === designationId.toString());
    return designation?.title || 'Not assigned';
  };

  const getBranchName = (branchId: number | null) => {
    if (!branchId) return 'Not assigned';
    const branch = branches.find(b => b.id === branchId);
    return branch?.name || 'Not assigned';
  };

  const getLocationName = (locationId: number | null) => {
    if (!locationId) return 'Not assigned';
    const location = locations.find(l => l.id === locationId);
    return location?.name || 'Not assigned';
  };

  const getCostCenterName = (costCenterId: number | null) => {
    if (!costCenterId) return 'Not assigned';
    const costCenter = costCenters.find(cc => cc.id === costCenterId);
    return costCenter ? `${costCenter.name} (${costCenter.code})` : 'Not assigned';
  };

  const getManagerName = (managerId: number | null) => {
    if (!managerId) return 'Not assigned';
    const manager = allEmployees.find(emp => emp.id === managerId);
    return manager ? `${manager.fullName} (${manager.employeeId})` : 'Not assigned';
  };

  const getStateName = (stateId: string | null) => {
    if (!stateId) return 'Not specified';
    const state = states.find(s => s.id.toString() === stateId.toString());
    return state?.name || 'Not specified';
  };

  const getShiftName = (shiftId: number | null) => {
    if (!shiftId) return 'Not assigned';
    const shift = shifts.find(s => s.id === shiftId);
    return shift ? `${shift.name} (${shift.startTime} - ${shift.endTime})` : 'Not assigned';
  };

  const getBiometricMachineName = (machineId: number | null) => {
    if (!machineId) return 'Not assigned';
    const machine = biometricMachines.find(m => m.id === machineId);
    return machine ? `${machine.serialNumber} - ${machine.location || 'No location'}` : 'Not assigned';
  };

  const getLeavePolicyName = (policyId: number | null) => {
    if (!policyId) return 'Not assigned';
    const policy = leavePolicies.find(p => p.id === policyId);
    return policy ? `${policy.name} (${policy.type})` : 'Not assigned';
  };

  const getAttendanceLocationName = (locationId: number | null) => {
    if (!locationId) return 'Not assigned';
    const location = attendanceLocations.find(l => l.id === locationId);
    return location?.name || 'Not assigned';
  };

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { label: 'Active', className: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' },
      inactive: { label: 'Inactive', className: 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200' },
      probation: { label: 'Probation', className: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' },
      terminated: { label: 'Terminated', className: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200' },
    };
    
    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.inactive;
    return <Badge className={config.className}>{config.label}</Badge>;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Not specified';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (employeeLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Employee Not Found</h2>
          <p className="text-gray-600 mb-4">The employee you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation('/admin/employees')}>
            Back to Employees
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation('/admin/employees')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Employees
          </Button>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">
              {employee.fullName}
            </h1>
            <div className="flex items-center gap-3 mt-1">
              <p className="text-muted-foreground">Employee ID: {employee.employeeId}</p>
              {getStatusBadge(employee.status)}
            </div>
          </div>
        </div>
        <Button
          onClick={() => setLocation(`/admin/employees/${employeeId}/edit`)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
        >
          <Edit className="h-4 w-4" />
          Edit Employee
        </Button>
      </div>

      {/* Employee Details */}
      <Tabs defaultValue="personal" className="space-y-6">
        <TabsList className="grid w-full grid-cols-9">
          <TabsTrigger value="personal" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Personal
          </TabsTrigger>
          <TabsTrigger value="employment" className="flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            Employment
          </TabsTrigger>
          <TabsTrigger value="contact" className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Contact
          </TabsTrigger>
          <TabsTrigger value="payroll" className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            Payroll
          </TabsTrigger>
          <TabsTrigger value="time" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Time Office
          </TabsTrigger>
          <TabsTrigger value="emergency" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Emergency
          </TabsTrigger>
          <TabsTrigger value="identity" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Identity
          </TabsTrigger>
          <TabsTrigger value="family" className="flex items-center gap-2">
            <UserCheck className="h-4 w-4" />
            Family
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
        </TabsList>

        {/* Personal Information */}
        <TabsContent value="personal">
          <Card>
            <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
              <CardTitle className="text-blue-700 dark:text-blue-300">Personal Information</CardTitle>
              <CardDescription>Basic employee details and identification</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Full Name</h4>
                  <p className="text-lg font-medium">{employee.fullName}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Employee ID</h4>
                  <p className="text-lg font-medium">{employee.employeeId}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Email</h4>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-gray-400" />
                    <p className="text-lg">{employee.email}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Phone</h4>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <p className="text-lg">{employee.phone || 'Not provided'}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Date of Birth</h4>
                  <p className="text-lg">{formatDate(employee.dateOfBirth)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Employment Information */}
        <TabsContent value="employment">
          <Card>
            <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
              <CardTitle className="text-green-700 dark:text-green-300">Employment Information</CardTitle>
              <CardDescription>Job role and department details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Designation</h4>
                  <p className="text-lg font-medium">{getDesignationName(employee.designation || employee.position)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Department</h4>
                  <p className="text-lg">{getDepartmentName(employee.departmentId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Branch</h4>
                  <p className="text-lg">{getBranchName(employee.branchId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Location</h4>
                  <p className="text-lg">{getLocationName(employee.locationId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Cost Center</h4>
                  <p className="text-lg">{getCostCenterName(employee.costCenterId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Reporting Manager</h4>
                  <p className="text-lg">{getManagerName(employee.managerId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Date of Join</h4>
                  <p className="text-lg">{formatDate(employee.hireDate)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Status</h4>
                  <div>{getStatusBadge(employee.status)}</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Contact Information */}
        <TabsContent value="contact">
          <Card>
            <CardHeader className="bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-950 dark:to-violet-950">
              <CardTitle className="text-purple-700 dark:text-purple-300">Contact Information</CardTitle>
              <CardDescription>Address and location details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8 pt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Present Address */}
                <div className="space-y-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <h3 className="font-semibold text-lg text-blue-800">Present Address</h3>
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Address</h4>
                      <p className="text-base">{employee.presentAddress || 'Not provided'}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">State</h4>
                        <p className="text-base">{getStateName(employee.presentState)}</p>
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">District</h4>
                        <p className="text-base">{employee.presentDistrict || 'Not specified'}</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Pin Code</h4>
                      <p className="text-base">{employee.presentPinCode || 'Not provided'}</p>
                    </div>
                  </div>
                </div>

                {/* Permanent Address */}
                <div className="space-y-4 p-4 bg-green-50 rounded-lg border border-green-200">
                  <h3 className="font-semibold text-lg text-green-800">Permanent Address</h3>
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Address</h4>
                      <p className="text-base">{employee.permanentAddress || 'Not provided'}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">State</h4>
                        <p className="text-base">{getStateName(employee.permanentState)}</p>
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">District</h4>
                        <p className="text-base">{employee.permanentDistrict || 'Not specified'}</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Pin Code</h4>
                      <p className="text-base">{employee.permanentPinCode || 'Not provided'}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payroll Information */}
        <TabsContent value="payroll">
          <Card>
            <CardHeader className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950 dark:to-orange-950">
              <CardTitle className="text-yellow-700 dark:text-yellow-300">Payroll Information</CardTitle>
              <CardDescription>Salary and compensation details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Salary</h4>
                  <p className="text-lg font-medium">
                    {employee.salary ? `₹${parseFloat(employee.salary).toLocaleString()}` : 'Not specified'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Time Office Policy */}
        <TabsContent value="time">
          <Card>
            <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-teal-950 dark:to-cyan-950">
              <CardTitle className="text-teal-700 dark:text-teal-300">Time Office Policy</CardTitle>
              <CardDescription>Working hours and attendance policies</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Duty Timing From</h4>
                  <p className="text-lg font-medium">{employee.dutyStartTime || 'Not set'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Duty Timing To</h4>
                  <p className="text-lg font-medium">{employee.dutyEndTime || 'Not set'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Late Arrival Allowed</h4>
                  <p className="text-lg">{employee.permissibleLateArrival ? `${employee.permissibleLateArrival} minutes` : 'Not set'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Early Departure Allowed</h4>
                  <p className="text-lg">{employee.permissibleEarlyDeparture ? `${employee.permissibleEarlyDeparture} minutes` : 'Not set'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Present Marking Duration</h4>
                  <p className="text-lg">{employee.presentMarkingDuration ? `${employee.presentMarkingDuration} hours` : 'Not set'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">First Weekly Off</h4>
                  <p className="text-lg capitalize">{employee.firstWeeklyOffDay || 'Not set'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Second Weekly Off</h4>
                  <p className="text-lg capitalize">{employee.secondWeeklyOffDay || 'Not set'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Overtime Applicable</h4>
                  <p className="text-lg">{employee.overtimeApplicable ? 'Yes' : 'No'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Shift Assignment</h4>
                  <p className="text-lg">{getShiftName(employee.shiftId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Biometric Device</h4>
                  <p className="text-lg">{getBiometricMachineName(employee.biometricMachineId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Leave Policy</h4>
                  <p className="text-lg">{getLeavePolicyName(employee.leavePolicyId)}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Attendance Location</h4>
                  <p className="text-lg">{getAttendanceLocationName(employee.attendanceLocationId)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Emergency Contact */}
        <TabsContent value="emergency">
          <Card>
            <CardHeader className="bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-950 dark:to-pink-950">
              <CardTitle className="text-red-700 dark:text-red-300">Emergency Contact</CardTitle>
              <CardDescription>Emergency contact information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Emergency Contact Name</h4>
                  <p className="text-lg">{employee.emergencyContact || 'Not provided'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Emergency Contact Phone</h4>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-400" />
                    <p className="text-lg">{employee.emergencyPhone || 'Not provided'}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Identity / KYC Details */}
        <TabsContent value="identity">
          <Card>
            <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
              <CardTitle className="text-indigo-700 dark:text-indigo-300">Identity / KYC Details</CardTitle>
              <CardDescription>Government identification and banking information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Aadhaar Number</h4>
                  <p className="text-lg">{employee.aadhaarNo || 'Not provided'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">PAN Number</h4>
                  <p className="text-lg">{employee.panNo || 'Not provided'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">Bank Account Number</h4>
                  <p className="text-lg">{employee.bankAccountNo || 'Not provided'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">IFSC Code</h4>
                  <p className="text-lg">{employee.ifscCode || 'Not provided'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">UAN Number</h4>
                  <p className="text-lg">{employee.uanNo || 'Not provided'}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium text-sm text-gray-500 uppercase tracking-wide">ESIC Number</h4>
                  <p className="text-lg">{employee.esicNo || 'Not provided'}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Family Details */}
        <TabsContent value="family">
          <Card>
            <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 dark:from-pink-950 dark:to-rose-950">
              <CardTitle className="text-pink-700 dark:text-pink-300">Family Details</CardTitle>
              <CardDescription>Information about family members</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="text-center py-8">
                <UserCheck className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="font-medium text-gray-900 mb-2">No family details on record</h3>
                <p className="text-gray-500">Family member information will appear here once added</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Documents */}
        <TabsContent value="documents">
          <Card>
            <CardHeader className="bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950 dark:to-yellow-950">
              <CardTitle className="text-amber-700 dark:text-amber-300">Documents</CardTitle>
              <CardDescription>Employee documents and certificates</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-6">
              <div className="text-center py-8">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="font-medium text-gray-900 mb-2">No documents uploaded</h3>
                <p className="text-gray-500">Documents will appear here once uploaded</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
