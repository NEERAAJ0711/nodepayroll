import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth, usePermission } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import AadharVerificationModal from "@/components/aadhar-verification-modal";


import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { Eye, Edit, MoreVertical, Trash2, Mail, Phone, Plus, Download, ShieldAlert } from "lucide-react";
import { type Employee } from "@shared/schema";
import { useLocation } from "wouter";

export default function EmployeesPage() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAadharModal, setShowAadharModal] = useState(false);
  
  const user = authService.getUser();
  const companyId = user?.companyId;
  const isSystemAdmin = user?.role === 'system_admin';
  
  // Check for employee list permission
  const { hasPermission: canViewEmployeeList, loading: permissionLoading } = usePermission('employee_list');

  // Fetch employees - System Admin gets all employees, others get company-specific
  const { data: employees = [], isLoading } = useQuery<Employee[]>({
    queryKey: isSystemAdmin ? ['/api/employees/all'] : [`/api/employees/${companyId}`],
    queryFn: async () => {
      const endpoint = isSystemAdmin ? '/api/employees/all' : `/api/employees/${companyId}`;
      const response = await apiRequestWithAuth('GET', endpoint);
      return response.json();
    },
    enabled: isSystemAdmin || !!companyId,
  });

  // Delete employee mutation
  const deleteEmployeeMutation = useMutation({
    mutationFn: async (employeeId: number) => {
      await apiRequestWithAuth('DELETE', `/api/employees/${employeeId}`);
    },
    onSuccess: () => {
      // Invalidate the correct query based on user role
      const queryKey = isSystemAdmin ? ['/api/employees/all'] : [`/api/employees/${companyId}`];
      queryClient.invalidateQueries({ queryKey });
      toast({
        title: "Success",
        description: "Employee deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleAddEmployee = () => {
    setShowAadharModal(true);
  };

  const handleViewEmployee = (employee: Employee) => {
    setLocation(`/admin/employees/${employee.id}/view`);
  };

  const handleEditEmployee = (employee: Employee) => {
    setLocation(`/admin/employees/${employee.id}/edit`);
  };

  const handleDeleteEmployee = (employee: Employee) => {
    if (confirm(`Are you sure you want to delete ${employee.fullName}?`)) {
      deleteEmployeeMutation.mutate(employee.id);
    }
  };

  const handleExportToExcel = () => {
    const token = localStorage.getItem('token');
    const url = `/api/employees/export/${companyId}`;
    
    // Create a temporary link with auth header
    fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `employees_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    })
    .catch(error => {
      toast({
        title: "Error",
        description: "Failed to export employee data",
        variant: "destructive",
      });
    });
  };

  // Filter employees based on search query
  const filteredEmployees = employees.filter(employee =>
    employee.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    employee.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    employee.position?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-hr-secondary/10 text-hr-secondary';
      case 'probation':
        return 'bg-yellow-100 text-yellow-700';
      case 'inactive':
        return 'bg-gray-100 text-gray-700';
      case 'terminated':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const formatDate = (date: string | Date | null) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString();
  };

  const getInitials = (fullName: string) => {
    const names = fullName.trim().split(' ');
    if (names.length >= 2) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return fullName.slice(0, 2).toUpperCase();
  };

  // Permission guard - show access denied if user doesn't have permission
  if (permissionLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
            <p className="mt-2 text-gray-600">Checking permissions...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!canViewEmployeeList && user?.role === 'employee') {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <ShieldAlert className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-4">You don't have permission to access the employee list.</p>
            <p className="text-sm text-gray-500">Please request the "employee_list" permission from your administrator.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Employees</h1>
          <p className="text-muted-foreground">{filteredEmployees.length} employees total</p>
        </div>
        {user?.role !== 'employee' && (
          <div className="flex gap-2">
            <Button 
              onClick={handleExportToExcel} 
              variant="outline"
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Export to Excel
            </Button>
            <Button onClick={handleAddEmployee} className="bg-hr-primary hover:bg-hr-primary/90">
              <Plus className="mr-2 h-4 w-4" />
              Add Employee
            </Button>
          </div>
        )}
      </div>
      
      <div className="flex items-center space-x-4">
        <div className="flex-1">
          <input
            type="text"
            placeholder="Search employees..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-hr-primary focus:border-transparent"
          />
        </div>
      </div>
      
      <Card className="shadow-sm border border-gray-100">
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-8 text-center">
                  <p className="text-hr-neutral">Loading employees...</p>
                </div>
              ) : filteredEmployees.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-hr-neutral">
                    {searchQuery ? 'No employees match your search.' : 'No employees found.'}
                  </p>
                  {!searchQuery && user?.role !== 'employee' && (
                    <Button 
                      onClick={handleAddEmployee}
                      className="mt-4 bg-hr-primary hover:bg-hr-primary/90"
                    >
                      Add First Employee
                    </Button>
                  )}
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Hire Date</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead className="text-center">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEmployees.map((employee) => (
                      <TableRow key={employee.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-hr-primary text-white rounded-full flex items-center justify-center text-sm font-medium">
                              {getInitials(employee.fullName)}
                            </div>
                            <div>
                              <p className="font-medium text-hr-text-primary">
                                {employee.fullName}
                              </p>
                              <p className="text-sm text-hr-neutral">{employee.employeeId}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <p className="text-hr-text-primary">{employee.position || 'N/A'}</p>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getStatusColor(employee.status)} capitalize`}>
                            {employee.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <p className="text-hr-text-primary">{formatDate(employee.hireDate)}</p>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Mail size={16} className="text-hr-neutral" />
                            <span className="text-sm text-hr-text-primary">{employee.email}</span>
                          </div>
                          {employee.phone && (
                            <div className="flex items-center space-x-2 mt-1">
                              <Phone size={16} className="text-hr-neutral" />
                              <span className="text-sm text-hr-text-primary">{employee.phone}</span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical size={16} />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleViewEmployee(employee)}>
                                <Eye size={16} className="mr-2" />
                                View Details
                              </DropdownMenuItem>
                              {user?.role !== 'employee' && (
                                <>
                                  <DropdownMenuItem onClick={() => handleEditEmployee(employee)}>
                                    <Edit size={16} className="mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    onClick={() => handleDeleteEmployee(employee)}
                                    className="text-hr-accent"
                                  >
                                    <Trash2 size={16} className="mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
        </CardContent>
      </Card>

      {/* Aadhar Verification Modal */}
      <AadharVerificationModal
        isOpen={showAadharModal}
        onClose={() => setShowAadharModal(false)}
      />

    </div>
  );
}
