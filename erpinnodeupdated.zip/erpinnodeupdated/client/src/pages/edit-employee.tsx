import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Download } from "lucide-react";
import { ArrowLeft, User, Briefcase, MapPin, CreditCard, Clock, Users, Shield, UserCheck, FileText } from "lucide-react";
import { type Employee, type Department } from "@shared/schema";
import SalaryStructureForm from "@/components/SalaryStructureForm";

interface EditEmployeePageProps {
  params: { id: string };
}

export default function EditEmployeePage({ params }: EditEmployeePageProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const employeeId = parseInt(params.id);
  
  const user = authService.getUser();
  const companyId = user?.companyId;
  
  // Month/Year selector state for salary structure
  const currentDate = new Date();
  const [selectedYear, setSelectedYear] = useState(currentDate.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(currentDate.getMonth() + 1);
  
  // PDF download state
  const [downloadingPDF, setDownloadingPDF] = useState(false);
  
  // All month names for reference
  const allMonthOptions = [
    { value: 1, label: 'January' },
    { value: 2, label: 'February' },
    { value: 3, label: 'March' },
    { value: 4, label: 'April' },
    { value: 5, label: 'May' },
    { value: 6, label: 'June' },
    { value: 7, label: 'July' },
    { value: 8, label: 'August' },
    { value: 9, label: 'September' },
    { value: 10, label: 'October' },
    { value: 11, label: 'November' },
    { value: 12, label: 'December' }
  ];
  
  // Fetch employee data with payroll
  const { data: employee, isLoading: employeeLoading } = useQuery<any>({
    queryKey: [`/api/employees/${companyId}/${employeeId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/employees/${companyId}/${employeeId}?_t=${Date.now()}`);
      return response.json();
    },
    enabled: !!companyId && !!employeeId,
    staleTime: 0, // Always consider data stale
    gcTime: 0, // Don't cache the data
  });

  // Time Office Policy data is now included in the employee data from backend

  // Generate year and month options based on employee's joining date
  const getPayrollPeriodOptions = () => {
    if (!employee?.hireDate) {
      // Fallback if no hire date available
      return {
        yearOptions: [currentDate.getFullYear()],
        monthOptions: allMonthOptions
      };
    }
    
    const hireDate = new Date(employee.hireDate);
    const hireYear = hireDate.getFullYear();
    const hireMonth = hireDate.getMonth() + 1;
    const currentYear = currentDate.getFullYear();
    const currentMonth = currentDate.getMonth() + 1;
    
    // Generate year options from hire year to current year
    const yearOptions = [];
    for (let year = hireYear; year <= currentYear; year++) {
      yearOptions.push(year);
    }
    
    // Generate month options based on selected year
    let monthOptions = [...allMonthOptions];
    
    if (selectedYear === hireYear && selectedYear === currentYear) {
      // Same year as hire and current: show from hire month to current month
      monthOptions = allMonthOptions.filter(m => m.value >= hireMonth && m.value <= currentMonth);
    } else if (selectedYear === hireYear) {
      // Hire year but not current: show from hire month to December
      monthOptions = allMonthOptions.filter(m => m.value >= hireMonth);
    } else if (selectedYear === currentYear) {
      // Current year but not hire: show from January to current month
      monthOptions = allMonthOptions.filter(m => m.value <= currentMonth);
    }
    // For other years (between hire and current), show all months
    
    return { yearOptions, monthOptions };
  };
  
  const { yearOptions, monthOptions } = getPayrollPeriodOptions();
  
  // Ensure selectedMonth is valid when year changes or employee data loads
  useEffect(() => {
    if (monthOptions.length > 0) {
      const validMonthValues = monthOptions.map(m => m.value);
      if (!validMonthValues.includes(selectedMonth)) {
        // Set to the closest valid month (first available or current month if available)
        const currentMonth = currentDate.getMonth() + 1;
        const preferredMonth = validMonthValues.includes(currentMonth) ? currentMonth : validMonthValues[0];
        setSelectedMonth(preferredMonth);
      }
    }
  }, [employee, selectedYear, monthOptions.length]);

  // Fetch salary structure for selected month/year
  const { data: salaryStructure, isLoading: salaryStructureLoading } = useQuery({
    queryKey: ['/api/employee-salary-structure', employeeId, selectedYear, selectedMonth],
    queryFn: async () => {
      try {
        const response = await apiRequestWithAuth('GET', `/api/employee-salary-structure/${employeeId}/${selectedYear}/${selectedMonth}`);
        if (response.ok) {
          return response.json();
        }
        return null; // No data for this month
      } catch (error) {
        return null; // No data for this month
      }
    },
    enabled: !!employeeId && !!selectedYear && !!selectedMonth,
    staleTime: 0,
    gcTime: 0,
  });

  // Fetch departments
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: [`/api/departments/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/departments/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch designations
  const { data: designations = [] } = useQuery<any[]>({
    queryKey: [`/api/designations/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/designations/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch branches
  const { data: branches = [] } = useQuery<any[]>({
    queryKey: [`/api/branches/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/branches/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch locations
  const { data: locations = [] } = useQuery<any[]>({
    queryKey: [`/api/locations/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/locations/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch cost centers
  const { data: costCenters = [] } = useQuery<any[]>({
    queryKey: [`/api/cost-centers/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/cost-centers/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch all employees for manager dropdown
  const { data: allEmployees = [] } = useQuery<any[]>({
    queryKey: [`/api/employees/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/employees/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch shifts
  const { data: shifts = [] } = useQuery<any[]>({
    queryKey: [`/api/shifts/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/shifts/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch biometric machines
  const { data: biometricMachines = [] } = useQuery<any[]>({
    queryKey: [`/api/biometric-machines/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/biometric-machines/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch leave policies
  const { data: leavePolicies = [] } = useQuery<any[]>({
    queryKey: [`/api/leave-policies/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/leave-policies/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch attendance locations
  const { data: attendanceLocations = [] } = useQuery<any[]>({
    queryKey: [`/api/attendance-locations/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/attendance-locations/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  const [selectedStateId, setSelectedStateId] = useState<string>('');
  const [selectedPermanentStateId, setSelectedPermanentStateId] = useState<string>('');
  const [activeTab, setActiveTab] = useState('personal');

  // Fetch states
  const { data: states = [] } = useQuery<any[]>({
    queryKey: ['/api/states'],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', '/api/states');
      return response.json();
    },
  });

  // Fetch districts based on selected present address state
  const { data: districts = [] } = useQuery<any[]>({
    queryKey: [`/api/districts/${selectedStateId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/districts/${selectedStateId}`);
      return response.json();
    },
    enabled: !!selectedStateId,
  });

  // Fetch districts based on selected permanent address state
  const { data: permanentDistricts = [] } = useQuery<any[]>({
    queryKey: [`/api/districts/${selectedPermanentStateId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/districts/${selectedPermanentStateId}`);
      return response.json();
    },
    enabled: !!selectedPermanentStateId,
  });

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    employeeId: '',
    designation: '',
    departmentId: '',
    branchId: '',
    locationId: '',
    costCenterId: '',
    managerId: '',
    presentAddress: '',
    presentState: '',
    presentDistrict: '',
    presentPinCode: '',
    permanentAddress: '',
    permanentState: '',
    permanentDistrict: '',
    permanentPinCode: '',
    dateOfBirth: '',
    hireDate: '',
    salary: '',
    status: 'active' as 'active' | 'inactive' | 'probation' | 'terminated',
    emergencyContact: '',
    emergencyPhone: '',
    // Identity / KYC fields
    aadhaarNo: '',
    panNo: '',
    bankAccountNo: '',
    ifscCode: '',
    uanNo: '',
    esicNo: '',
    // Time Office Policy fields
    dutyTimingFrom: '',
    dutyTimingTo: '',
    lateArrivalAllowed: '',
    earlyDepartureAllowed: '',
    permissibleFlexibility: '',
    weeklyOff1: '',
    weeklyOff2: '',
    overtimeApplicable: false,
    shiftId: '',
    biometricMachineId: '',
    leavePolicyId: '',
    attendanceLocationId: '',
    // Payroll fields
    epfEnabled: false,
    employeePfLimit: false,
    employerPfLimit: false,
    esicEnabled: false,
    lwfEnabled: false,
    otEnabled: false,
    doubleOt: false,
    vpfEnabled: false,
    vpfAmount: '',
    tdsEnabled: false,
    tdsAmount: '',
    ptEnabled: false,
    ptAmount: '',
    bonusEnabled: false,
    bonusMonthlyPayment: false,
    entryType: 'gross' as 'ctc' | 'gross' | 'earning_heads',
    ctcValue: '',
    grossValue: '',
    earningHead1: '', // Basic Salary
    earningHead2: '', // HRA
    earningHead3: '', // Conveyance Allowance
    earningHead4: '', // Other Allowances
    epfEmployeeAmount: '',
    esicEmployeeAmount: '',
    lwfEmployeeAmount: ''
  });

  // Payroll calculation functions with corrected earning heads logic
  const calculateEarningHeads = (grossAmount: number) => {
    let basicSalary = 0;
    let hra = 0;
    let conveyanceAllowance = 0;
    let otherAllowances = 0;

    if (grossAmount < 15000) {
      // For salaries < ₹15,000: Basic = full gross salary
      basicSalary = grossAmount;
      hra = 0;
      conveyanceAllowance = 0;
      otherAllowances = 0;
    } else if (grossAmount < 22500) {
      // For salaries ₹15,000 to ₹22,500: Basic = ₹15,000, HRA = remainder
      basicSalary = 15000;
      hra = grossAmount - 15000;
      conveyanceAllowance = 0;
      otherAllowances = 0;
    } else if (grossAmount < 25000) {
      // For salaries ₹22,500 to ₹25,000: Basic = ₹15,000, HRA = ₹7,500, Conv = Gross-Basic-HRA
      basicSalary = 15000;              // Fixed ₹15,000
      hra = 7500;                       // Fixed ₹7,500
      conveyanceAllowance = grossAmount - basicSalary - hra;  // Remainder
      otherAllowances = 0;
    } else if (grossAmount <= 100000) {
      // For salaries ₹25,000 to ₹1,00,000: Basic = 60%, HRA = 30%, Conveyance = 10%, Other = 0%
      basicSalary = grossAmount * 0.6;  // 60%
      hra = grossAmount * 0.3;          // 30%
      conveyanceAllowance = grossAmount * 0.1;  // 10%
      otherAllowances = 0;              // Must be 0
    } else {
      // For salaries > ₹1,00,000: Basic = 60%, HRA = 30%, Conveyance = 6%, Other = 4%
      basicSalary = grossAmount * 0.6;  // 60%
      hra = grossAmount * 0.3;          // 30%
      conveyanceAllowance = grossAmount * 0.06; // 6%
      otherAllowances = grossAmount * 0.04;     // 4%
    }
    
    return {
      basicSalary: Math.round(basicSalary),
      hra: Math.round(hra),
      conveyanceAllowance: Math.round(conveyanceAllowance),
      otherAllowances: Math.round(otherAllowances)
    };
  };

  // Populate form when employee data loads or month/year changes
  useEffect(() => {
    // Early return: wait until both employee and states are loaded
    if (!employee || states.length === 0) {
      return;
    }
    
    if (employee) {
      console.log('Loading employee data:', employee);
      console.log('Employee payroll data:', employee.payroll);
      console.log('Salary structure data:', salaryStructure);
      
      // Prefer salary structure data for the selected month, fallback to current payroll data
      const payrollData = salaryStructure || employee.payroll;
      
      setFormData({
        fullName: employee.fullName || '',
        email: employee.email || '',
        phone: employee.phone || '',
        employeeId: employee.employeeId || '',
        designation: employee.designation || employee.position || '',
        departmentId: employee.departmentId?.toString() || '',
        branchId: employee.branchId?.toString() || '',
        locationId: employee.locationId?.toString() || '',
        costCenterId: employee.costCenterId?.toString() || '',
        managerId: employee.managerId?.toString() || '',
        presentAddress: employee.presentAddress || '',
        presentState: employee.presentState || '',
        presentDistrict: employee.presentDistrict || '',
        presentPinCode: employee.presentPinCode || '',
        permanentAddress: employee.permanentAddress || '',
        permanentState: employee.permanentState || '',
        permanentDistrict: employee.permanentDistrict || '',
        permanentPinCode: employee.permanentPinCode || '',
        dateOfBirth: employee.dateOfBirth ? new Date(employee.dateOfBirth).toISOString().split('T')[0] : '',
        hireDate: employee.hireDate ? new Date(employee.hireDate).toISOString().split('T')[0] : '',
        salary: employee.salary || '',
        status: employee.status || 'active',
        emergencyContact: employee.emergencyContact || '',
        emergencyPhone: employee.emergencyPhone || '',
        // Identity / KYC fields
        aadhaarNo: employee.aadhaarNo || '',
        panNo: employee.panNo || '',
        bankAccountNo: employee.bankAccountNo || '',
        ifscCode: employee.ifscCode || '',
        uanNo: employee.uanNo || '',
        esicNo: employee.esicNo || '',
        // Time Office Policy fields - now included in employee data from backend
        dutyTimingFrom: employee.dutyStartTime || '09:00',
        dutyTimingTo: employee.dutyEndTime || '18:00',
        lateArrivalAllowed: employee.permissibleLateArrival || '15',
        earlyDepartureAllowed: employee.permissibleEarlyDeparture || '15',
        permissibleFlexibility: employee.presentMarkingDuration || '4',
        weeklyOff1: employee.firstWeeklyOffDay || 'saturday',
        weeklyOff2: employee.secondWeeklyOffDay || 'sunday',
        overtimeApplicable: employee.overtimeApplicable || false,
        shiftId: employee.shiftId?.toString() || '',
        biometricMachineId: employee.biometricMachineId?.toString() || '',
        leavePolicyId: employee.leavePolicyId?.toString() || '',
        attendanceLocationId: employee.attendanceLocationId?.toString() || '',
        // Payroll fields - load from salary structure (priority) or current payroll data (fallback)
        epfEnabled: payrollData?.epfEnabled ?? false,
        employeePfLimit: payrollData?.employeePfLimit ?? false,
        employerPfLimit: payrollData?.employerPfLimit ?? false,
        esicEnabled: payrollData?.esicEnabled ?? false,
        lwfEnabled: payrollData?.lwfEnabled ?? false,
        otEnabled: payrollData?.otEnabled ?? false,
        doubleOt: payrollData?.doubleOt ?? false,
        vpfEnabled: payrollData?.vpfEnabled ?? false,
        vpfAmount: payrollData?.vpfAmount?.toString() || '',
        tdsEnabled: payrollData?.tdsEnabled ?? false,
        tdsAmount: payrollData?.tdsAmount?.toString() || '',
        ptEnabled: payrollData?.ptEnabled ?? false,
        ptAmount: payrollData?.ptAmount?.toString() || '',
        bonusEnabled: payrollData?.bonusEnabled ?? false,
        bonusMonthlyPayment: payrollData?.bonusMonthlyPayment ?? false,
        entryType: (payrollData?.entryType as 'ctc' | 'gross' | 'earning_heads') || 'gross',
        ctcValue: payrollData?.ctcValue?.toString() || '',
        grossValue: payrollData?.grossValue?.toString() || employee.salary || '',
        earningHead1: payrollData?.earningHead1?.toString() || '',
        earningHead2: payrollData?.earningHead2?.toString() || '',
        earningHead3: payrollData?.earningHead3?.toString() || '',
        earningHead4: payrollData?.earningHead4?.toString() || '',
        epfEmployeeAmount: payrollData?.epfEmployeeAmount?.toString() || '',
        esicEmployeeAmount: payrollData?.esicEmployeeAmount?.toString() || '',
        lwfEmployeeAmount: payrollData?.lwfEmployeeAmount?.toString() || ''
      });
      
      console.log('Form data set with payroll values:', {
        epfEnabled: employee.payroll?.epfEnabled,
        esicEnabled: employee.payroll?.esicEnabled,
        lwfEnabled: employee.payroll?.lwfEnabled,
        bonusEnabled: employee.payroll?.bonusEnabled
      });
      
      // Recalculate CTC when form loads with existing data
      if (payrollData?.entryType === 'gross' || employee.salary) {
        const grossAmount = parseFloat(payrollData?.grossValue || employee.salary || '0');
        if (grossAmount > 0) {
          const calculatedCTC = calculateCTC(grossAmount);
          console.log('Recalculated CTC on form load:', {
            gross: grossAmount,
            calculatedCTC: calculatedCTC,
            epfEnabled: payrollData?.epfEnabled,
            employerPfLimit: payrollData?.employerPfLimit,
            esicEnabled: payrollData?.esicEnabled,
            originalCTC: payrollData?.ctcValue
          });
          
          // Update form data with correct CTC
          setTimeout(() => {
            setFormData(prev => ({
              ...prev,
              ctcValue: calculatedCTC.toFixed(2)
            }));
          }, 200);
        }
      }
      
      // Only auto-calculate earning heads if none are saved in the database
      const earningHeads = [
        payrollData?.earningHead1,
        payrollData?.earningHead2,
        payrollData?.earningHead3,
        payrollData?.earningHead4
      ];
      const hasSavedEarningHeads = earningHeads.some(v => v !== undefined && v !== null && v !== '');
      
      if (!hasSavedEarningHeads) {
        setTimeout(() => {
          const grossAmount = parseFloat(payrollData?.grossValue || employee.salary || '0');
          if (grossAmount > 0) {
            const earningHeads = calculateEarningHeads(grossAmount);
            setFormData(prev => ({
              ...prev,
              earningHead1: earningHeads.basicSalary.toString(),
              earningHead2: earningHeads.hra.toString(),
              earningHead3: earningHeads.conveyanceAllowance.toString(),
              earningHead4: earningHeads.otherAllowances.toString()
            }));
          }
        }, 100);
      }
      
      // Set selected state IDs for address dropdowns to enable district loading
      // Handle both legacy state names and new state IDs
      if (employee.presentState && states.length > 0) {
        // Check if it's already an ID (numeric) or a state name
        const isNumericId = !isNaN(Number(employee.presentState));
        if (isNumericId) {
          setSelectedStateId(employee.presentState.toString());
        } else {
          // Legacy data: state name stored, need to find the ID
          const matchingState = states.find((s: any) => s.name === employee.presentState);
          if (matchingState) {
            setSelectedStateId(matchingState.id.toString());
          }
        }
      }
      if (employee.permanentState && states.length > 0) {
        // Check if it's already an ID (numeric) or a state name
        const isNumericId = !isNaN(Number(employee.permanentState));
        if (isNumericId) {
          setSelectedPermanentStateId(employee.permanentState.toString());
        } else {
          // Legacy data: state name stored, need to find the ID
          const matchingState = states.find((s: any) => s.name === employee.permanentState);
          if (matchingState) {
            setSelectedPermanentStateId(matchingState.id.toString());
          }
        }
      }
    }
  }, [employee, salaryStructure, selectedYear, selectedMonth, states]);

  // Auto-recalculate CTC when relevant fields change
  useEffect(() => {
    if (formData.entryType === 'gross' && formData.grossValue) {
      const grossAmount = parseFloat(formData.grossValue);
      if (grossAmount > 0) {
        const calculatedCTC = calculateCTC(grossAmount);
        const newCtcValue = calculatedCTC.toFixed(2);
        
        if (newCtcValue !== formData.ctcValue) {
          console.log('Auto-recalculating CTC:', {
            gross: grossAmount,
            oldCTC: formData.ctcValue,
            newCTC: newCtcValue,
            epfEnabled: formData.epfEnabled,
            employerPfLimit: formData.employerPfLimit,
            esicEnabled: formData.esicEnabled,
            lwfEnabled: formData.lwfEnabled
          });
          
          setFormData(prev => ({
            ...prev,
            ctcValue: newCtcValue
          }));
        }
      }
    }
  }, [
    formData.grossValue,
    formData.entryType,
    formData.epfEnabled,
    formData.employerPfLimit,
    formData.esicEnabled,
    formData.lwfEnabled,
    formData.bonusEnabled,
    formData.bonusMonthlyPayment,
    formData.earningHead1 // Basic salary affects PF calculation
  ]);

  const updateEmployeeMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const updateData = {
        ...data,
        // Map designation to position for backend compatibility
        position: data.designation,
        departmentId: data.departmentId ? parseInt(data.departmentId) : null,
        branchId: data.branchId ? parseInt(data.branchId) : null,
        locationId: data.locationId ? parseInt(data.locationId) : null,
        costCenterId: data.costCenterId ? parseInt(data.costCenterId) : null,
        managerId: data.managerId ? parseInt(data.managerId) : null,
        dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth).toISOString() : null,
        hireDate: data.hireDate ? new Date(data.hireDate).toISOString() : null,
        // Contact Information fields (addresses)
        presentAddress: data.presentAddress,
        presentState: data.presentState,
        presentDistrict: data.presentDistrict,
        presentPinCode: data.presentPinCode,
        permanentAddress: data.permanentAddress,
        permanentState: data.permanentState,
        permanentDistrict: data.permanentDistrict,
        permanentPinCode: data.permanentPinCode,
        // Emergency contact
        emergencyContact: data.emergencyContact,
        emergencyPhone: data.emergencyPhone,
        // Identity / KYC fields
        aadhaarNo: data.aadhaarNo,
        panNo: data.panNo,
        bankAccountNo: data.bankAccountNo,
        ifscCode: data.ifscCode,
        uanNo: data.uanNo,
        esicNo: data.esicNo,
        // Map Time Office Policy fields to backend field names
        dutyStartTime: data.dutyTimingFrom,
        dutyEndTime: data.dutyTimingTo,
        permissibleLateArrival: data.lateArrivalAllowed ? parseInt(data.lateArrivalAllowed) : null,
        permissibleEarlyDeparture: data.earlyDepartureAllowed ? parseInt(data.earlyDepartureAllowed) : null,
        presentMarkingDuration: data.permissibleFlexibility ? parseFloat(data.permissibleFlexibility) : null,
        firstWeeklyOffDay: data.weeklyOff1 || null,
        secondWeeklyOffDay: data.weeklyOff2 === 'none' ? null : data.weeklyOff2,
        overtimeApplicable: data.overtimeApplicable,
        shiftId: data.shiftId ? parseInt(data.shiftId) : null,
        biometricMachineId: data.biometricMachineId ? parseInt(data.biometricMachineId) : null,
        leavePolicyId: data.leavePolicyId ? parseInt(data.leavePolicyId) : null,
        attendanceLocationId: data.attendanceLocationId ? parseInt(data.attendanceLocationId) : null
      };
      
      const response = await apiRequestWithAuth('PUT', `/api/employees/${employeeId}`, updateData);
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Immediately update form state with the submitted values
      setFormData(prev => ({
        ...prev,
        earningHead1: variables.earningHead1,
        earningHead2: variables.earningHead2,
        earningHead3: variables.earningHead3,
        earningHead4: variables.earningHead4,
        grossValue: variables.grossValue,
        ctcValue: variables.ctcValue
      }));
      
      // Use targeted cache invalidation instead of clearing everything
      queryClient.invalidateQueries({ queryKey: [`/api/employees/${companyId}/${employeeId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/employees/${companyId}`] });
      
      toast({
        title: "Success",
        description: "Employee updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update employee",
        variant: "destructive",
      });
    },
  });
  
  // Comprehensive cascading salary structure save mutation 
  const saveSalaryStructureMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const structureData = {
        // Payroll toggles
        epfEnabled: data.epfEnabled,
        employeePfLimit: data.employeePfLimit,
        employerPfLimit: data.employerPfLimit,
        esicEnabled: data.esicEnabled,
        lwfEnabled: data.lwfEnabled,
        otEnabled: data.otEnabled,
        doubleOt: data.doubleOt,
        vpfEnabled: data.vpfEnabled,
        vpfAmount: data.vpfAmount,
        tdsEnabled: data.tdsEnabled,
        tdsAmount: data.tdsAmount,
        ptEnabled: data.ptEnabled,
        ptAmount: data.ptAmount,
        bonusEnabled: data.bonusEnabled,
        bonusMonthlyPayment: data.bonusMonthlyPayment,
        // Salary structure
        entryType: data.entryType,
        ctcValue: data.ctcValue,
        grossValue: data.grossValue,
        earningHead1: data.earningHead1,
        earningHead2: data.earningHead2,
        earningHead3: data.earningHead3,
        earningHead4: data.earningHead4,
        epfEmployeeAmount: data.epfEmployeeAmount,
        esicEmployeeAmount: data.esicEmployeeAmount,
        lwfEmployeeAmount: data.lwfEmployeeAmount
      };
      
      // First save the current month
      const response = await apiRequestWithAuth('PUT', `/api/employee-salary-structure/${employeeId}/${selectedYear}/${selectedMonth}`, structureData);
      const result = await response.json();
      
      // Then cascade to all future months
      try {
        const cascadeResponse = await apiRequestWithAuth('POST', `/api/employee-salary-structure/${employeeId}/${selectedYear}/${selectedMonth}/cascade`, structureData);
        const cascadeResult = await cascadeResponse.json();
        
        return {
          ...result,
          cascadeInfo: cascadeResult
        };
      } catch (cascadeError: any) {
        console.warn('Cascade update failed:', cascadeError);
        // Return the main result even if cascade fails
        return {
          ...result,
          cascadeInfo: null,
          cascadeError: cascadeError?.message || 'Unknown error'
        };
      }
    },
    onSuccess: (data) => {
      // Invalidate all salary structure caches since we updated multiple months
      queryClient.invalidateQueries({ queryKey: ['/api/employee-salary-structure'] });
      
      const monthName = allMonthOptions.find(m => m.value === selectedMonth)?.label;
      let description = `Salary structure saved for ${monthName} ${selectedYear}`;
      
      if (data.cascadeInfo?.updatedMonths?.length > 0) {
        description += ` and cascaded to ${data.cascadeInfo.updatedMonths.length} future months`;
      } else if (data.cascadeError) {
        description += ` (cascade to future months failed)`;
      }
      
      toast({
        title: "Success",
        description,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save salary structure",
        variant: "destructive",
      });
    },
  });
  
  // Handle PDF download
  const handleDownloadSalaryHistory = async () => {
    if (!employeeId) return;
    
    setDownloadingPDF(true);
    
    try {
      // Get the JWT token for authentication
      const token = localStorage.getItem('token');
      if (!token) {
        throw new Error('Not authenticated');
      }
      
      // Use direct fetch for binary PDF data (don't use apiRequestWithAuth which expects JSON)
      const response = await fetch(`/api/employee-salary-structure/${employeeId}/pdf?limit=12`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to generate PDF');
      }
      
      // Get the PDF blob
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      // Set filename from Content-Disposition header or use default
      const contentDisposition = response.headers.get('Content-Disposition');
      let filename = 'salary_history.pdf';
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="(.+)"/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }
      
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      
      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Success",
        description: "Salary history PDF downloaded successfully",
      });
      
    } catch (error: any) {
      console.error('Error downloading PDF:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to download salary history PDF",
        variant: "destructive",
      });
    } finally {
      setDownloadingPDF(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Only save employee data (not salary structure) from non-payroll tabs
    updateEmployeeMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof typeof formData, value: string | boolean) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Auto-calculate employee amounts when components are enabled
      if (field === 'epfEnabled') {
        if (value === true) {
          // Calculate PF base: All earning heads except HRA
          const pfBase = (parseFloat(newData.earningHead1 || '0') + 
                          parseFloat(newData.earningHead3 || '0') + 
                          parseFloat(newData.earningHead4 || '0'));
          let epfAmount = pfBase * 0.12; // 12% of PF Base (excluding HRA)
          
          // Apply Employee PF Limit: Maximum deduction of 1800 when enabled
          if (newData.employeePfLimit && epfAmount > 1800) {
            epfAmount = 1800;
          }
          
          newData.epfEmployeeAmount = epfAmount.toFixed(2);
        } else {
          // Clear EPF amount when EPF is disabled
          newData.epfEmployeeAmount = '0.00';
        }
      } else if (field === 'esicEnabled') {
        if (value === true) {
          const grossAmount = parseFloat(newData.grossValue || '0');
          
          // Apply ESIC Ceiling: Zero ESIC when gross > 21000
          let esicAmount = 0;
          if (grossAmount <= 21000) {
            esicAmount = grossAmount * 0.0075; // 0.75% of Gross
          }
          
          newData.esicEmployeeAmount = esicAmount.toFixed(2);
        } else {
          // Clear ESIC amount when ESIC is disabled
          newData.esicEmployeeAmount = '0.00';
        }
      } else if (field === 'lwfEnabled') {
        if (value === true) {
          newData.lwfEmployeeAmount = '10.00'; // Fixed amount for employee
        } else {
          // Clear LWF amount when LWF is disabled
          newData.lwfEmployeeAmount = '0.00';
        }
      } else if (field === 'employeePfLimit') {
        // Recalculate EPF amount when PF limit toggle changes
        if (newData.epfEnabled) {
          // Calculate PF base: All earning heads except HRA
          const pfBase = (parseFloat(newData.earningHead1 || '0') + 
                          parseFloat(newData.earningHead3 || '0') + 
                          parseFloat(newData.earningHead4 || '0'));
          let epfAmount = pfBase * 0.12; // 12% of PF Base (excluding HRA)
          
          // Apply Employee PF Limit: Maximum deduction of 1800 when enabled
          if (value === true && epfAmount > 1800) {
            epfAmount = 1800;
          }
          
          newData.epfEmployeeAmount = epfAmount.toFixed(2);
        }
      }
      
      // Recalculate employee amounts when earning heads change (any earning head affects PF except HRA)
      if ((field === 'earningHead1' || field === 'earningHead3' || field === 'earningHead4') && newData.epfEnabled) {
        // Calculate PF base: All earning heads except HRA (earningHead2)
        const pfBase = (parseFloat(newData.earningHead1 || '0') + 
                        parseFloat(newData.earningHead3 || '0') + 
                        parseFloat(newData.earningHead4 || '0'));
        let epfAmount = pfBase * 0.12; // 12% of PF Base (excluding HRA)
        
        // Apply Employee PF Limit: Maximum deduction of 1800 when enabled
        if (newData.employeePfLimit && epfAmount > 1800) {
          epfAmount = 1800;
        }
        
        newData.epfEmployeeAmount = epfAmount.toFixed(2);
      }
      
      if ((field === 'grossValue' || field.startsWith('earningHead')) && newData.esicEnabled) {
        const grossAmount = field === 'grossValue' ? parseFloat(value as string || '0') : parseFloat(newData.grossValue || '0');
        
        // Apply ESIC Ceiling: Zero ESIC when gross > 21000
        let esicAmount = 0;
        if (grossAmount <= 21000) {
          esicAmount = grossAmount * 0.0075; // 0.75% of Gross
        }
        
        newData.esicEmployeeAmount = esicAmount.toFixed(2);
      }
      
      return newData;
    });
  };

  const calculateGross = () => {
    const earning1 = parseFloat(formData.earningHead1) || 0;
    const earning2 = parseFloat(formData.earningHead2) || 0;
    const earning3 = parseFloat(formData.earningHead3) || 0;
    const earning4 = parseFloat(formData.earningHead4) || 0;
    return earning1 + earning2 + earning3 + earning4;
  };

  // Calculate PF base: All earning heads except HRA (earningHead2)
  const calculatePFBase = () => {
    const earning1 = parseFloat(formData.earningHead1) || 0; // Basic Salary
    const earning3 = parseFloat(formData.earningHead3) || 0; // Other allowances
    const earning4 = parseFloat(formData.earningHead4) || 0; // Other allowances
    // Note: earningHead2 (HRA) is excluded from PF calculation
    return earning1 + earning3 + earning4;
  };

  const calculateCTC = (grossAmount: number) => {
    // Get PF base for PF calculations - all earning heads except HRA
    const pfBase = calculatePFBase();
    
    // CTC = Gross + Employer Contributions
    let employerPF = formData.epfEnabled ? pfBase * 0.12 : 0; // 12% of PF Base (excluding HRA)
    let adminCharges = formData.epfEnabled ? pfBase * 0.01 : 0; // 1% of PF Base (excluding HRA)
    
    // Apply Employer PF Limit: Maximum contribution of 1800 + fixed admin charges of 150 when enabled
    if (formData.employerPfLimit && formData.epfEnabled) {
      if (employerPF > 1800) {
        employerPF = 1800;
      }
      adminCharges = 150; // Fixed amount when limit is enabled
    }
    
    // Apply ESIC Ceiling: Zero ESIC when gross > 21000
    let employerESIC = 0;
    if (formData.esicEnabled && grossAmount <= 21000) {
      employerESIC = grossAmount * 0.0325; // 3.25% of Gross
    }
    
    const employerLWF = formData.lwfEnabled ? 20 : 0; // Fixed amount
    const bonus = formData.bonusEnabled ? grossAmount * 0.0833 : 0; // 8.33% of Gross (always include when enabled)
    
    return grossAmount + employerPF + adminCharges + employerESIC + employerLWF + bonus;
  };

  const calculateGrossFromCTC = (ctcAmount: number) => {
    // Reverse calculation approximation
    const estimatedMultiplier = 1.25; // Approximate multiplier
    return ctcAmount / estimatedMultiplier;
  };

  // Handle entry type changes and auto-calculations
  const handleEntryTypeChange = (entryType: string) => {
    setFormData(prev => {
      const newData = { ...prev, entryType: entryType as 'ctc' | 'gross' | 'earning_heads' };
      
      if (entryType === 'ctc' && prev.ctcValue) {
        const grossCalculated = calculateGrossFromCTC(parseFloat(prev.ctcValue));
        newData.grossValue = grossCalculated.toFixed(2);
      } else if (entryType === 'gross' && prev.grossValue) {
        const ctcCalculated = calculateCTC(parseFloat(prev.grossValue));
        newData.ctcValue = ctcCalculated.toFixed(2);
      } else if (entryType === 'earning_heads') {
        // Auto-calculate earning heads when switching to this mode
        if (prev.grossValue) {
          const grossAmount = parseFloat(prev.grossValue);
          const earningHeads = calculateEarningHeads(grossAmount);
          newData.earningHead1 = earningHeads.basicSalary.toString();
          newData.earningHead2 = earningHeads.hra.toString();
          newData.earningHead3 = earningHeads.conveyanceAllowance.toString();
          newData.earningHead4 = earningHeads.otherAllowances.toString();
        }
        const grossCalculated = calculateGross();
        const ctcCalculated = calculateCTC(grossCalculated);
        newData.grossValue = grossCalculated.toFixed(2);
        newData.ctcValue = ctcCalculated.toFixed(2);
      }
      
      return newData;
    });
  };

  const handleSalaryValueChange = (field: string, value: string) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      if (field === 'ctcValue' && prev.entryType === 'ctc') {
        const grossCalculated = calculateGrossFromCTC(parseFloat(value) || 0);
        newData.grossValue = grossCalculated.toFixed(2);
      } else if (field === 'grossValue' && prev.entryType === 'gross') {
        const ctcCalculated = calculateCTC(parseFloat(value) || 0);
        newData.ctcValue = ctcCalculated.toFixed(2);
      } else if (field.startsWith('earningHead')) {
        // Allow direct earning head updates regardless of entry type
        // Only recalculate gross/CTC when entry type is earning_heads
        if (prev.entryType === 'earning_heads') {
          setTimeout(() => {
            const grossCalculated = calculateGross();
            const ctcCalculated = calculateCTC(grossCalculated);
            setFormData(current => ({
              ...current,
              grossValue: grossCalculated.toFixed(2),
              ctcValue: ctcCalculated.toFixed(2)
            }));
          }, 0);
        }
      }
      
      return newData;
    });
  };

  // Copy present address to permanent address
  const copyPresentToPermanent = () => {
    setFormData(prev => ({
      ...prev,
      permanentAddress: prev.presentAddress,
      permanentState: prev.presentState,
      permanentDistrict: prev.presentDistrict,
      permanentPinCode: prev.presentPinCode
    }));
    setSelectedPermanentStateId(selectedStateId);
  };

  if (employeeLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Employee Not Found</h2>
          <p className="text-gray-600 mb-4">The employee you're looking for doesn't exist.</p>
          <Button onClick={() => setLocation('/admin/employees')}>
            Back to Employees
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocation('/admin/employees')}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Employees
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Edit Employee</h1>
          <p className="text-muted-foreground">Update employee information</p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-9">
            <TabsTrigger value="personal" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              Personal
            </TabsTrigger>
            <TabsTrigger value="employment" className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              Employment
            </TabsTrigger>
            <TabsTrigger value="contact" className="flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Contact
            </TabsTrigger>
            <TabsTrigger value="payroll" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Payroll
            </TabsTrigger>
            <TabsTrigger value="time" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              Time Office
            </TabsTrigger>
            <TabsTrigger value="emergency" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Emergency
            </TabsTrigger>
            <TabsTrigger value="identity" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Identity
            </TabsTrigger>
            <TabsTrigger value="family" className="flex items-center gap-2">
              <UserCheck className="h-4 w-4" />
              Family
            </TabsTrigger>
            <TabsTrigger value="documents" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Documents
            </TabsTrigger>
          </TabsList>

          {/* Personal Information */}
          <TabsContent value="personal">
            <Card>
              <CardHeader className="bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950 dark:to-indigo-950">
                <CardTitle className="text-blue-700 dark:text-blue-300">Personal Information</CardTitle>
                <CardDescription>Basic employee details and identification</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name *</Label>
                    <Input
                      id="fullName"
                      value={formData.fullName}
                      onChange={(e) => handleInputChange('fullName', e.target.value)}
                      placeholder="Enter full name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="employeeId">Employee ID *</Label>
                    <Input
                      id="employeeId"
                      value={formData.employeeId}
                      onChange={(e) => handleInputChange('employeeId', e.target.value)}
                      placeholder="Enter employee ID"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="Enter email address"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="Enter phone number"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth</Label>
                    <Input
                      id="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Employment Information */}
          <TabsContent value="employment">
            <Card>
              <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950 dark:to-emerald-950">
                <CardTitle className="text-green-700 dark:text-green-300">Employment Information</CardTitle>
                <CardDescription>Job role and department details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="designation">Designation</Label>
                    <Select
                      value={formData.designation}
                      onValueChange={(value) => handleInputChange('designation', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select designation" />
                      </SelectTrigger>
                      <SelectContent>
                        {designations.map((designation) => (
                          <SelectItem key={designation.id} value={designation.id.toString()}>
                            {designation.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="departmentId">Department</Label>
                    <Select
                      value={formData.departmentId}
                      onValueChange={(value) => handleInputChange('departmentId', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        {departments.map((dept) => (
                          <SelectItem key={dept.id} value={dept.id.toString()}>
                            {dept.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="branchId">Branch</Label>
                    <Select
                      value={formData.branchId || undefined}
                      onValueChange={(value) => handleInputChange('branchId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select branch" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {branches.map((branch) => (
                          <SelectItem key={branch.id} value={branch.id.toString()}>
                            {branch.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="locationId">Location</Label>
                    <Select
                      value={formData.locationId || undefined}
                      onValueChange={(value) => handleInputChange('locationId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {locations.map((location) => (
                          <SelectItem key={location.id} value={location.id.toString()}>
                            {location.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="costCenterId">Cost Center</Label>
                    <Select
                      value={formData.costCenterId || undefined}
                      onValueChange={(value) => handleInputChange('costCenterId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select cost center" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {costCenters.map((cc) => (
                          <SelectItem key={cc.id} value={cc.id.toString()}>
                            {cc.name} ({cc.code})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="managerId">Reporting Manager</Label>
                    <Select
                      value={formData.managerId || undefined}
                      onValueChange={(value) => handleInputChange('managerId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select manager" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {allEmployees.filter(emp => emp.id.toString() !== employeeId).map((emp) => (
                          <SelectItem key={emp.id} value={emp.id.toString()}>
                            {emp.fullName} ({emp.employeeId})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hireDate">Date of Join</Label>
                    <Input
                      id="hireDate"
                      type="date"
                      value={formData.hireDate}
                      onChange={(e) => handleInputChange('hireDate', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select
                      value={formData.status}
                      onValueChange={(value) => handleInputChange('status', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                        <SelectItem value="probation">Probation</SelectItem>
                        <SelectItem value="terminated">Terminated</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Contact Information */}
          <TabsContent value="contact">
            <Card>
              <CardHeader className="bg-gradient-to-r from-purple-50 to-violet-50 dark:from-purple-950 dark:to-violet-950">
                <CardTitle className="text-purple-700 dark:text-purple-300">Contact Information</CardTitle>
                <CardDescription>Address and location details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Present Address Section */}
                  <div className="space-y-4 p-6 bg-blue-50 rounded-lg border-2 border-blue-200">
                    <h3 className="font-semibold text-lg text-blue-800 mb-4">Present Address</h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="presentAddress">Address *</Label>
                      <Textarea
                        id="presentAddress"
                        value={formData.presentAddress}
                        onChange={(e) => handleInputChange('presentAddress', e.target.value)}
                        placeholder="Enter complete current residential address"
                        className="bg-white"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="presentState">State *</Label>
                      <Select 
                        value={formData.presentState} 
                        onValueChange={(value) => {
                          handleInputChange('presentState', value);
                          setSelectedStateId(value);
                          handleInputChange('presentDistrict', '');
                        }}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent>
                          {states.map((state: any) => (
                            <SelectItem key={state.id} value={state.id.toString()}>
                              {state.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="presentDistrict">District *</Label>
                      <Select 
                        value={formData.presentDistrict} 
                        onValueChange={(value) => handleInputChange('presentDistrict', value)}
                        disabled={!selectedStateId}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder={selectedStateId ? "Select district" : "First select a state"} />
                        </SelectTrigger>
                        <SelectContent>
                          {districts.map((district: any) => (
                            <SelectItem key={district.id} value={district.id.toString()}>
                              {district.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="presentPinCode">Pin Code *</Label>
                      <Input
                        id="presentPinCode"
                        value={formData.presentPinCode}
                        onChange={(e) => handleInputChange('presentPinCode', e.target.value)}
                        placeholder="Enter 6-digit pin code"
                        maxLength={6}
                        className="bg-white"
                      />
                    </div>
                  </div>

                  {/* Permanent Address Section */}
                  <div className="space-y-4 p-6 bg-green-50 rounded-lg border-2 border-green-200">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold text-lg text-green-800">Permanent Address</h3>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={copyPresentToPermanent}
                        className="text-xs border-green-600 text-green-700 hover:bg-green-100"
                      >
                        Copy from Present
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="permanentAddress">Address *</Label>
                      <Textarea
                        id="permanentAddress"
                        value={formData.permanentAddress}
                        onChange={(e) => handleInputChange('permanentAddress', e.target.value)}
                        placeholder="Enter permanent address"
                        className="bg-white"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="permanentState">State *</Label>
                      <Select 
                        value={formData.permanentState} 
                        onValueChange={(value) => {
                          handleInputChange('permanentState', value);
                          setSelectedPermanentStateId(value);
                          handleInputChange('permanentDistrict', '');
                        }}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent>
                          {states.map((state: any) => (
                            <SelectItem key={state.id} value={state.id.toString()}>
                              {state.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="permanentDistrict">District *</Label>
                      <Select 
                        value={formData.permanentDistrict} 
                        onValueChange={(value) => handleInputChange('permanentDistrict', value)}
                        disabled={!selectedPermanentStateId}
                      >
                        <SelectTrigger className="bg-white">
                          <SelectValue placeholder={selectedPermanentStateId ? "Select district" : "First select a state"} />
                        </SelectTrigger>
                        <SelectContent>
                          {permanentDistricts.map((district: any) => (
                            <SelectItem key={district.id} value={district.id.toString()}>
                              {district.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="permanentPinCode">Pin Code *</Label>
                      <Input
                        id="permanentPinCode"
                        value={formData.permanentPinCode}
                        onChange={(e) => handleInputChange('permanentPinCode', e.target.value)}
                        placeholder="Enter 6-digit pin code"
                        maxLength={6}
                        className="bg-white"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payroll Information */}
          <TabsContent value="payroll">
            <div className="space-y-6">
              {/* Month/Year Selector for Historical Salary Structure */}
              <Card>
                <CardHeader className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950 dark:to-orange-950">
                  <CardTitle className="text-yellow-700 dark:text-yellow-300">Payroll Information</CardTitle>
                  <CardDescription>Complete payroll setup with automatic calculations</CardDescription>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-300">Salary Structure Period</h3>
                    {salaryStructureLoading && (
                      <div className="text-sm text-gray-500">Loading...</div>
                    )}
                    {salaryStructure && (
                      <div className="text-sm text-green-600 font-medium">✓ Data found for this period</div>
                    )}
                    {!salaryStructureLoading && !salaryStructure && (selectedYear !== currentDate.getFullYear() || selectedMonth !== (currentDate.getMonth() + 1)) && (
                      <div className="text-sm text-gray-500">No data for this period - will use current payroll as template</div>
                    )}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="salary-year">Year</Label>
                      <Select
                        value={selectedYear.toString()}
                        onValueChange={(value) => setSelectedYear(parseInt(value))}
                      >
                        <SelectTrigger id="salary-year" data-testid="select-year">
                          <SelectValue placeholder="Select year" />
                        </SelectTrigger>
                        <SelectContent>
                          {yearOptions.map(year => (
                            <SelectItem key={year} value={year.toString()}>
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="salary-month">Month</Label>
                      <Select
                        value={selectedMonth.toString()}
                        onValueChange={(value) => setSelectedMonth(parseInt(value))}
                      >
                        <SelectTrigger id="salary-month" data-testid="select-month">
                          <SelectValue placeholder="Select month" />
                        </SelectTrigger>
                        <SelectContent>
                          {monthOptions.map(month => (
                            <SelectItem key={month.value} value={month.value.toString()}>
                              {month.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  {/* PDF Download Button */}
                  <div className="mt-4 pt-4 border-t">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={handleDownloadSalaryHistory}
                      disabled={downloadingPDF}
                      className="flex items-center gap-2"
                    >
                      {downloadingPDF ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                          Generating PDF...
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4" />
                          Download Salary History PDF
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Modern Salary Structure Form */}
              <SalaryStructureForm
                companyId={companyId!}
                employeeId={employeeId}
                initialData={salaryStructure || employee?.payroll}
                onSave={(salaryData) => {
                  // Update form data with new salary structure
                  setFormData(prev => ({
                    ...prev,
                    ...salaryData
                  }));
                  
                  // Save salary structure for the selected month
                  const isCurrentMonth = selectedYear === currentDate.getFullYear() && selectedMonth === (currentDate.getMonth() + 1);
                  
                  if (isCurrentMonth) {
                    // Save to both global payroll and month-specific structure for current month
                    updateEmployeeMutation.mutate({ ...formData, ...salaryData });
                    saveSalaryStructureMutation.mutate(salaryData);
                    
                    // Auto-update future months with the same structure (disabled for now)
                    // autoUpdateFutureMonthsMutation.mutate(salaryData);
                  } else {
                    // Only save to month-specific structure for historical/future months
                    saveSalaryStructureMutation.mutate(salaryData);
                  }
                }}
              />
            </div>
          </TabsContent>

          {/* Time Office Policy */}
          <TabsContent value="time">
            <Card>
              <CardHeader className="bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-teal-950 dark:to-cyan-950">
                <CardTitle className="text-teal-700 dark:text-teal-300">Time Office Policy</CardTitle>
                <CardDescription>Working hours and attendance policies</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="dutyTimingFrom">Duty Timing From</Label>
                    <Input
                      id="dutyTimingFrom"
                      type="time"
                      value={formData.dutyTimingFrom}
                      onChange={(e) => handleInputChange('dutyTimingFrom', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dutyTimingTo">Duty Timing To</Label>
                    <Input
                      id="dutyTimingTo"
                      type="time"
                      value={formData.dutyTimingTo}
                      onChange={(e) => handleInputChange('dutyTimingTo', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lateArrivalAllowed">Late Arrival Allowed (minutes)</Label>
                    <Input
                      id="lateArrivalAllowed"
                      type="number"
                      value={formData.lateArrivalAllowed}
                      onChange={(e) => handleInputChange('lateArrivalAllowed', e.target.value)}
                      placeholder="Minutes"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="earlyDepartureAllowed">Early Departure Allowed (minutes)</Label>
                    <Input
                      id="earlyDepartureAllowed"
                      type="number"
                      value={formData.earlyDepartureAllowed}
                      onChange={(e) => handleInputChange('earlyDepartureAllowed', e.target.value)}
                      placeholder="Minutes"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="permissibleFlexibility">Present Marking Duration (hours)</Label>
                    <Input
                      id="permissibleFlexibility"
                      type="number"
                      step="0.5"
                      min="1"
                      max="12"
                      value={formData.permissibleFlexibility}
                      onChange={(e) => handleInputChange('permissibleFlexibility', e.target.value)}
                      placeholder="4"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weeklyOff1">First Weekly Off Day</Label>
                    <Select 
                      value={formData.weeklyOff1} 
                      onValueChange={(value) => handleInputChange('weeklyOff1', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select day" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sunday">Sunday</SelectItem>
                        <SelectItem value="monday">Monday</SelectItem>
                        <SelectItem value="tuesday">Tuesday</SelectItem>
                        <SelectItem value="wednesday">Wednesday</SelectItem>
                        <SelectItem value="thursday">Thursday</SelectItem>
                        <SelectItem value="friday">Friday</SelectItem>
                        <SelectItem value="saturday">Saturday</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="weeklyOff2">Second Weekly Off Day</Label>
                    <Select 
                      value={formData.weeklyOff2} 
                      onValueChange={(value) => handleInputChange('weeklyOff2', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select day (optional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        <SelectItem value="sunday">Sunday</SelectItem>
                        <SelectItem value="monday">Monday</SelectItem>
                        <SelectItem value="tuesday">Tuesday</SelectItem>
                        <SelectItem value="wednesday">Wednesday</SelectItem>
                        <SelectItem value="thursday">Thursday</SelectItem>
                        <SelectItem value="friday">Friday</SelectItem>
                        <SelectItem value="saturday">Saturday</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="overtimeApplicable"
                        checked={formData.overtimeApplicable}
                        onCheckedChange={(checked: boolean) => handleInputChange('overtimeApplicable', checked)}
                      />
                      <Label htmlFor="overtimeApplicable">Overtime Applicable</Label>
                    </div>
                    <p className="text-xs text-gray-500">Enable overtime calculation for extra working hours</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="shiftId">Shift Assignment</Label>
                    <Select
                      value={formData.shiftId || undefined}
                      onValueChange={(value) => handleInputChange('shiftId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select shift" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {shifts.map((shift) => (
                          <SelectItem key={shift.id} value={shift.id.toString()}>
                            {shift.name} ({shift.startTime} - {shift.endTime})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="biometricMachineId">Biometric Device</Label>
                    <Select
                      value={formData.biometricMachineId || undefined}
                      onValueChange={(value) => handleInputChange('biometricMachineId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select device" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {biometricMachines.map((machine) => (
                          <SelectItem key={machine.id} value={machine.id.toString()}>
                            {machine.serialNumber} - {machine.location || 'No location'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="leavePolicyId">Leave Policy</Label>
                    <Select
                      value={formData.leavePolicyId || undefined}
                      onValueChange={(value) => handleInputChange('leavePolicyId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select leave policy" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {leavePolicies.map((policy) => (
                          <SelectItem key={policy.id} value={policy.id.toString()}>
                            {policy.name} ({policy.type})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="attendanceLocationId">Attendance Location</Label>
                    <Select
                      value={formData.attendanceLocationId || undefined}
                      onValueChange={(value) => handleInputChange('attendanceLocationId', value === 'none' ? '' : value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">None</SelectItem>
                        {attendanceLocations.map((location) => (
                          <SelectItem key={location.id} value={location.id.toString()}>
                            {location.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Emergency Contact */}
          <TabsContent value="emergency">
            <Card>
              <CardHeader className="bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-950 dark:to-pink-950">
                <CardTitle className="text-red-700 dark:text-red-300">Emergency Contact</CardTitle>
                <CardDescription>Emergency contact information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="emergencyContact">Emergency Contact Name</Label>
                    <Input
                      id="emergencyContact"
                      value={formData.emergencyContact}
                      onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
                      placeholder="Full name of emergency contact"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="emergencyPhone">Emergency Contact Phone</Label>
                    <Input
                      id="emergencyPhone"
                      type="tel"
                      value={formData.emergencyPhone}
                      onChange={(e) => handleInputChange('emergencyPhone', e.target.value)}
                      placeholder="Phone number"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Identity / KYC Details */}
          <TabsContent value="identity">
            <Card>
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950">
                <CardTitle className="text-indigo-700 dark:text-indigo-300">Identity / KYC Details</CardTitle>
                <CardDescription>Government identification and banking information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="aadhaarNo">Aadhaar Number</Label>
                    <Input
                      id="aadhaarNo"
                      value={formData.aadhaarNo}
                      onChange={(e) => handleInputChange('aadhaarNo', e.target.value)}
                      placeholder="XXXX-XXXX-XXXX"
                      maxLength={12}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="panNo">PAN Number</Label>
                    <Input
                      id="panNo"
                      value={formData.panNo}
                      onChange={(e) => handleInputChange('panNo', e.target.value)}
                      placeholder="ABCDE1234F"
                      maxLength={10}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bankAccountNo">Bank Account Number</Label>
                    <Input
                      id="bankAccountNo"
                      value={formData.bankAccountNo || ''}
                      onChange={(e) => handleInputChange('bankAccountNo', e.target.value)}
                      placeholder="Enter account number"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ifscCode">IFSC Code</Label>
                    <Input
                      id="ifscCode"
                      value={formData.ifscCode || ''}
                      onChange={(e) => handleInputChange('ifscCode', e.target.value)}
                      placeholder="SBIN0001234"
                      maxLength={11}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="uanNo">UAN Number</Label>
                    <Input
                      id="uanNo"
                      value={formData.uanNo || ''}
                      onChange={(e) => handleInputChange('uanNo', e.target.value)}
                      placeholder="Universal Account Number"
                      maxLength={12}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="esicNo">ESIC Number</Label>
                    <Input
                      id="esicNo"
                      value={formData.esicNo || ''}
                      onChange={(e) => handleInputChange('esicNo', e.target.value)}
                      placeholder="Employee State Insurance Number"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Family Details */}
          <TabsContent value="family">
            <Card>
              <CardHeader className="bg-gradient-to-r from-pink-50 to-rose-50 dark:from-pink-950 dark:to-rose-950">
                <CardTitle className="text-pink-700 dark:text-pink-300">Family Details</CardTitle>
                <CardDescription>Information about family members</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="text-center py-8">
                  <UserCheck className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="font-medium text-gray-900 mb-2">Family Member Management</h3>
                  <p className="text-gray-500 mb-4">Family member details will be managed here in a future update</p>
                  <p className="text-sm text-gray-400">Contact administrator to add family member information</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documents */}
          <TabsContent value="documents">
            <Card>
              <CardHeader className="bg-gradient-to-r from-amber-50 to-yellow-50 dark:from-amber-950 dark:to-yellow-950">
                <CardTitle className="text-amber-700 dark:text-amber-300">Documents</CardTitle>
                <CardDescription>Upload and manage important documents</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Card className="border-dashed border-2">
                    <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-3" />
                      <p className="font-medium text-sm">Resume</p>
                      <p className="text-xs text-gray-500 mb-3">PDF, DOC, DOCX</p>
                      <Button variant="outline" size="sm" type="button">Upload</Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-dashed border-2">
                    <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-3" />
                      <p className="font-medium text-sm">Aadhaar Card</p>
                      <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                      <Button variant="outline" size="sm" type="button">Upload</Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-dashed border-2">
                    <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-3" />
                      <p className="font-medium text-sm">PAN Card</p>
                      <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                      <Button variant="outline" size="sm" type="button">Upload</Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-dashed border-2">
                    <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-3" />
                      <p className="font-medium text-sm">Educational Certificates</p>
                      <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                      <Button variant="outline" size="sm" type="button">Upload</Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-dashed border-2">
                    <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-3" />
                      <p className="font-medium text-sm">Experience Letters</p>
                      <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                      <Button variant="outline" size="sm" type="button">Upload</Button>
                    </CardContent>
                  </Card>
                  
                  <Card className="border-dashed border-2">
                    <CardContent className="flex flex-col items-center justify-center p-6 text-center">
                      <FileText className="h-8 w-8 text-gray-400 mb-3" />
                      <p className="font-medium text-sm">Other Documents</p>
                      <p className="text-xs text-gray-500 mb-3">PDF, JPG, PNG</p>
                      <Button variant="outline" size="sm" type="button">Upload</Button>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button - Hidden on Payroll tab as it has its own save button */}
        {activeTab !== 'payroll' && (
          <div className="flex justify-end gap-4 mt-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => window.history.back()}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={updateEmployeeMutation.isPending || saveSalaryStructureMutation.isPending}
            >
              {updateEmployeeMutation.isPending || saveSalaryStructureMutation.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        )}
      </form>
    </div>
  );
}
