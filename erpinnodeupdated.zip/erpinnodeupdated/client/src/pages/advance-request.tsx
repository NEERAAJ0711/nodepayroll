import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, DollarSign, Clock, User, CheckCircle, XCircle, Eye, CreditCard, ShieldAlert } from "lucide-react";
import { usePermission } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { AdvanceRequest, InsertAdvanceRequest } from "@shared/schema";

const advanceRequestSchema = z.object({
  amount: z.string().min(1, "Amount is required").refine(
    (val) => !isNaN(Number(val)) && Number(val) > 0,
    "Amount must be a positive number"
  ),
  reason: z.string().min(10, "Reason must be at least 10 characters"),
  repaymentPeriod: z.string().min(1, "Repayment period is required").refine(
    (val) => !isNaN(Number(val)) && Number(val) > 0 && Number(val) <= 24,
    "Repayment period must be between 1-24 months"
  ),
});

type AdvanceRequestForm = z.infer<typeof advanceRequestSchema>;

const StatusBadges = {
  pending: { color: "bg-yellow-100 text-yellow-800", label: "Pending" },
  approved: { color: "bg-green-100 text-green-800", label: "Approved" },
  rejected: { color: "bg-red-100 text-red-800", label: "Rejected" },
  cancelled: { color: "bg-gray-100 text-gray-800", label: "Cancelled" },
  paid: { color: "bg-blue-100 text-blue-800", label: "Paid" }
};

export default function AdvanceRequest() {
  const { toast } = useToast();
  const [requestDialogOpen, setRequestDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedAdvance, setSelectedAdvance] = useState<AdvanceRequest | null>(null);
  
  // Check for advance permission
  const { hasPermission: canRequestAdvance, loading: permissionLoading } = usePermission('advance_request_submit');

  const form = useForm<AdvanceRequestForm>({
    resolver: zodResolver(advanceRequestSchema),
    defaultValues: {
      amount: '',
      reason: '',
      repaymentPeriod: '6',
    },
  });

  // Get current user
  const { data: user } = useQuery<{ id: number; companyId: number; role: string }>({
    queryKey: ['/api/auth/me'],
  });

  const companyId = user?.companyId;

  // Fetch advance requests
  const { data: advanceRequests = [], isLoading } = useQuery<AdvanceRequest[]>({
    queryKey: ['advance-requests', companyId],
    queryFn: async () => {
      if (!companyId) throw new Error('No company ID');
      
      const token = localStorage.getItem('auth_token');
      const response = await fetch(`/api/advance-requests/${companyId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      return response.json();
    },
    enabled: !!companyId,
  });

  // Submit advance request
  const submitMutation = useMutation({
    mutationFn: async (data: AdvanceRequestForm) => {
      const advanceData: InsertAdvanceRequest = {
        ...data,
        amount: data.amount,
        repaymentPeriod: parseInt(data.repaymentPeriod),
        companyId: companyId!,
        employeeId: user!.id,
      };

      const response = await apiRequest('POST', '/api/advance-requests', advanceData);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Advance request submitted successfully",
      });
      setRequestDialogOpen(false);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['advance-requests', companyId] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit advance request",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: AdvanceRequestForm) => {
    submitMutation.mutate(data);
  };

  const formatCurrency = (amount: string | number) => {
    const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(numAmount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getApprovalStatus = (advance: AdvanceRequest) => {
    if (advance.status === 'rejected') return 'Rejected';
    if (advance.status === 'paid') return 'Paid';
    if (advance.status === 'approved') return 'Fully Approved';
    
    // Check approval levels
    if (advance.finalApprovedAt) return 'Final Approved';
    if (advance.level2ApprovedAt) return 'Level 2 Approved';
    if (advance.level1ApprovedAt) return 'Level 1 Approved';
    
    return 'Pending Approval';
  };

  // Permission guard - show access denied if user doesn't have permission
  if (permissionLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
            <p className="mt-2 text-gray-600">Checking permissions...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!canRequestAdvance && user?.role === 'employee') {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <ShieldAlert className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h1>
            <p className="text-gray-600 mb-4">You don't have permission to access advance requests.</p>
            <p className="text-sm text-gray-500">Please request the "advance_request_submit" permission from your administrator.</p>
          </div>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Loading advance requests...</p>
        </div>
      </div>
    );
  }

  const totalRequested = advanceRequests.reduce((sum, req) => sum + parseFloat(req.amount), 0);
  const totalApproved = advanceRequests
    .filter(req => req.status === 'approved' || req.status === 'paid')
    .reduce((sum, req) => sum + parseFloat(req.amount), 0);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Advance Requests</h1>
          <p className="text-gray-600">Request salary advance and track approval status</p>
        </div>
        <Dialog open={requestDialogOpen} onOpenChange={setRequestDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Request Advance
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Request Salary Advance</DialogTitle>
              <DialogDescription>
                Submit your advance request for approval
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount (₹)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="Enter amount"
                          step="0.01"
                          min="1"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="repaymentPeriod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Repayment Period</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select repayment period" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {Array.from({ length: 24 }, (_, i) => i + 1).map((month) => (
                            <SelectItem key={month} value={month.toString()}>
                              {month} month{month > 1 ? 's' : ''}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="reason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reason</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Please provide reason for advance request..." 
                          className="min-h-[80px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setRequestDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={submitMutation.isPending}>
                    {submitMutation.isPending ? "Submitting..." : "Submit Request"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Advance Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{advanceRequests.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {advanceRequests.filter(req => req.status === 'pending').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {advanceRequests.filter(req => req.status === 'approved' || req.status === 'paid').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Requested</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-blue-600">
              {formatCurrency(totalRequested)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Approved</CardTitle>
            <CreditCard className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-lg font-bold text-green-600">
              {formatCurrency(totalApproved)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Advance Requests List */}
      <Card>
        <CardHeader>
          <CardTitle>My Advance Requests</CardTitle>
          <CardDescription>Track your advance request status and approval progress</CardDescription>
        </CardHeader>
        <CardContent>
          {advanceRequests.length === 0 ? (
            <div className="text-center py-8">
              <DollarSign className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 mb-2">No advance requests found</p>
              <p className="text-sm text-gray-400">Submit your first advance request to get started</p>
            </div>
          ) : (
            <div className="space-y-4">
              {advanceRequests.map((advance) => (
                <div key={advance.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4">
                        <div>
                          <h3 className="font-semibold text-lg">
                            {formatCurrency(advance.amount)}
                          </h3>
                          <p className="text-sm text-gray-600">
                            Repayment: {advance.repaymentPeriod} month{advance.repaymentPeriod > 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                      <p className="text-gray-700 mt-2 line-clamp-2">{advance.reason}</p>
                      <div className="mt-2 flex items-center space-x-4">
                        <Badge className={StatusBadges[advance.status as keyof typeof StatusBadges].color}>
                          {StatusBadges[advance.status as keyof typeof StatusBadges].label}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          Applied: {formatDate(advance.appliedAt.toString())}
                        </span>
                        <span className="text-sm text-gray-600">
                          Status: {getApprovalStatus(advance)}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedAdvance(advance);
                          setViewDialogOpen(true);
                        }}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Advance Details Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Advance Request Details</DialogTitle>
          </DialogHeader>
          {selectedAdvance && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Amount</label>
                  <p className="text-lg font-semibold">{formatCurrency(selectedAdvance.amount)}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Repayment Period</label>
                  <p>{selectedAdvance.repaymentPeriod} month{selectedAdvance.repaymentPeriod > 1 ? 's' : ''}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Monthly Deduction</label>
                  <p>{formatCurrency(parseFloat(selectedAdvance.amount) / selectedAdvance.repaymentPeriod)}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Applied Date</label>
                  <p>{formatDate(selectedAdvance.appliedAt.toString())}</p>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-500">Reason</label>
                <p className="mt-1 p-3 bg-gray-50 rounded-md">{selectedAdvance.reason}</p>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-500">Approval Status</label>
                <div className="mt-2 space-y-2">
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Level 1 Approval</span>
                    <Badge className={selectedAdvance.level1ApprovedAt ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                      {selectedAdvance.level1ApprovedAt ? "Approved" : "Pending"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Level 2 Approval</span>
                    <Badge className={selectedAdvance.level2ApprovedAt ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                      {selectedAdvance.level2ApprovedAt ? "Approved" : "Pending"}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>Final Approval</span>
                    <Badge className={selectedAdvance.finalApprovedAt ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"}>
                      {selectedAdvance.finalApprovedAt ? "Approved" : "Pending"}
                    </Badge>
                  </div>
                </div>
              </div>

              {selectedAdvance.status === 'paid' && selectedAdvance.paidAt && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Payment Details</label>
                  <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-md">
                    <div className="flex justify-between items-center">
                      <span>Paid Amount:</span>
                      <span className="font-semibold">{formatCurrency(selectedAdvance.paidAmount || selectedAdvance.amount)}</span>
                    </div>
                    <div className="flex justify-between items-center mt-1">
                      <span>Payment Date:</span>
                      <span>{formatDate(selectedAdvance.paidAt.toString())}</span>
                    </div>
                    {selectedAdvance.paymentMethod && (
                      <div className="flex justify-between items-center mt-1">
                        <span>Payment Method:</span>
                        <span className="capitalize">{selectedAdvance.paymentMethod}</span>
                      </div>
                    )}
                    {selectedAdvance.paymentReference && (
                      <div className="flex justify-between items-center mt-1">
                        <span>Reference:</span>
                        <span>{selectedAdvance.paymentReference}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {selectedAdvance.rejectionReason && (
                <div>
                  <label className="text-sm font-medium text-gray-500">Rejection Reason</label>
                  <p className="mt-1 p-3 bg-red-50 border border-red-200 rounded-md text-red-800">
                    {selectedAdvance.rejectionReason}
                  </p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}