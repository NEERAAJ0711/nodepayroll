import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";

const companyProfileSchema = z.object({
  name: z.string().min(2, "Company name must be at least 2 characters"),
  address: z.string().min(5, "Company address is required"),
  type: z.enum(["proprietorship", "partnership", "private_limited", "limited"], {
    required_error: "Please select company type",
  }),
  gstPan: z.string().min(10, "GST/PAN number is required"),
  pfNo: z.string().min(1, "PF number is required"),
  esicNo: z.string().min(1, "ESIC number is required"),
  cinNo: z.string().min(1, "CIN number is required"),
  authorizedPersonName: z.string().min(2, "Authorized person name is required"),
  authorizedPersonContact: z.string().min(10, "Contact number must be at least 10 digits"),
});

type CompanyProfileData = z.infer<typeof companyProfileSchema>;

export default function CompanyProfileSetup() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: company, isLoading: companyLoading } = useQuery({
    queryKey: [`/api/companies/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const form = useForm<CompanyProfileData>({
    resolver: zodResolver(companyProfileSchema),
    defaultValues: {
      name: '',
      address: '',
      type: undefined,
      gstPan: '',
      pfNo: '',
      esicNo: '',
      cinNo: '',
      authorizedPersonName: '',
      authorizedPersonContact: '',
    },
  });

  const updateCompanyMutation = useMutation({
    mutationFn: async (data: CompanyProfileData) => {
      const response = await apiRequest('PUT', `/api/companies/${user?.companyId}`, data);
      
      // Check if update was successful
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Update failed' }));
        throw new Error(errorData.message || 'Failed to update company profile');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/companies'] });
      toast({ title: "Company profile completed successfully! Waiting for approval." });
      setLocation('/company-approval-pending');
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to update company profile", 
        description: error.message || "Please try again",
        variant: "destructive" 
      });
    },
  });

  const onSubmit = (data: CompanyProfileData) => {
    // Defensive guard: ensure companyId exists
    if (!user?.companyId) {
      toast({
        title: "Error",
        description: "Company ID not found. Please try logging in again.",
        variant: "destructive"
      });
      return;
    }
    
    updateCompanyMutation.mutate(data);
  };

  const isLoading = updateCompanyMutation.isPending || companyLoading;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-hr-background to-hr-background/80 p-4">
      <Card className="w-full max-w-4xl shadow-2xl border-0">
        <CardHeader className="text-center space-y-2 pb-6">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-hr-primary/10 p-3 rounded-full">
              <Building2 className="h-8 w-8 text-hr-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-hr-text-primary">
            Complete Company Profile
          </CardTitle>
          <CardDescription className="text-hr-text-secondary">
            Please provide your company details to continue using the HR management system
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Company Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-hr-text-primary border-b pb-2">
                Company Information
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Company Name</Label>
                  <Input
                    id="name"
                    {...form.register("name")}
                    disabled={isLoading}
                    placeholder="Enter company name"
                  />
                  {form.formState.errors.name && (
                    <p className="text-sm text-red-600">{form.formState.errors.name.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="type">Company Type</Label>
                  <Select
                    value={form.watch("type")}
                    onValueChange={(value) => form.setValue("type", value as any)}
                    disabled={isLoading}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select company type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="proprietorship">Proprietorship</SelectItem>
                      <SelectItem value="partnership">Partnership</SelectItem>
                      <SelectItem value="private_limited">Private Limited</SelectItem>
                      <SelectItem value="limited">Limited</SelectItem>
                    </SelectContent>
                  </Select>
                  {form.formState.errors.type && (
                    <p className="text-sm text-red-600">{form.formState.errors.type.message}</p>
                  )}
                </div>
              </div>

              <div>
                <Label htmlFor="address">Company Address</Label>
                <Input
                  id="address"
                  {...form.register("address")}
                  disabled={isLoading}
                  placeholder="Enter complete company address"
                />
                {form.formState.errors.address && (
                  <p className="text-sm text-red-600">{form.formState.errors.address.message}</p>
                )}
              </div>
            </div>

            {/* Legal & Registration Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-hr-text-primary border-b pb-2">
                Legal & Registration Details
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="gstPan">Company GST/PAN</Label>
                  <Input
                    id="gstPan"
                    {...form.register("gstPan")}
                    disabled={isLoading}
                    placeholder="GST or PAN number"
                  />
                  {form.formState.errors.gstPan && (
                    <p className="text-sm text-red-600">{form.formState.errors.gstPan.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="pfNo">Company PF No.</Label>
                  <Input
                    id="pfNo"
                    {...form.register("pfNo")}
                    disabled={isLoading}
                    placeholder="Provident Fund number"
                  />
                  {form.formState.errors.pfNo && (
                    <p className="text-sm text-red-600">{form.formState.errors.pfNo.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="esicNo">Company ESIC No.</Label>
                  <Input
                    id="esicNo"
                    {...form.register("esicNo")}
                    disabled={isLoading}
                    placeholder="ESIC registration number"
                  />
                  {form.formState.errors.esicNo && (
                    <p className="text-sm text-red-600">{form.formState.errors.esicNo.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="cinNo">Company CIN No.</Label>
                  <Input
                    id="cinNo"
                    {...form.register("cinNo")}
                    disabled={isLoading}
                    placeholder="Corporate Identification Number"
                  />
                  {form.formState.errors.cinNo && (
                    <p className="text-sm text-red-600">{form.formState.errors.cinNo.message}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Authorized Person Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-hr-text-primary border-b pb-2">
                Authorized Person Details
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="authorizedPersonName">Authorized Person Name</Label>
                  <Input
                    id="authorizedPersonName"
                    {...form.register("authorizedPersonName")}
                    disabled={isLoading}
                    placeholder="Full name of authorized person"
                  />
                  {form.formState.errors.authorizedPersonName && (
                    <p className="text-sm text-red-600">{form.formState.errors.authorizedPersonName.message}</p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="authorizedPersonContact">Contact Number</Label>
                  <Input
                    id="authorizedPersonContact"
                    {...form.register("authorizedPersonContact")}
                    disabled={isLoading}
                    placeholder="Contact number"
                  />
                  {form.formState.errors.authorizedPersonContact && (
                    <p className="text-sm text-red-600">{form.formState.errors.authorizedPersonContact.message}</p>
                  )}
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-hr-primary hover:bg-hr-primary/90"
              disabled={isLoading}
            >
              {isLoading ? "Saving Company Profile..." : "Complete Setup & Continue"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}