import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Edit, Trash2, Plus } from "lucide-react";
import { authService } from "@/lib/auth";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface DailyAttendanceRecord {
  id: number;
  date: string;
  day: string;
  inTime: string;
  outTime: string;
  workingHours: number;
  otHours: number;
  status: 'Present' | 'Absent' | 'Late' | 'Half Day' | 'Leave';
  source: 'Biometric' | 'Manual' | 'Self';
}

export default function DailyLogPage() {
  const [, params] = useRoute("/admin/attendance/daily-log/:employeeId/:year/:month");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const user = authService.getUser();

  const employeeId = params?.employeeId ? parseInt(params.employeeId) : 0;
  const year = params?.year ? parseInt(params.year) : new Date().getFullYear();
  const month = params?.month ? parseInt(params.month) : new Date().getMonth() + 1;

  // Dialog states
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<DailyAttendanceRecord | null>(null);
  
  // Form states
  const [formData, setFormData] = useState({
    date: '',
    inTime: '',
    outTime: '',
    status: 'Present' as DailyAttendanceRecord['status'],
    source: 'Manual' as DailyAttendanceRecord['source']
  });

  // Get employee details
  const { data: employee } = useQuery({
    queryKey: [`/api/employees/${user?.companyId}/${employeeId}`],
    enabled: !!user?.companyId && !!employeeId,
  });

  // Get daily attendance records
  const { data: dailyRecords = [], isLoading } = useQuery<DailyAttendanceRecord[]>({
    queryKey: [`/api/attendance/daily-log/${employeeId}/${year}/${month}`],
    enabled: !!employeeId,
  });

  const getMonthName = (monthNum: number) => {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months[monthNum - 1];
  };

  const calculateWorkingHours = (inTime: string, outTime: string): number => {
    if (!inTime || !outTime) return 0;
    const inDate = new Date(`1970-01-01T${inTime}`);
    const outDate = new Date(`1970-01-01T${outTime}`);
    return (outDate.getTime() - inDate.getTime()) / (1000 * 60 * 60);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Present': return 'bg-green-100 text-green-800';
      case 'Absent': return 'bg-red-100 text-red-800';
      case 'Late': return 'bg-yellow-100 text-yellow-800';
      case 'Half Day': return 'bg-blue-100 text-blue-800';
      case 'Leave': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSourceColor = (source: string) => {
    switch (source) {
      case 'Biometric': return 'bg-indigo-100 text-indigo-800';
      case 'Manual': return 'bg-orange-100 text-orange-800';
      case 'Self': return 'bg-cyan-100 text-cyan-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  // Add record mutation
  const addRecordMutation = useMutation({
    mutationFn: async (data: any) => {
      const token = authService.getToken();
      if (!token) throw new Error('Authentication required');
      
      const response = await fetch('/api/attendance/daily-record', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          employeeId,
          ...data,
          workingHours: calculateWorkingHours(data.inTime, data.outTime),
          otHours: Math.max(0, calculateWorkingHours(data.inTime, data.outTime) - 8)
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to add record');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Daily record added successfully" });
      setIsAddDialogOpen(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/daily-log/${employeeId}/${year}/${month}`] });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  // Edit record mutation
  const editRecordMutation = useMutation({
    mutationFn: async (data: any) => {
      const token = authService.getToken();
      if (!token) throw new Error('Authentication required');
      
      const response = await fetch(`/api/attendance/daily-record/${editingRecord?.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          ...data,
          workingHours: calculateWorkingHours(data.inTime, data.outTime),
          otHours: Math.max(0, calculateWorkingHours(data.inTime, data.outTime) - 8)
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update record');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Daily record updated successfully" });
      setIsEditDialogOpen(false);
      setEditingRecord(null);
      resetForm();
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/daily-log/${employeeId}/${year}/${month}`] });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  // Delete record mutation
  const deleteRecordMutation = useMutation({
    mutationFn: async (recordId: number) => {
      const token = authService.getToken();
      if (!token) throw new Error('Authentication required');
      
      const response = await fetch(`/api/attendance/daily-record/${recordId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to delete record');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Success", description: "Daily record deleted successfully" });
      queryClient.invalidateQueries({ queryKey: [`/api/attendance/daily-log/${employeeId}/${year}/${month}`] });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    }
  });

  const resetForm = () => {
    setFormData({
      date: '',
      inTime: '',
      outTime: '',
      status: 'Present',
      source: 'Manual'
    });
  };

  const handleEdit = (record: DailyAttendanceRecord) => {
    setEditingRecord(record);
    setFormData({
      date: record.date,
      inTime: record.inTime,
      outTime: record.outTime,
      status: record.status,
      source: record.source
    });
    setIsEditDialogOpen(true);
  };

  const handleDelete = (record: DailyAttendanceRecord) => {
    if (window.confirm(`Are you sure you want to delete the record for ${record.date}?`)) {
      deleteRecordMutation.mutate(record.id);
    }
  };

  const submitForm = () => {
    if (!formData.date || !formData.inTime) {
      toast({ title: "Error", description: "Date and In Time are required", variant: "destructive" });
      return;
    }
    
    if (editingRecord) {
      editRecordMutation.mutate(formData);
    } else {
      addRecordMutation.mutate(formData);
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">Loading daily attendance records...</div>
        </div>
      </div>
    );
  }

  const employeeName = employee ? `${employee[0]?.firstName} ${employee[0]?.lastName}` : 'Employee';

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={() => setLocation('/admin/attendance')}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Attendance
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Daily Attendance Log</h1>
            <p className="text-gray-600">
              {employeeName} - {getMonthName(month)} {year}
            </p>
          </div>
        </div>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Record
        </Button>
      </div>

      {/* Daily Records Table */}
      <Card>
        <CardHeader>
          <CardTitle>Daily Attendance Records</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Day</TableHead>
                <TableHead>In Time</TableHead>
                <TableHead>Out Time</TableHead>
                <TableHead>Working Hours</TableHead>
                <TableHead>OT Hours</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Source</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {dailyRecords.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8 text-gray-500">
                    No daily attendance records found for this period
                  </TableCell>
                </TableRow>
              ) : (
                dailyRecords.map((record) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">{record.date}</TableCell>
                    <TableCell>{record.day}</TableCell>
                    <TableCell>{record.inTime || '-'}</TableCell>
                    <TableCell>{record.outTime || '-'}</TableCell>
                    <TableCell>{record.workingHours.toFixed(1)}h</TableCell>
                    <TableCell>{record.otHours.toFixed(1)}h</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(record.status)}>
                        {record.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getSourceColor(record.source)}>
                        {record.source}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(record)}
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-600 hover:text-red-700"
                          onClick={() => handleDelete(record)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add Record Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Daily Record</DialogTitle>
            <DialogDescription>Add new daily attendance record</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="inTime">In Time</Label>
                <Input
                  id="inTime"
                  type="time"
                  value={formData.inTime}
                  onChange={(e) => setFormData({ ...formData, inTime: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="outTime">Out Time</Label>
                <Input
                  id="outTime"
                  type="time"
                  value={formData.outTime}
                  onChange={(e) => setFormData({ ...formData, outTime: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value: DailyAttendanceRecord['status']) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Present">Present</SelectItem>
                    <SelectItem value="Absent">Absent</SelectItem>
                    <SelectItem value="Late">Late</SelectItem>
                    <SelectItem value="Half Day">Half Day</SelectItem>
                    <SelectItem value="Leave">Leave</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="source">Source</Label>
                <Select value={formData.source} onValueChange={(value: DailyAttendanceRecord['source']) => setFormData({ ...formData, source: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Biometric">Biometric</SelectItem>
                    <SelectItem value="Manual">Manual</SelectItem>
                    <SelectItem value="Self">Self</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => { setIsAddDialogOpen(false); resetForm(); }}>
                Cancel
              </Button>
              <Button onClick={submitForm} disabled={addRecordMutation.isPending}>
                {addRecordMutation.isPending ? "Adding..." : "Add Record"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Record Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Daily Record</DialogTitle>
            <DialogDescription>Update daily attendance record</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="editDate">Date</Label>
              <Input
                id="editDate"
                type="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="editInTime">In Time</Label>
                <Input
                  id="editInTime"
                  type="time"
                  value={formData.inTime}
                  onChange={(e) => setFormData({ ...formData, inTime: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="editOutTime">Out Time</Label>
                <Input
                  id="editOutTime"
                  type="time"
                  value={formData.outTime}
                  onChange={(e) => setFormData({ ...formData, outTime: e.target.value })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="editStatus">Status</Label>
                <Select value={formData.status} onValueChange={(value: DailyAttendanceRecord['status']) => setFormData({ ...formData, status: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Present">Present</SelectItem>
                    <SelectItem value="Absent">Absent</SelectItem>
                    <SelectItem value="Late">Late</SelectItem>
                    <SelectItem value="Half Day">Half Day</SelectItem>
                    <SelectItem value="Leave">Leave</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="editSource">Source</Label>
                <Select value={formData.source} onValueChange={(value: DailyAttendanceRecord['source']) => setFormData({ ...formData, source: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Biometric">Biometric</SelectItem>
                    <SelectItem value="Manual">Manual</SelectItem>
                    <SelectItem value="Self">Self</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => { setIsEditDialogOpen(false); setEditingRecord(null); resetForm(); }}>
                Cancel
              </Button>
              <Button onClick={submitForm} disabled={editRecordMutation.isPending}>
                {editRecordMutation.isPending ? "Updating..." : "Update Record"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}