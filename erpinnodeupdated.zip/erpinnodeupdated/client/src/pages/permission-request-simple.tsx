import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { FileText, CheckCircle, XCircle, Clock } from 'lucide-react';

export default function PermissionRequestSimple() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [permissionType, setPermissionType] = useState('');
  const [reason, setReason] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch permission requests
  const { data: permissionRequests = [], isLoading } = useQuery({
    queryKey: ['/api/permission-requests'],
    queryFn: async () => {
      const response = await fetch('/api/permission-requests', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
      });
      if (!response.ok) throw new Error('Failed to fetch');
      return response.json();
    },
  });

  // Create permission request mutation
  const createRequestMutation = useMutation({
    mutationFn: async (data: { permissionType: string; reason: string }) => {
      const response = await fetch('/api/permission-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to create permission request');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/permission-requests'] });
      setIsDialogOpen(false);
      setPermissionType('');
      setReason('');
      toast({ title: 'Success', description: 'Permission request submitted successfully!' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to create permission request', variant: 'destructive' });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!permissionType || !reason) {
      toast({ title: "Error", description: "Please fill all fields", variant: "destructive" });
      return;
    }
    
    createRequestMutation.mutate({ permissionType, reason });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Permission Requests</h1>
          <p className="text-muted-foreground">
            Request additional permissions from your administrator
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              className="bg-blue-600 hover:bg-blue-700 text-white"
              onClick={() => setIsDialogOpen(true)}
            >
              <FileText className="w-4 h-4 mr-2" />
              Request New Permission
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Request Permission</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="permissionType">Permission Type</Label>
                <Select value={permissionType} onValueChange={setPermissionType} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select permission type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="employee_edit">Employee Edit - Edit employee information</SelectItem>
                    <SelectItem value="employee_create">Employee Create - Create new employee records</SelectItem>
                    <SelectItem value="employee_delete">Employee Delete - Delete employee records</SelectItem>
                    <SelectItem value="job_create">Job Create - Create new job postings</SelectItem>
                    <SelectItem value="job_edit">Job Edit - Edit existing job postings</SelectItem>
                    <SelectItem value="job_delete">Job Delete - Delete job postings</SelectItem>
                    <SelectItem value="department_create">Department Create - Create new departments</SelectItem>
                    <SelectItem value="department_edit">Department Edit - Edit department information</SelectItem>
                    <SelectItem value="company_settings">Company Settings - Access company settings</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="reason">Reason for Request</Label>
                <Input 
                  id="reason" 
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  required 
                  placeholder="Explain why you need this permission"
                />
              </div>
              <Button 
                type="submit" 
                disabled={createRequestMutation.isPending}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {createRequestMutation.isPending ? 'Submitting...' : 'Submit Permission Request'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>My Permission Requests</CardTitle>
          <CardDescription>
            Track your submitted permission requests and their status
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div>Loading requests...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Permission Type</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {permissionRequests.map((request: any) => (
                  <TableRow key={request.id}>
                    <TableCell className="font-medium">{request.permissionType}</TableCell>
                    <TableCell>{request.reason}</TableCell>
                    <TableCell>{getStatusBadge(request.status)}</TableCell>
                    <TableCell>{new Date(request.createdAt).toLocaleDateString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}