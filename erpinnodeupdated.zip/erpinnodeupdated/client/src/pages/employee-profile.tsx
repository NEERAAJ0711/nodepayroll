import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { 
  Edit, Save, User, MapPin, Phone, Mail, Briefcase, Calendar, Building, 
  Camera, Upload, X, Check, Star, Award, GraduationCap, Clock, DollarSign,
  FileText, Shield, CreditCard, Users, Home, Settings, Eye, Search, RotateCw
} from "lucide-react";
import { useAuth, apiRequestWithAuth } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import React, { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRoute } from "wouter";
import type { EmployeeProfile, Job, JobApplication, KycDetails } from "@shared/schema";

const profileSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  fatherName: z.string().optional(),
  presentAddress: z.string().optional(),
  permanentAddress: z.string().optional(),
  currentSalary: z.string().optional(),
  expectedSalary: z.string().optional(),
  noticePeriod: z.string().optional(),
  primaryContact: z.string().optional(),
  alternativeContact: z.string().optional(),
  totalExperience: z.string().optional(),
  speciality: z.string().optional(),
  skills: z.string().optional(),
  experience: z.string().optional(),
  phone: z.string().optional(),
  address: z.string().optional(),
  // Employment Information fields
  position: z.string().optional(),
  departmentId: z.string().optional(),
  branchId: z.string().optional(),
  locationId: z.string().optional(),
  costCenterId: z.string().optional(),
  designationId: z.string().optional(),
  hireDate: z.string().optional(),
  status: z.string().optional(),
  // Time Office Policy fields
  dutyStartTime: z.string().optional(),
  dutyEndTime: z.string().optional(),
  permissibleLateArrival: z.string().optional(),
  permissibleEarlyDeparture: z.string().optional(),
  firstWeeklyOffDay: z.string().optional(),
  secondWeeklyOffDay: z.string().optional(),
  overtimeApplicable: z.boolean().optional(),
  presentMarkingDuration: z.string().optional(),
});

const kycSchema = z.object({
  aadharNo: z.string().optional(),
  panNo: z.string().optional(),
  bankAccountNo: z.string().optional(),
  ifscCode: z.string().optional(),
  uanNo: z.string().optional(),
  esicNo: z.string().optional(),
});

type ProfileData = z.infer<typeof profileSchema>;
type KycData = z.infer<typeof kycSchema>;

export default function EmployeeProfile() {
  const { user } = useAuth();
  const [, params] = useRoute("/admin/employees/:employeeId");
  const employeeId = params?.employeeId;
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingKyc, setIsEditingKyc] = useState(false);
  const [profileImage, setProfileImage] = useState<string | null>(null);
  
  // Role-based permission helpers
  const isEmployee = user?.role === 'employee';
  const isAdmin = user?.role === 'admin' || user?.role === 'system_admin';
  const canEditTimeOfficePolicy = isAdmin; // Entire Time Office Policy is admin-only
  const [isUploadingImage, setIsUploadingImage] = useState(false);
  const [selectedShiftId, setSelectedShiftId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: profile, isLoading } = useQuery<EmployeeProfile>({
    queryKey: [`/api/employees/${user?.companyId}/${employeeId}`],
    enabled: !!user?.companyId && !!employeeId,
    staleTime: 0, // Always fetch fresh data to get latest profile info
    refetchOnMount: true,
  });

  const { data: availableJobs = [] } = useQuery<Job[]>({
    queryKey: ['/api/jobs/public'],
  });

  const { data: myApplications = [] } = useQuery<JobApplication[]>({
    queryKey: ['/api/job-applications/my'],
    enabled: !!user?.id,
  });

  const { data: kycDetails } = useQuery<KycDetails>({
    queryKey: ['/api/employee/kyc'],
    enabled: !!profile?.id,
    staleTime: 0, // Always fetch fresh KYC data including Aadhaar info
    refetchOnMount: true,
  });

  // Shift-related queries
  const { data: availableShifts = [] } = useQuery<Array<{
    id: number;
    name: string;
    startTime: string;
    endTime: string;
    colorCode?: string;
    breakDuration: number;
  }>>({
    queryKey: [`/api/shifts/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: employeeShifts = [] } = useQuery<Array<{
    id: number;
    shift?: {
      name: string;
      startTime: string;
      endTime: string;
      breakDuration: number;
    };
  }>>({
    queryKey: [`/api/employee-shifts/${profile?.id}`],
    enabled: !!profile?.id,
  });

  // Organizational data queries
  const { data: departments = [] } = useQuery<Array<{
    id: number;
    name: string;
    description?: string;
  }>>({  
    queryKey: [`/api/departments/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: branches = [] } = useQuery<Array<{
    id: number;
    name: string;
    address?: string;
    city?: string;
  }>>({  
    queryKey: [`/api/branches/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: locations = [] } = useQuery<Array<{
    id: number;
    name: string;
    branchId: number;
  }>>({  
    queryKey: [`/api/locations/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: costCenters = [] } = useQuery<Array<{
    id: number;
    name: string;
    code: string;
  }>>({  
    queryKey: [`/api/cost-centers/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: designations = [] } = useQuery<Array<{
    id: number;
    title: string;
    level?: string;
    departmentId: number;
  }>>({  
    queryKey: [`/api/designations/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const form = useForm<ProfileData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: profile?.firstName || '',
      lastName: profile?.lastName || '',
      fatherName: profile?.fatherName || '',
      presentAddress: profile?.presentAddress || '',
      permanentAddress: profile?.permanentAddress || '',
      currentSalary: profile?.currentSalary || '',
      expectedSalary: profile?.expectedSalary || '',
      noticePeriod: profile?.noticePeriod || '',
      primaryContact: profile?.primaryContact || '',
      alternativeContact: profile?.alternativeContact || '',
      totalExperience: profile?.totalExperience || '',
      speciality: profile?.speciality || '',
      skills: profile?.skills || '',
      experience: profile?.experience || '',
      phone: profile?.phone || '',
      address: profile?.address || '',
      dutyStartTime: profile?.dutyStartTime || '',
      dutyEndTime: profile?.dutyEndTime || '',
      permissibleLateArrival: profile?.permissibleLateArrival || '',
      permissibleEarlyDeparture: profile?.permissibleEarlyDeparture || '',
      firstWeeklyOffDay: profile?.firstWeeklyOffDay || '',
      secondWeeklyOffDay: profile?.secondWeeklyOffDay || '',
      overtimeApplicable: profile?.overtimeApplicable || false,
      presentMarkingDuration: profile?.presentMarkingDuration || '',
      // Employment Information
      position: profile?.position || '',
      departmentId: profile?.departmentId?.toString() || '',
      branchId: profile?.branchId?.toString() || '',
      locationId: profile?.locationId?.toString() || '',
      costCenterId: profile?.costCenterId?.toString() || '',
      designationId: profile?.designationId?.toString() || '',
      hireDate: profile?.hireDate || '',
      status: profile?.status || 'Active',
    },
  });

  // Reset form when profile data changes
  React.useEffect(() => {
    if (profile) {
      console.log('Profile data loaded for prefilling:', profile);
      const formData = {
        firstName: profile.firstName || '',
        lastName: profile.lastName || '',
        fatherName: profile.fatherName || '',
        presentAddress: profile.presentAddress || '',
        permanentAddress: profile.permanentAddress || '',
        currentSalary: profile.currentSalary || '',
        expectedSalary: profile.expectedSalary || '',
        noticePeriod: profile.noticePeriod || '',
        primaryContact: profile.primaryContact || '',
        alternativeContact: profile.alternativeContact || '',
        totalExperience: profile.totalExperience || '',
        speciality: profile.speciality || '',
        skills: profile.skills || '',
        experience: profile.experience || '',
        phone: profile.phone || '',
        address: profile.address || '',
        dutyStartTime: profile.dutyStartTime || '',
        dutyEndTime: profile.dutyEndTime || '',
        permissibleLateArrival: profile.permissibleLateArrival || '',
        permissibleEarlyDeparture: profile.permissibleEarlyDeparture || '',
        firstWeeklyOffDay: profile.firstWeeklyOffDay || '',
        secondWeeklyOffDay: profile.secondWeeklyOffDay || '',
        overtimeApplicable: profile.overtimeApplicable || false,
        presentMarkingDuration: profile.presentMarkingDuration || '',
        // Employment Information
        position: profile.position || '',
        departmentId: profile.departmentId?.toString() || '',
        branchId: profile.branchId?.toString() || '',
        locationId: profile.locationId?.toString() || '',
        costCenterId: profile.costCenterId?.toString() || '',
        designationId: profile.designationId?.toString() || '',
        hireDate: profile.hireDate || '',
        status: profile.status || 'Active',
      };
      console.log('Form data being set:', formData);
      form.reset(formData);
    }
  }, [profile, form]);

  const kycForm = useForm<KycData>({
    resolver: zodResolver(kycSchema),
    defaultValues: {
      aadharNo: kycDetails?.aadharNo || '',
      panNo: kycDetails?.panNo || '',
      bankAccountNo: kycDetails?.bankAccountNo || '',
      ifscCode: kycDetails?.ifscCode || '',
      uanNo: kycDetails?.uanNo || '',
      esicNo: kycDetails?.esicNo || '',
    },
  });

  // Reset KYC form when data changes
  React.useEffect(() => {
    if (kycDetails) {
      console.log('KYC data loaded for prefilling:', kycDetails);
      const kycFormData = {
        aadharNo: kycDetails.aadharNo || '',
        panNo: kycDetails.panNo || '',
        bankAccountNo: kycDetails.bankAccountNo || '',
        ifscCode: kycDetails.ifscCode || '',
        uanNo: kycDetails.uanNo || '',
        esicNo: kycDetails.esicNo || '',
      };
      console.log('KYC form data being set:', kycFormData);
      kycForm.reset(kycFormData);
    }
  }, [kycDetails, kycForm]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileData) => {
      const response = await apiRequestWithAuth('PUT', '/api/employee/profile', data);
      const result = await response.json();
      
      // Throw error for non-2xx status codes except 202 (change request)
      if (!response.ok && response.status !== 202) {
        const error = new Error(result.message || `HTTP ${response.status}`) as any;
        error.status = response.status;
        error.response = result;
        throw error;
      }
      
      return { status: response.status, data: result };
    },
    onSuccess: ({ status, data }) => {
      if (status === 202) {
        // Change request submitted for admin approval (employee)
        toast({ 
          title: "Profile update request submitted", 
          description: "Your changes will be reviewed by an administrator",
          variant: "default"
        });
        setIsEditing(false);
        queryClient.invalidateQueries({ queryKey: ['/api/employee/profile'] });
      } else if (status === 200 || status === 201) {
        // Direct update successful (admin)
        toast({ title: "Profile updated successfully!" });
        setIsEditing(false);
        queryClient.invalidateQueries({ queryKey: ['/api/employee/profile'] });
      }
    },
    onError: (error: any) => {
      console.error('Profile update error:', error);
      let errorMessage = "Unknown error occurred";
      
      if (error.status === 403) {
        errorMessage = error.response?.adminOnlyFields ? 
          `Access denied. You cannot edit admin-only fields: ${error.response.adminOnlyFields.join(', ')}. These fields require admin approval.` :
          "Access denied. You cannot edit admin-only fields like weekly off configuration.";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast({ 
        title: "Failed to update profile", 
        description: errorMessage,
        variant: "destructive" 
      });
    },
  });

  const applyToJobMutation = useMutation({
    mutationFn: async (jobId: number) => {
      return await apiRequest('POST', '/api/job-applications', {
        jobId,
        applicantName: `${profile?.firstName} ${profile?.lastName}`,
        applicantEmail: user?.email,
        applicantPhone: profile?.phone || '',
        coverLetter: 'Applied through employee portal',
      });
    },
    onSuccess: () => {
      toast({ title: "Application submitted successfully!" });
      queryClient.invalidateQueries({ queryKey: ['/api/job-applications/my'] });
    },
    onError: () => {
      toast({ 
        title: "Failed to submit application", 
        variant: "destructive" 
      });
    },
  });

  const updateKycMutation = useMutation({
    mutationFn: async (data: KycData) => {
      return await apiRequest('PUT', '/api/employee/kyc', data);
    },
    onSuccess: () => {
      toast({ title: "KYC details updated successfully!" });
      setIsEditingKyc(false);
      queryClient.invalidateQueries({ queryKey: ['/api/employee/kyc'] });
    },
    onError: () => {
      toast({ 
        title: "Failed to update KYC details", 
        variant: "destructive" 
      });
    },
  });

  // Shift assignment mutation
  const assignShiftMutation = useMutation({
    mutationFn: async (shiftData: { employeeId: number; shiftId: number }) => {
      return await apiRequestWithAuth('POST', '/api/employee-shifts', shiftData);
    },
    onSuccess: () => {
      toast({ title: "Shift assigned successfully!" });
      queryClient.invalidateQueries({ queryKey: [`/api/employee-shifts/${profile?.id}`] });
    },
    onError: () => {
      toast({ 
        title: "Failed to assign shift", 
        variant: "destructive" 
      });
    },
  });

  const onSubmit = (data: ProfileData) => {
    updateProfileMutation.mutate(data);
  };

  const onKycSubmit = (data: KycData) => {
    updateKycMutation.mutate(data);
  };

  // Handle profile image upload
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      toast({
        title: "Error",
        description: "Image size should be less than 5MB",
        variant: "destructive",
      });
      return;
    }

    setIsUploadingImage(true);
    try {
      // Create a data URL for the image preview
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfileImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      
      toast({
        title: "Success",
        description: "Profile photo updated successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload image",
        variant: "destructive",
      });
    } finally {
      setIsUploadingImage(false);
    }
  };

  const removeProfileImage = () => {
    setProfileImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getInitials = (firstName?: string, lastName?: string) => {
    return `${firstName?.charAt(0) || ''}${lastName?.charAt(0) || ''}`.toUpperCase();
  };

  const getProfileCompleteness = () => {
    if (!profile) return 0;
    const fields = [
      profile.firstName,
      profile.lastName,
      profile.phone,
      profile.address,
      profile.skills,
      profile.experience,
      kycDetails?.aadharNo,
      kycDetails?.panNo,
    ];
    const filledFields = fields.filter(field => field && field.trim() !== '').length;
    return Math.round((filledFields / fields.length) * 100);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };



  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading your profile...</p>
        </div>
      </div>
    );
  }

  const completeness = getProfileCompleteness();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header Section */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8">
            {/* Profile Photo Section */}
            <div className="relative group">
              <div className="relative">
                <Avatar className="w-32 h-32 border-4 border-white shadow-lg">
                  {profileImage ? (
                    <AvatarImage src={profileImage} alt="Profile" />
                  ) : (
                    <AvatarFallback className="text-2xl font-semibold bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                      {getInitials(profile?.firstName, profile?.lastName)}
                    </AvatarFallback>
                  )}
                </Avatar>
                
                {/* Upload Button */}
                <div className="absolute inset-0 bg-black bg-opacity-50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                  <Button
                    size="sm"
                    variant="secondary"
                    className="bg-white bg-opacity-90 hover:bg-opacity-100"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploadingImage}
                  >
                    {isUploadingImage ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600" />
                    ) : (
                      <Camera className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                
                {/* Remove Image Button */}
                {profileImage && (
                  <Button
                    size="sm"
                    variant="destructive"
                    className="absolute -top-2 -right-2 rounded-full h-8 w-8 p-0"
                    onClick={removeProfileImage}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </div>

            {/* Profile Info */}
            <div className="flex-1 text-center lg:text-left">
              <div className="mb-4">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  {profile?.firstName} {profile?.lastName}
                </h1>
                <p className="text-lg text-gray-600 mb-3">
                  {profile?.speciality || 'Software Professional'} 
                </p>
                
                {/* Contact Info */}
                <div className="flex flex-wrap justify-center lg:justify-start gap-4 text-sm text-gray-500">
                  {user?.email && (
                    <div className="flex items-center gap-1">
                      <Mail className="h-4 w-4" />
                      <span>{user.email}</span>
                    </div>
                  )}
                  {profile?.phone && (
                    <div className="flex items-center gap-1">
                      <Phone className="h-4 w-4" />
                      <span>{profile.phone}</span>
                    </div>
                  )}
                  {profile?.address && (
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{profile.address}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Profile Completeness */}
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-700">Profile Completeness</span>
                  <span className="text-sm font-semibold text-gray-900">{completeness}%</span>
                </div>
                <Progress value={completeness} className="h-2" />
                <p className="text-xs text-gray-500 mt-1">
                  {completeness < 100 ? "Complete your profile to increase visibility to employers" : "Your profile is complete!"}
                </p>
              </div>

              {/* Quick Stats */}
              <div className="flex justify-center lg:justify-start gap-6">
                <div className="text-center">
                  <div className="text-xl font-bold text-blue-600">{profile?.totalExperience || '0'}</div>
                  <div className="text-xs text-gray-500">Years Exp.</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-green-600">{myApplications.length}</div>
                  <div className="text-xs text-gray-500">Applications</div>
                </div>
                <div className="text-center">
                  <div className="text-xl font-bold text-purple-600">{availableJobs.length}</div>
                  <div className="text-xs text-gray-500">Open Jobs</div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2">
              <Button onClick={() => setIsEditing(!isEditing)} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                {isEditing ? (
                  <>
                    <X className="mr-2 h-4 w-4" />
                    Cancel Edit
                  </>
                ) : (
                  <>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Profile
                  </>
                )}
              </Button>
              <Button variant="outline" onClick={() => window.print()}>
                <FileText className="mr-2 h-4 w-4" />
                Download Resume
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        <Tabs defaultValue="time-office" className="space-y-6">
          <TabsList className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-7 w-full">
            <TabsTrigger value="personal" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">Personal</span>
            </TabsTrigger>
            <TabsTrigger value="professional" className="flex items-center gap-2">
              <Briefcase className="h-4 w-4" />
              <span className="hidden sm:inline">Professional</span>
            </TabsTrigger>
            <TabsTrigger value="time-office" className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span className="hidden sm:inline">Time Office</span>
            </TabsTrigger>
            <TabsTrigger value="documents" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span className="hidden sm:inline">Documents</span>
            </TabsTrigger>
            <TabsTrigger value="jobs" className="flex items-center gap-2">
              <Search className="h-4 w-4" />
              <span className="hidden sm:inline">Jobs</span>
            </TabsTrigger>
            <TabsTrigger value="applications" className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Applications</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Settings</span>
            </TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Personal Information
                </CardTitle>
                <CardDescription className="text-blue-100">
                  Your basic personal and contact information
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {isEditing ? (
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="firstName" className="text-sm font-medium">First Name *</Label>
                        <Input
                          id="firstName"
                          {...form.register("firstName")}
                          className="h-12"
                          placeholder="Enter your first name"
                        />
                        {form.formState.errors.firstName && (
                          <p className="text-sm text-red-600">{form.formState.errors.firstName.message}</p>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="lastName" className="text-sm font-medium">Last Name *</Label>
                        <Input
                          id="lastName"
                          {...form.register("lastName")}
                          className="h-12"
                          placeholder="Enter your last name"
                        />
                        {form.formState.errors.lastName && (
                          <p className="text-sm text-red-600">{form.formState.errors.lastName.message}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="fatherName" className="text-sm font-medium">Father's Name</Label>
                        <Input
                          id="fatherName"
                          {...form.register("fatherName")}
                          className="h-12"
                          placeholder="Enter your father's name"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-sm font-medium">Phone Number</Label>
                        <Input
                          id="phone"
                          {...form.register("phone")}
                          className="h-12"
                          placeholder="Enter your phone number"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="presentAddress" className="text-sm font-medium">Present Address</Label>
                        <Textarea
                          id="presentAddress"
                          {...form.register("presentAddress")}
                          className="min-h-[100px]"
                          placeholder="Enter your current address"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="permanentAddress" className="text-sm font-medium">Permanent Address</Label>
                        <Textarea
                          id="permanentAddress"
                          {...form.register("permanentAddress")}
                          className="min-h-[100px]"
                          placeholder="Enter your permanent address"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="submit" 
                        disabled={updateProfileMutation.isPending}
                        className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                      >
                        {updateProfileMutation.isPending ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Changes
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">First Name</Label>
                          <p className="text-lg font-medium">{profile?.firstName || 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Father's Name</Label>
                          <p className="text-lg font-medium">{profile?.fatherName || 'Not provided'}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Last Name</Label>
                          <p className="text-lg font-medium">{profile?.lastName || 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Phone Number</Label>
                          <p className="text-lg font-medium">{profile?.phone || 'Not provided'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Present Address</Label>
                          <p className="text-lg">{profile?.presentAddress || 'Not provided'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Permanent Address</Label>
                          <p className="text-lg">{profile?.permanentAddress || 'Not provided'}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Professional Information Tab */}
          <TabsContent value="professional">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5" />
                  Professional Information
                </CardTitle>
                <CardDescription className="text-purple-100">
                  Your career and work-related details
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {isEditing ? (
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="speciality" className="text-sm font-medium">Specialization</Label>
                        <Input
                          id="speciality"
                          {...form.register("speciality")}
                          className="h-12"
                          placeholder="e.g., Software Engineer, Data Analyst"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="totalExperience" className="text-sm font-medium">Total Experience (Years)</Label>
                        <Input
                          id="totalExperience"
                          {...form.register("totalExperience")}
                          className="h-12"
                          placeholder="e.g., 2.5"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="currentSalary" className="text-sm font-medium">Current Salary (LPA)</Label>
                        <Input
                          id="currentSalary"
                          {...form.register("currentSalary")}
                          className="h-12"
                          placeholder="e.g., 8.5"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="expectedSalary" className="text-sm font-medium">Expected Salary (LPA)</Label>
                        <Input
                          id="expectedSalary"
                          {...form.register("expectedSalary")}
                          className="h-12"
                          placeholder="e.g., 12.0"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="noticePeriod" className="text-sm font-medium">Notice Period</Label>
                        <Input
                          id="noticePeriod"
                          {...form.register("noticePeriod")}
                          className="h-12"
                          placeholder="e.g., 30 days, Immediate"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="primaryContact" className="text-sm font-medium">Primary Contact</Label>
                        <Input
                          id="primaryContact"
                          {...form.register("primaryContact")}
                          className="h-12"
                          placeholder="Alternative contact number"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="skills" className="text-sm font-medium">Skills</Label>
                        <Textarea
                          id="skills"
                          {...form.register("skills")}
                          className="min-h-[100px]"
                          placeholder="e.g., React, Node.js, Python, SQL, AWS"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="experience" className="text-sm font-medium">Work Experience</Label>
                        <Textarea
                          id="experience"
                          {...form.register("experience")}
                          className="min-h-[120px]"
                          placeholder="Describe your work experience, projects, and achievements"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4">
                      <Button 
                        type="submit" 
                        disabled={updateProfileMutation.isPending}
                        className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                      >
                        {updateProfileMutation.isPending ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Changes
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Specialization</Label>
                          <p className="text-lg font-medium">{profile?.speciality || 'Not specified'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Current Salary</Label>
                          <p className="text-lg font-medium">{profile?.currentSalary ? `₹${profile.currentSalary} LPA` : 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Notice Period</Label>
                          <p className="text-lg font-medium">{profile?.noticePeriod || 'Not specified'}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Total Experience</Label>
                          <p className="text-lg font-medium">{profile?.totalExperience ? `${profile.totalExperience} years` : 'Not specified'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Expected Salary</Label>
                          <p className="text-lg font-medium">{profile?.expectedSalary ? `₹${profile.expectedSalary} LPA` : 'Not provided'}</p>
                        </div>
                        <div>
                          <Label className="text-sm text-gray-500">Primary Contact</Label>
                          <p className="text-lg font-medium">{profile?.primaryContact || 'Not provided'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Skills</Label>
                          <p className="text-lg">{profile?.skills || 'No skills listed'}</p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-3">
                        <div>
                          <Label className="text-sm text-gray-500">Work Experience</Label>
                          <div className="prose max-w-none">
                            <p className="text-lg">{profile?.experience || 'No experience details provided'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Time Office Policy Tab */}
          <TabsContent value="time-office">
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-indigo-500 to-blue-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Time Office Policy
                </CardTitle>
                <CardDescription className="text-indigo-100">
                  Configure working hours, shift assignments, weekly offs, and attendance policies
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                {isEditing ? (
                  <form onSubmit={form.handleSubmit((data) => updateProfileMutation.mutate(data))} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      
                      {/* Shift Assignment Card */}
                      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <RotateCw className="h-5 w-5 text-blue-600" />
                          <h4 className="font-semibold text-blue-800">Shift Assignment</h4>
                          {!canEditTimeOfficePolicy && (
                            <Badge variant="secondary" className="text-xs">
                              <Shield className="h-3 w-3 mr-1" />
                              Admin Only
                            </Badge>
                          )}
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <Label className="text-sm font-medium text-gray-700 mb-2 block">Current Shift</Label>
                            {canEditTimeOfficePolicy ? (
                              <Select value={selectedShiftId || ''} onValueChange={setSelectedShiftId}>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a shift" />
                                </SelectTrigger>
                                <SelectContent>
                                  {availableShifts.map((shift: any) => (
                                    <SelectItem key={shift.id} value={shift.id.toString()}>
                                      <div className="flex items-center gap-2">
                                        <div 
                                          className="w-3 h-3 rounded-full" 
                                          style={{ backgroundColor: shift.colorCode || '#3b82f6' }}
                                        />
                                        {shift.name} ({shift.startTime} - {shift.endTime})
                                      </div>
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            ) : (
                              <div className="p-3 bg-gray-50 border rounded-md text-gray-700">
                                {employeeShifts.length > 0 ? 
                                  employeeShifts[0]?.shift?.name || 'Unknown Shift' : 
                                  'No shift assigned'
                                }
                              </div>
                            )}
                          </div>

                          {canEditTimeOfficePolicy && selectedShiftId && (
                            <Button 
                              type="button"
                              onClick={() => assignShiftMutation.mutate({ 
                                employeeId: profile?.id!, 
                                shiftId: parseInt(selectedShiftId) 
                              })}
                              className="w-full"
                              disabled={assignShiftMutation.isPending}
                            >
                              {assignShiftMutation.isPending ? (
                                <>
                                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                                  Assigning...
                                </>
                              ) : (
                                <>
                                  <RotateCw className="mr-2 h-4 w-4" />
                                  Assign Shift
                                </>
                              )}
                            </Button>
                          )}

                          {employeeShifts.length > 0 && (
                            <div className="p-3 bg-blue-50 border border-blue-200 rounded-md">
                              <div className="text-sm font-medium text-blue-800 mb-1">Current Details</div>
                              <div className="space-y-1 text-xs text-blue-600">
                                <div>Time: {employeeShifts[0]?.shift?.startTime} - {employeeShifts[0]?.shift?.endTime}</div>
                                <div>Break: {employeeShifts[0]?.shift?.breakDuration} minutes</div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Work Timing Card */}
                      <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-lg p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <Clock className="h-5 w-5 text-green-600" />
                          <h4 className="font-semibold text-green-800">Work Timing</h4>
                          {!canEditTimeOfficePolicy && (
                            <Badge variant="secondary" className="text-xs">
                              <Shield className="h-3 w-3 mr-1" />
                              Admin Only
                            </Badge>
                          )}
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="dutyStartTime" className="text-sm font-medium text-gray-700 mb-2 block">
                              Start Time
                            </Label>
                            {canEditTimeOfficePolicy ? (
                              <Input
                                id="dutyStartTime"
                                type="time"
                                {...form.register("dutyStartTime")}
                              />
                            ) : (
                              <div className="p-3 bg-gray-50 border rounded-md text-gray-700">
                                {form.watch("dutyStartTime") || "Not set"}
                              </div>
                            )}
                          </div>

                          <div>
                            <Label htmlFor="dutyEndTime" className="text-sm font-medium text-gray-700 mb-2 block">
                              End Time
                            </Label>
                            {canEditTimeOfficePolicy ? (
                              <Input
                                id="dutyEndTime"
                                type="time"
                                {...form.register("dutyEndTime")}
                              />
                            ) : (
                              <div className="p-3 bg-gray-50 border rounded-md text-gray-700">
                                {form.watch("dutyEndTime") || "Not set"}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Flexibility & Schedule Card */}
                      <div className="bg-gradient-to-br from-purple-50 to-violet-50 border border-purple-200 rounded-lg p-6">
                        <div className="flex items-center gap-2 mb-4">
                          <Settings className="h-5 w-5 text-purple-600" />
                          <h4 className="font-semibold text-purple-800">Flexibility & Schedule</h4>
                          {!canEditTimeOfficePolicy && (
                            <Badge variant="secondary" className="text-xs">
                              <Shield className="h-3 w-3 mr-1" />
                              Admin Only
                            </Badge>
                          )}
                        </div>
                        
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="permissibleLateArrival" className="text-sm font-medium text-gray-700 mb-2 block">
                              Late Arrival (minutes)
                            </Label>
                            {canEditTimeOfficePolicy ? (
                              <Input
                                id="permissibleLateArrival"
                                type="number"
                                min="0"
                                max="120"
                                {...form.register("permissibleLateArrival")}
                                placeholder="30"
                              />
                            ) : (
                              <div className="p-3 bg-gray-50 border rounded-md text-gray-700">
                                {form.watch("permissibleLateArrival") ? `${form.watch("permissibleLateArrival")} min` : "Not set"}
                              </div>
                            )}
                          </div>

                          <div>
                            <Label htmlFor="firstWeeklyOffDay" className="text-sm font-medium text-gray-700 mb-2 block">
                              Weekly Off Day
                            </Label>
                            {canEditTimeOfficePolicy ? (
                              <Select value={form.watch("firstWeeklyOffDay") || ''} onValueChange={(value) => form.setValue("firstWeeklyOffDay", value)}>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select day" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Sunday">Sunday</SelectItem>
                                  <SelectItem value="Monday">Monday</SelectItem>
                                  <SelectItem value="Tuesday">Tuesday</SelectItem>
                                  <SelectItem value="Wednesday">Wednesday</SelectItem>
                                  <SelectItem value="Thursday">Thursday</SelectItem>
                                  <SelectItem value="Friday">Friday</SelectItem>
                                  <SelectItem value="Saturday">Saturday</SelectItem>
                                </SelectContent>
                              </Select>
                            ) : (
                              <div className="p-3 bg-gray-50 border rounded-md text-gray-700">
                                {form.watch("firstWeeklyOffDay") || "Not set"}
                              </div>
                            )}
                          </div>

                          {canEditTimeOfficePolicy && (
                            <div className="flex items-center space-x-2">
                              <Checkbox
                                id="overtimeApplicable"
                                checked={!!form.watch("overtimeApplicable")}
                                onCheckedChange={(checked) => form.setValue("overtimeApplicable", checked)}
                              />
                              <Label htmlFor="overtimeApplicable" className="text-sm font-medium">
                                Overtime Applicable
                              </Label>
                            </div>
                          )}
                        </div>
                      </div>

                    </div>

                    {/* Save Button */}
                    <div className="flex gap-4 pt-6 border-t border-gray-200">
                      <Button 
                        type="submit" 
                        disabled={updateProfileMutation.isPending}
                        className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
                      >
                        {updateProfileMutation.isPending ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        ) : (
                          <Save className="mr-2 h-4 w-4" />
                        )}
                        Save Changes
                      </Button>
                      <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                        <X className="mr-2 h-4 w-4" />
                        Cancel
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-8">
                    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                      {/* Shift Assignment */}
                      <div className="space-y-6 border border-gray-200 bg-white p-4 rounded-lg shadow-sm">
                        <h4 className="font-semibold text-gray-700 border-b border-gray-200 pb-2 flex items-center gap-2">
                          <RotateCw className="h-4 w-4" />
                          Shift Assignment
                        </h4>
                        <div className="space-y-3">
                          <Label htmlFor="currentShift" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            Current Shift
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Select value={selectedShiftId || ''} onValueChange={setSelectedShiftId}>
                              <SelectTrigger className="h-12 border-2 focus:border-indigo-500">
                                <SelectValue placeholder="Select a shift" />
                              </SelectTrigger>
                              <SelectContent>
                                {availableShifts.map((shift: any) => (
                                  <SelectItem key={shift.id} value={shift.id.toString()}>
                                    <div className="flex items-center gap-2">
                                      <div 
                                        className="w-3 h-3 rounded-full" 
                                        style={{ backgroundColor: shift.colorCode || '#6366f1' }}
                                      />
                                      {shift.name} ({shift.startTime} - {shift.endTime})
                                    </div>
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {employeeShifts.length > 0 ? 
                                `${employeeShifts[0]?.shift?.name || 'Unknown Shift'}` : 
                                "No shift assigned"
                              }
                            </div>
                          )}
                        </div>

                        {canEditTimeOfficePolicy && selectedShiftId && (
                          <Button 
                            onClick={() => assignShiftMutation.mutate({ 
                              employeeId: profile?.id!, 
                              shiftId: parseInt(selectedShiftId) 
                            })}
                            className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700"
                            disabled={assignShiftMutation.isPending}
                          >
                            {assignShiftMutation.isPending ? (
                              <>
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                                Assigning...
                              </>
                            ) : (
                              <>
                                <RotateCw className="mr-2 h-4 w-4" />
                                Assign Shift
                              </>
                            )}
                          </Button>
                        )}

                        {employeeShifts.length > 0 && (
                          <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-lg">
                            <div className="text-sm font-medium text-indigo-800 mb-2">Shift Details</div>
                            <div className="space-y-1 text-xs text-indigo-600">
                              <div>Start: {employeeShifts[0]?.shift?.startTime}</div>
                              <div>End: {employeeShifts[0]?.shift?.endTime}</div>
                              <div>Break: {employeeShifts[0]?.shift?.breakDuration} min</div>
                            </div>
                          </div>
                        )}
                      </div>
                      {/* Duty Timing */}
                      <div className="space-y-6">
                        <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2 flex items-center gap-2">
                          Work Timing
                          {!canEditTimeOfficePolicy && (
                            <Badge variant="secondary" className="text-xs">
                              <Shield className="h-3 w-3 mr-1" />
                              Admin Only
                            </Badge>
                          )}
                        </h4>
                        <div className="space-y-3">
                          <Label htmlFor="dutyStartTime" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            Duty Start Time
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Input
                              id="dutyStartTime"
                              type="time"
                              {...form.register("dutyStartTime")}
                              className="h-12 border-2 focus:border-indigo-500"
                            />
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {form.watch("dutyStartTime") || "Not configured"}
                            </div>
                          )}
                        </div>

                        <div className="space-y-3">
                          <Label htmlFor="dutyEndTime" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            Duty End Time
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Input
                              id="dutyEndTime"
                              type="time"
                              {...form.register("dutyEndTime")}
                              className="h-12 border-2 focus:border-indigo-500"
                            />
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {form.watch("dutyEndTime") || "Not configured"}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Permissible Timing */}
                      <div className="space-y-6">
                        <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2 flex items-center gap-2">
                          Flexibility Rules
                          {!canEditTimeOfficePolicy && (
                            <Badge variant="secondary" className="text-xs">
                              <Shield className="h-3 w-3 mr-1" />
                              Admin Only
                            </Badge>
                          )}
                        </h4>
                        <div className="space-y-3">
                          <Label htmlFor="permissibleLateArrival" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            Permissible Late Arrival (minutes)
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Input
                              id="permissibleLateArrival"
                              type="number"
                              min="0"
                              max="120"
                              {...form.register("permissibleLateArrival")}
                              placeholder="30"
                              className="h-12 border-2 focus:border-indigo-500"
                            />
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {form.watch("permissibleLateArrival") ? `${form.watch("permissibleLateArrival")} minutes` : "Not configured"}
                            </div>
                          )}
                        </div>

                        <div className="space-y-3">
                          <Label htmlFor="permissibleEarlyDeparture" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            Permissible Early Departure (minutes)
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Input
                              id="permissibleEarlyDeparture"
                              type="number"
                              min="0"
                              max="120"
                              {...form.register("permissibleEarlyDeparture")}
                              placeholder="15"
                              className="h-12 border-2 focus:border-indigo-500"
                            />
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {form.watch("permissibleEarlyDeparture") ? `${form.watch("permissibleEarlyDeparture")} minutes` : "Not configured"}
                            </div>
                          )}
                        </div>

                        <div className="space-y-3">
                          <Label htmlFor="presentMarkingDuration" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            Present Marking Duration (hours)
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Input
                              id="presentMarkingDuration"
                              type="number"
                              min="1"
                              max="12"
                              step="0.5"
                              {...form.register("presentMarkingDuration")}
                              placeholder="4"
                              className="h-12 border-2 focus:border-indigo-500"
                            />
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {form.watch("presentMarkingDuration") ? `${form.watch("presentMarkingDuration")} hours` : "Not configured"}
                            </div>
                          )}
                          <p className="text-xs text-gray-500">Minimum hours for half-day marking</p>
                        </div>
                      </div>

                      {/* Weekly Offs & OT */}
                      <div className="space-y-6">
                        <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2 flex items-center gap-2">
                          Weekly Offs & Overtime
                          {!canEditTimeOfficePolicy && (
                            <Badge variant="secondary" className="text-xs">
                              <Shield className="h-3 w-3 mr-1" />
                              Admin Only
                            </Badge>
                          )}
                        </h4>
                        <div className="space-y-3">
                          <Label htmlFor="firstWeeklyOffDay" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            First Weekly Off Day
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Select value={form.watch("firstWeeklyOffDay")} onValueChange={(value) => form.setValue("firstWeeklyOffDay", value)}>
                              <SelectTrigger className="h-12 border-2 focus:border-indigo-500">
                                <SelectValue placeholder="Select day" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="sunday">Sunday</SelectItem>
                                <SelectItem value="monday">Monday</SelectItem>
                                <SelectItem value="tuesday">Tuesday</SelectItem>
                                <SelectItem value="wednesday">Wednesday</SelectItem>
                                <SelectItem value="thursday">Thursday</SelectItem>
                                <SelectItem value="friday">Friday</SelectItem>
                                <SelectItem value="saturday">Saturday</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {form.watch("firstWeeklyOffDay") ? 
                                form.watch("firstWeeklyOffDay")?.charAt(0).toUpperCase() + form.watch("firstWeeklyOffDay")?.slice(1) : 
                                "Not configured"
                              }
                            </div>
                          )}
                        </div>

                        <div className="space-y-3">
                          <Label htmlFor="secondWeeklyOffDay" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                            Second Weekly Off Day
                            {!canEditTimeOfficePolicy && (
                              <Badge variant="secondary" className="text-xs">
                                <Shield className="h-3 w-3 mr-1" />
                                Admin Only
                              </Badge>
                            )}
                          </Label>
                          {canEditTimeOfficePolicy ? (
                            <Select value={form.watch("secondWeeklyOffDay")} onValueChange={(value) => form.setValue("secondWeeklyOffDay", value)}>
                              <SelectTrigger className="h-12 border-2 focus:border-indigo-500">
                                <SelectValue placeholder="Select day (optional)" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="none">None</SelectItem>
                                <SelectItem value="sunday">Sunday</SelectItem>
                                <SelectItem value="monday">Monday</SelectItem>
                                <SelectItem value="tuesday">Tuesday</SelectItem>
                                <SelectItem value="wednesday">Wednesday</SelectItem>
                                <SelectItem value="thursday">Thursday</SelectItem>
                                <SelectItem value="friday">Friday</SelectItem>
                                <SelectItem value="saturday">Saturday</SelectItem>
                              </SelectContent>
                            </Select>
                          ) : (
                            <div className="h-12 border-2 border-gray-200 bg-gray-50 rounded-md flex items-center px-3 text-gray-500">
                              {form.watch("secondWeeklyOffDay") && form.watch("secondWeeklyOffDay") !== "none" ? 
                                form.watch("secondWeeklyOffDay")?.charAt(0).toUpperCase() + form.watch("secondWeeklyOffDay")?.slice(1) : 
                                "None"
                              }
                            </div>
                          )}
                        </div>

                        <div className="space-y-3">
                          <div className="flex items-center space-x-3">
                            {canEditTimeOfficePolicy ? (
                              <Checkbox
                                id="overtimeApplicable"
                                checked={form.watch("overtimeApplicable")}
                                onCheckedChange={(checked) => form.setValue("overtimeApplicable", checked as boolean)}
                                className="border-2 border-indigo-500"
                              />
                            ) : (
                              <div className="h-4 w-4 border-2 border-gray-300 bg-gray-50 rounded flex items-center justify-center">
                                {form.watch("overtimeApplicable") && <div className="h-2 w-2 bg-gray-400 rounded-sm" />}
                              </div>
                            )}
                            <Label htmlFor="overtimeApplicable" className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                              Overtime Applicable
                              {!canEditTimeOfficePolicy && (
                                <Badge variant="secondary" className="text-xs">
                                  <Shield className="h-3 w-3 mr-1" />
                                  Admin Only
                                </Badge>
                              )}
                            </Label>
                          </div>
                          <p className="text-xs text-gray-500 pl-7">
                            Enable overtime calculation for extra working hours
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Overall warning for employees */}
                    {!canEditTimeOfficePolicy && (
                      <div className="mt-6 p-4 bg-amber-50 border-l-4 border-l-amber-400 rounded-r-lg">
                        <div className="flex items-center">
                          <Shield className="h-5 w-5 text-amber-600 mr-2" />
                          <h5 className="font-semibold text-amber-800">Time Office Policy - Admin Only</h5>
                        </div>
                        <p className="text-sm text-amber-700 mt-2">
                          All Time Office Policy settings (work timing, flexibility rules, weekly offs, and overtime) can only be modified by administrators. 
                          Contact your admin to request changes to these settings.
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
