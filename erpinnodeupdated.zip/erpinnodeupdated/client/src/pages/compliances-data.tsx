import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FileSpreadsheet, Filter, Calendar, Plus, Download } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

export default function CompliancesData() {
  const { user } = useAuth();
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [selectedMonth, setSelectedMonth] = useState<string>('');
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: projects = [] } = useQuery({
    queryKey: ['/api/clients', user?.companyId],
    enabled: !!user?.companyId,
  });

  const { data: compliancesData = [] } = useQuery({
    queryKey: [`/api/compliances-data/${user?.companyId}/${selectedProject}/${selectedMonth}`],
    enabled: !!user?.companyId && !!selectedProject && !!selectedMonth,
  });

  // Generate sample data mutation
  const generateSampleDataMutation = useMutation({
    mutationFn: async () => {
      if (!selectedProject || !selectedMonth) return;
      
      // Get compliance setups for sample data generation
      const setupResponse = await apiRequest('GET', `/api/compliance-setups/${user?.companyId}`);
      const setups = await setupResponse.json();
      
      if (setups.length === 0) {
        throw new Error('No employee compliance setups found. Please set up employees first.');
      }

      // Generate compliance data for each setup
      const sampleData = setups.map((setup: any) => ({
        companyId: user?.companyId,
        projectId: parseInt(selectedProject),
        employeeId: setup.employeeId,
        month: selectedMonth,
        actualPayable: (Math.random() * 50000 + 30000).toFixed(2),
        compliancesGross: (Math.random() * 45000 + 28000).toFixed(2),
        compliancesAttendance: Math.floor(Math.random() * 8) + 20, // 20-27 days
        compliancesOT: Math.floor(Math.random() * 20), // 0-20 hours
        compliancesGrossEarn: (Math.random() * 48000 + 29000).toFixed(2),
        pfDeduction: (Math.random() * 3000 + 1500).toFixed(2),
        esicDeduction: (Math.random() * 1500 + 500).toFixed(2),
        netPayableAmount: (Math.random() * 42000 + 25000).toFixed(2),
        differenceAmount: ((Math.random() - 0.5) * 5000).toFixed(2),
      }));

      // Create all compliance data records
      for (const data of sampleData) {
        await apiRequest('POST', '/api/compliances-data', data);
      }
      
      return sampleData;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [`/api/compliances-data/${user?.companyId}/${selectedProject}/${selectedMonth}`] 
      });
      toast({
        title: "Success",
        description: "Sample compliance data generated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate sample data",
        variant: "destructive",
      });
    },
  });

  // Generate month options for current and previous months
  const getMonthOptions = () => {
    const months = [];
    const currentDate = new Date();
    
    for (let i = 0; i < 12; i++) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
      const monthYear = date.toISOString().slice(0, 7); // YYYY-MM format
      const monthName = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      months.push({ value: monthYear, label: monthName });
    }
    
    return months;
  };

  const monthOptions = getMonthOptions();

  const formatCurrency = (amount: number | string) => {
    return `₹${Number(amount).toLocaleString('en-IN')}`;
  };

  const handleExportToExcel = () => {
    const token = localStorage.getItem('token');
    const url = `/api/compliances/export/${user?.companyId}`;
    
    // Create a temporary link with auth header
    fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `compliances_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    })
    .catch(error => {
      toast({
        title: "Error",
        description: "Failed to export compliance data",
        variant: "destructive",
      });
    });
  };

  return (
    <div className="space-y-6 p-6">

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="w-5 h-5 mr-2 text-blue-600" />
            Filters
          </CardTitle>
          <CardDescription>
            Select project and month to view compliance data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Project Selection</label>
              <Select value={selectedProject} onValueChange={setSelectedProject}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a project" />
                </SelectTrigger>
                <SelectContent>
                  {projects.map((project: any) => (
                    <SelectItem key={project.id} value={project.id.toString()}>
                      {project.projectName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Month Selection</label>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger>
                  <SelectValue placeholder="Select month" />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map((month) => (
                    <SelectItem key={month.value} value={month.value}>
                      {month.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Compliances Data Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center">
                <FileSpreadsheet className="w-5 h-5 mr-2 text-green-600" />
                Employee Compliances Data
              </CardTitle>
              <CardDescription>
                Detailed compliance breakdown for selected project and month
              </CardDescription>
            </div>
            <Button 
              onClick={handleExportToExcel} 
              variant="outline"
              className="flex items-center gap-2"
            >
              <Download className="h-4 w-4" />
              Export to Excel
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {!selectedProject || !selectedMonth ? (
            <div className="text-center py-12 text-gray-500">
              <Calendar className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">Select Project and Month</p>
              <p>Please select both project and month to view compliance data.</p>
            </div>
          ) : compliancesData.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <FileSpreadsheet className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">No Data Found</p>
              <p className="mb-4">No compliance data available for the selected project and month.</p>
              <div className="space-y-2">
                <p className="text-sm text-blue-600 mb-3">
                  💡 <strong>Automatic Generation:</strong> Compliance data is automatically created when employees are assigned to projects
                </p>
                <Button 
                  onClick={() => generateSampleDataMutation.mutate()}
                  disabled={generateSampleDataMutation.isPending}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {generateSampleDataMutation.isPending ? "Generating..." : "Generate Sample Data"}
                </Button>
              </div>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">S.N.</TableHead>
                    <TableHead>Employee Name</TableHead>
                    <TableHead>Designation</TableHead>
                    <TableHead className="text-right">Actual Payable</TableHead>
                    <TableHead className="text-right">Compliances Gross</TableHead>
                    <TableHead className="text-center">Compliances Attendance</TableHead>
                    <TableHead className="text-right">Compliances OT</TableHead>
                    <TableHead className="text-right">Compliances Gross Ern</TableHead>
                    <TableHead className="text-right">PF Deduction</TableHead>
                    <TableHead className="text-right">ESIC Deduction</TableHead>
                    <TableHead className="text-right">Net Payable Amount</TableHead>
                    <TableHead className="text-right">Difference Amount</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {compliancesData.map((item: any, index: number) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{index + 1}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{item.employee?.firstName} {item.employee?.lastName}</p>
                          <p className="text-sm text-gray-500">{item.employee?.employeeId}</p>
                        </div>
                      </TableCell>
                      <TableCell>{item.employee?.designation || 'Not Set'}</TableCell>
                      <TableCell className="text-right font-medium">
                        {formatCurrency(item.actualPayable || 0)}
                      </TableCell>
                      <TableCell className="text-right">
                        {formatCurrency(item.compliancesGross || 0)}
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant={item.compliancesAttendance >= 22 ? 'default' : 'secondary'}>
                          {item.compliancesAttendance || 0} days
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {item.compliancesOT || 0} hrs
                      </TableCell>
                      <TableCell className="text-right">
                        {formatCurrency(item.compliancesGrossEarn || 0)}
                      </TableCell>
                      <TableCell className="text-right text-red-600">
                        -{formatCurrency(item.pfDeduction || 0)}
                      </TableCell>
                      <TableCell className="text-right text-red-600">
                        -{formatCurrency(item.esicDeduction || 0)}
                      </TableCell>
                      <TableCell className="text-right font-semibold text-green-600">
                        {formatCurrency(item.netPayableAmount || 0)}
                      </TableCell>
                      <TableCell className="text-right">
                        <Badge variant={Number(item.differenceAmount || 0) >= 0 ? 'default' : 'destructive'}>
                          {formatCurrency(item.differenceAmount || 0)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Summary Card */}
      {compliancesData.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600">Total Employees</p>
                <p className="text-2xl font-bold text-blue-600">{compliancesData.length}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600">Total Payable</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(
                    compliancesData.reduce((sum: number, item: any) => 
                      sum + Number(item.actualPayable || 0), 0
                    )
                  )}
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600">Total PF Deduction</p>
                <p className="text-2xl font-bold text-red-600">
                  {formatCurrency(
                    compliancesData.reduce((sum: number, item: any) => 
                      sum + Number(item.pfDeduction || 0), 0
                    )
                  )}
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="text-center">
                <p className="text-sm text-gray-600">Total ESIC Deduction</p>
                <p className="text-2xl font-bold text-red-600">
                  {formatCurrency(
                    compliancesData.reduce((sum: number, item: any) => 
                      sum + Number(item.esicDeduction || 0), 0
                    )
                  )}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}