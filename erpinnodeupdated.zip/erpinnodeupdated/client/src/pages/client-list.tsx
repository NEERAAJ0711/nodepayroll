import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Plus, MoreHorizontal, Edit, Users, Calendar, DollarSign } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth';
import { useLocation } from 'wouter';

const clientSchema = z.object({
  projectName: z.string().min(1, 'Project name is required'),
  projectCost: z.string().min(1, 'Project cost is required'),
  startDate: z.string().min(1, 'Start date is required'),
  principalEmployer: z.string().optional(),
  clientName: z.string().optional(),
  natureAndLocationOfWork: z.string().optional(),
});

type ClientFormData = z.infer<typeof clientSchema>;

export default function ClientList() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<any>(null);

  const { data: clients = [], isLoading } = useQuery<any[]>({
    queryKey: ['/api/clients', user?.companyId],
    enabled: !!user?.companyId,
  });

  const form = useForm<ClientFormData>({
    resolver: zodResolver(clientSchema),
    defaultValues: {
      projectName: '',
      projectCost: '',
      startDate: '',
      principalEmployer: '',
      clientName: '',
      natureAndLocationOfWork: '',
    },
  });

  const createClientMutation = useMutation({
    mutationFn: async (data: ClientFormData) => {
      const response = await apiRequest('POST', '/api/clients', {
        ...data,
        companyId: user?.companyId,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clients'] });
      setIsDialogOpen(false);
      form.reset();
      toast({
        title: 'Success',
        description: 'Client project created successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to create client project',
        variant: 'destructive',
      });
    },
  });

  const updateClientMutation = useMutation({
    mutationFn: async (data: ClientFormData & { id: number }) => {
      const response = await apiRequest('PUT', `/api/clients/${data.id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/clients'] });
      setIsDialogOpen(false);
      setEditingClient(null);
      form.reset();
      toast({
        title: 'Success',
        description: 'Client project updated successfully',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to update client project',
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: ClientFormData) => {
    if (editingClient) {
      updateClientMutation.mutate({ ...data, id: editingClient.id });
    } else {
      createClientMutation.mutate(data);
    }
  };

  const handleEdit = (client: any) => {
    setEditingClient(client);
    form.reset({
      projectName: client.projectName,
      projectCost: client.projectCost,
      startDate: client.startDate?.split('T')[0] || '',
      principalEmployer: client.principalEmployer || '',
      clientName: client.clientName || '',
      natureAndLocationOfWork: client.natureAndLocationOfWork || '',
    });
    setIsDialogOpen(true);
  };

  const handleAddNew = () => {
    setEditingClient(null);
    form.reset();
    setIsDialogOpen(true);
  };

  const handleManageEmployee = (client: any) => {
    // Navigate to manage employee page with client project context
    setLocation(`/admin/manage-employee?projectId=${client.id}&projectName=${encodeURIComponent(client.projectName)}`);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={handleAddNew}>
              <Plus className="w-4 h-4 mr-2" />
              Add Client Project
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingClient ? 'Edit Client Project' : 'Add New Client Project'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div>
                <Label htmlFor="projectName">Project Name</Label>
                <Input
                  id="projectName"
                  {...form.register('projectName')}
                  placeholder="Enter project name"
                />
                {form.formState.errors.projectName && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.projectName.message}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="projectCost">Project Cost</Label>
                <Input
                  id="projectCost"
                  {...form.register('projectCost')}
                  placeholder="Enter project cost"
                />
                {form.formState.errors.projectCost && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.projectCost.message}
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="startDate">Start Date</Label>
                <Input
                  id="startDate"
                  type="date"
                  {...form.register('startDate')}
                />
                {form.formState.errors.startDate && (
                  <p className="text-red-500 text-sm mt-1">
                    {form.formState.errors.startDate.message}
                  </p>
                )}
              </div>
              
              <div>
                <Label htmlFor="principalEmployer">Principal Employer</Label>
                <Input
                  id="principalEmployer"
                  {...form.register('principalEmployer')}
                  placeholder="Enter principal employer"
                />
              </div>
              
              <div>
                <Label htmlFor="clientName">Client Name</Label>
                <Input
                  id="clientName"
                  {...form.register('clientName')}
                  placeholder="Enter client name"
                />
              </div>
              
              <div>
                <Label htmlFor="natureAndLocationOfWork">Nature & Location of Work</Label>
                <Input
                  id="natureAndLocationOfWork"
                  {...form.register('natureAndLocationOfWork')}
                  placeholder="Enter nature and location of work"
                />
              </div>
              
              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createClientMutation.isPending || updateClientMutation.isPending}
                >
                  {createClientMutation.isPending || updateClientMutation.isPending
                    ? 'Saving...'
                    : editingClient
                    ? 'Update'
                    : 'Create'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <DollarSign className="w-5 h-5 mr-2 text-blue-600" />
            Client Projects Overview
          </CardTitle>
          <CardDescription>
            Manage and track all your client projects in one place
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Project Name</TableHead>
                <TableHead>Project Cost</TableHead>
                <TableHead>Start Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {clients.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-8 text-gray-500">
                    No client projects found. Create your first project to get started.
                  </TableCell>
                </TableRow>
              ) : (
                clients.map((client: any) => (
                  <TableRow key={client.id}>
                    <TableCell className="font-medium">{client.projectName}</TableCell>
                    <TableCell>₹{client.projectCost}</TableCell>
                    <TableCell>
                      {client.startDate
                        ? new Date(client.startDate).toLocaleDateString()
                        : 'Not set'}
                    </TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEdit(client)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleManageEmployee(client)}>
                            <Users className="w-4 h-4 mr-2" />
                            Manage Employee
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}