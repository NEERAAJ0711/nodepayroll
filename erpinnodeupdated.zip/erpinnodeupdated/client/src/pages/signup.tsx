import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Building2, User, ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { authService } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const adminSignupSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  aadhaarNumber: z.string().optional().refine((val) => {
    if (!val || val.trim() === '') return true;
    const clean = val.replace(/\s/g, '');
    return /^\d{12}$/.test(clean);
  }, "Please enter a valid 12-digit Aadhaar number or leave empty"),
});

const employeeSignupSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  aadhaarNumber: z.string().refine((val) => {
    const clean = val.replace(/\s/g, '');
    return /^\d{12}$/.test(clean);
  }, "Please enter a valid 12-digit Aadhaar number"),
});

type AdminSignupData = z.infer<typeof adminSignupSchema>;
type EmployeeSignupData = z.infer<typeof employeeSignupSchema>;

export default function SignupPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("admin");

  // No need to fetch companies or departments for employee signup

  const adminForm = useForm<AdminSignupData>({
    resolver: zodResolver(adminSignupSchema),
  });

  const employeeForm = useForm<EmployeeSignupData>({
    resolver: zodResolver(employeeSignupSchema),
  });

  const adminSignupMutation = useMutation({
    mutationFn: async (data: AdminSignupData) => {
      // Create admin user with optional Aadhaar data
      const payload: any = {
        name: data.name,
        email: data.email,
        password: data.password,
      };
      
      // Only include Aadhaar if provided
      if (data.aadhaarNumber && data.aadhaarNumber.trim() !== '') {
        payload.aadhaarNumber = data.aadhaarNumber.replace(/\s/g, '');
      }
      
      const userResponse = await apiRequest('POST', '/api/users/admin-signup', payload);
      
      // Check if signup was successful
      if (!userResponse.ok) {
        const errorData = await userResponse.json().catch(() => ({ message: 'Signup failed' }));
        throw new Error(errorData.message || 'Signup failed');
      }
      
      return userResponse.json();
    },
    onSuccess: async (data) => {
      try {
        toast({ title: "Account created successfully! Redirecting to company setup..." });
        
        // Auto-login the user after signup
        const loginResponse = await authService.login({
          email: adminForm.getValues('email'),
          password: adminForm.getValues('password'),
        });
        
        // Verify login was successful
        if (!loginResponse) {
          throw new Error('Login failed after signup');
        }
        
        // Clear password from form for security
        adminForm.setValue('password', '');
        
        // Redirect to company profile setup
        setLocation('/company-profile-setup');
      } catch (loginError: any) {
        toast({
          title: "Login failed",
          description: loginError.message || "Please try logging in manually",
          variant: "destructive"
        });
        setLocation('/login');
      }
    },
    onError: (error: any) => {
      toast({ 
        title: "Signup failed", 
        description: error.message || "Please try again",
        variant: "destructive" 
      });
    },
  });

  const employeeSignupMutation = useMutation({
    mutationFn: async (data: EmployeeSignupData) => {
      // Create employee user with Aadhaar data
      const userResponse = await apiRequest('POST', '/api/users/employee-signup', {
        name: data.name,
        email: data.email,
        password: data.password,
        aadhaarNumber: data.aadhaarNumber.replace(/\s/g, ''),
      });
      
      if (!userResponse.ok) {
        const errorData = await userResponse.json().catch(() => ({ message: 'Unknown error' }));
        throw new Error(errorData.message || 'Signup failed');
      }
      
      return await userResponse.json();
    },
    onSuccess: () => {
      toast({ title: "Employee account created successfully! You can now browse and apply for jobs." });
      setLocation('/login');
    },
    onError: (error: any) => {
      console.error('Frontend: Signup mutation error:', error);
      toast({ 
        title: "Signup failed", 
        description: error.message || "Please try again",
        variant: "destructive" 
      });
    },
  });

  const onAdminSubmit = (data: AdminSignupData) => {
    adminSignupMutation.mutate(data);
  };

  const onEmployeeSubmit = (data: EmployeeSignupData) => {
    employeeSignupMutation.mutate(data);
  };

  const isLoading = adminSignupMutation.isPending || employeeSignupMutation.isPending;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-hr-background to-hr-background/80 p-4">
      <Card className="w-full max-w-2xl shadow-2xl border-0">
        <CardHeader className="text-center space-y-2 pb-6">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-hr-primary/10 p-3 rounded-full">
              <Building2 className="h-8 w-8 text-hr-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-hr-text-primary">
            Create Your Account
          </CardTitle>
          <CardDescription className="text-hr-text-secondary">
            Join our HR management platform
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="admin" className="flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Admin (Company Owner)
              </TabsTrigger>
              <TabsTrigger value="employee" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                Employee
              </TabsTrigger>
            </TabsList>

            <TabsContent value="admin" className="space-y-4 mt-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <h4 className="font-medium text-blue-900 mb-2">Admin Registration</h4>
                <p className="text-sm text-blue-700">
                  As an admin, you'll create a new company and become its administrator. 
                  You'll be able to manage employees, departments, and company settings.
                </p>
              </div>

              <form onSubmit={adminForm.handleSubmit(onAdminSubmit)} className="space-y-4">
                <div>
                  <Label htmlFor="admin-name">Full Name</Label>
                  <Input
                    id="admin-name"
                    {...adminForm.register("name")}
                    disabled={isLoading}
                    placeholder="Enter your full name"
                  />
                  {adminForm.formState.errors.name && (
                    <p className="text-sm text-red-600">{adminForm.formState.errors.name.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="admin-email">Email</Label>
                  <Input
                    id="admin-email"
                    type="email"
                    {...adminForm.register("email")}
                    disabled={isLoading}
                    placeholder="Enter your email address"
                  />
                  {adminForm.formState.errors.email && (
                    <p className="text-sm text-red-600">{adminForm.formState.errors.email.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="admin-aadhaar">Aadhaar Number (Optional)</Label>
                  <Input
                    id="admin-aadhaar"
                    {...adminForm.register("aadhaarNumber")}
                    disabled={isLoading}
                    placeholder="1234 5678 9012 (Optional)"
                    maxLength={14}
                    onChange={(e) => {
                      const formatted = e.target.value.replace(/\D/g, '').replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
                      e.target.value = formatted.slice(0, 14);
                      adminForm.setValue('aadhaarNumber', formatted);
                    }}
                    className="font-mono tracking-wider"
                  />
                  {adminForm.formState.errors.aadhaarNumber && (
                    <p className="text-sm text-red-600">{adminForm.formState.errors.aadhaarNumber.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="admin-password">Password</Label>
                  <Input
                    id="admin-password"
                    type="password"
                    {...adminForm.register("password")}
                    disabled={isLoading}
                    placeholder="Create a secure password"
                  />
                  {adminForm.formState.errors.password && (
                    <p className="text-sm text-red-600">{adminForm.formState.errors.password.message}</p>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full bg-hr-primary hover:bg-hr-primary/90"
                  disabled={isLoading}
                >
                  {isLoading ? "Creating Account..." : "Create Admin Account"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="employee" className="space-y-4 mt-6">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <h4 className="font-medium text-green-900 mb-2">Employee Registration</h4>
                <p className="text-sm text-green-700">
                  Create your employee account to browse and apply for jobs across different companies. 
                  You can update your profile later and request permissions from company admins.
                </p>
              </div>

              <form onSubmit={employeeForm.handleSubmit(onEmployeeSubmit)} className="space-y-4">
                <div>
                  <Label htmlFor="emp-name">Full Name</Label>
                  <Input
                    id="emp-name"
                    {...employeeForm.register("name")}
                    disabled={isLoading}
                    placeholder="Enter your full name"
                  />
                  {employeeForm.formState.errors.name && (
                    <p className="text-sm text-red-600">{employeeForm.formState.errors.name.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="emp-email">Email</Label>
                  <Input
                    id="emp-email"
                    type="email"
                    {...employeeForm.register("email")}
                    disabled={isLoading}
                    placeholder="Enter your email address"
                  />
                  {employeeForm.formState.errors.email && (
                    <p className="text-sm text-red-600">{employeeForm.formState.errors.email.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="emp-aadhaar">Aadhaar Number *</Label>
                  <Input
                    id="emp-aadhaar"
                    {...employeeForm.register("aadhaarNumber")}
                    disabled={isLoading}
                    placeholder="1234 5678 9012"
                    maxLength={14}
                    onChange={(e) => {
                      const formatted = e.target.value.replace(/\D/g, '').replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
                      e.target.value = formatted.slice(0, 14);
                      employeeForm.setValue('aadhaarNumber', formatted);
                    }}
                    className="font-mono tracking-wider"
                  />
                  {employeeForm.formState.errors.aadhaarNumber && (
                    <p className="text-sm text-red-600">{employeeForm.formState.errors.aadhaarNumber.message}</p>
                  )}
                </div>

                <div>
                  <Label htmlFor="emp-password">Password</Label>
                  <Input
                    id="emp-password"
                    type="password"
                    {...employeeForm.register("password")}
                    disabled={isLoading}
                    placeholder="Create a secure password"
                  />
                  {employeeForm.formState.errors.password && (
                    <p className="text-sm text-red-600">{employeeForm.formState.errors.password.message}</p>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full bg-hr-success hover:bg-hr-success/90"
                  disabled={isLoading}
                >
                  {isLoading ? "Creating Account..." : "Create Employee Account"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className="mt-6 text-center">
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Link href="/login" className="flex items-center gap-1 text-hr-primary hover:underline">
                <ArrowLeft className="h-3 w-3" />
                Back to Login
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}