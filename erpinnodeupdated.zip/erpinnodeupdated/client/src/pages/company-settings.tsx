import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth, usePermission } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { 
  Building2, 
  Users, 
  MapPin, 
  Clock, 
  DollarSign, 
  Fingerprint, 
  Calendar, 
  FileText,
  Plus,
  Edit,
  Trash2,
  MoreVertical,
  Upload,
  Download,
  AlertCircle,
  Loader2,
  Link2
} from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

interface Department {
  id: number;
  name: string;
  description: string;
  headOfDepartment: string;
  createdAt: Date;
}

interface Designation {
  id: number;
  title: string;
  departmentId: number;
  level: string;
  description: string;
}

interface Branch {
  id: number;
  name: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  manager: string;
}

interface Location {
  id: number;
  name: string;
  address: string;
  branchId: number;
  capacity: number;
}

interface CostCenter {
  id: number;
  code: string;
  name: string;
  description: string;
  budget: string;
  manager: string;
}

interface BiometricMachine {
  id: number;
  serialNumber: string;
  ipAddress: string;
  port: number;
  location: string;
  model: string;
  status: 'active' | 'inactive' | 'maintenance';
  lastSync: Date;
}

interface Holiday {
  id: number;
  name: string;
  date: Date;
  type: 'national' | 'regional' | 'company';
  description: string;
  mandatory: boolean;
}

interface Shift {
  id: number;
  name: string;
  description?: string;
  startTime: string;
  endTime: string;
  breakDuration: number;
  totalHours: string;
  isActive: boolean;
  colorCode?: string;
  companyId: number;
}

interface LeavePolicy {
  id: number;
  name: string;
  type: 'annual' | 'sick' | 'maternity' | 'paternity' | 'personal' | 'emergency';
  allowedDays: number;
  carryForward: boolean;
  description: string;
}

export default function CompanySettings() {
  const { toast } = useToast();
  const user = authService.getUser();
  const companyId = user?.companyId;
  
  // State for active tab and dialogs
  const [activeTab, setActiveTab] = useState("departments");
  const [showDialog, setShowDialog] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [selectedItem, setSelectedItem] = useState<any>(null);

  // Form states
  const [formData, setFormData] = useState<any>({});
  
  // Machine Import States
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<BiometricMachine | null>(null);
  const [importFile, setImportFile] = useState<File | null>(null);
  const [importData, setImportData] = useState<any[]>([]);
  const [importProgress, setImportProgress] = useState<{
    isImporting: boolean;
    progress: number;
    results?: any;
    errors?: string[];
  }>({ isImporting: false, progress: 0 });

  // Connection Test States
  const [testingConnection, setTestingConnection] = useState<Record<number, boolean>>({});
  const [connectionResults, setConnectionResults] = useState<Record<number, any>>({});

  // Permission check for company settings access
  const { hasPermission: canAccessSettings, loading: permissionLoading } = usePermission('company_settings');

  // Fetch company data
  const { data: company } = useQuery({
    queryKey: [`/api/companies/${companyId}`],
    enabled: !!companyId,
  });

  // Fetch departments
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: [`/api/departments/${companyId}`],
    enabled: !!companyId,
  });

  // Fetch all company settings data
  const { data: designations = [] } = useQuery<Designation[]>({
    queryKey: [`/api/designations/${companyId}`],
    enabled: !!companyId,
  });

  const { data: branches = [] } = useQuery<Branch[]>({
    queryKey: [`/api/branches/${companyId}`],
    enabled: !!companyId,
  });

  const { data: locations = [] } = useQuery<Location[]>({
    queryKey: [`/api/locations/${companyId}`],
    enabled: !!companyId,
  });

  const { data: costCenters = [] } = useQuery<CostCenter[]>({
    queryKey: [`/api/cost-centers/${companyId}`],
    enabled: !!companyId,
  });

  const { data: biometricMachines = [] } = useQuery<BiometricMachine[]>({
    queryKey: [`/api/biometric-machines/${companyId}`],
    enabled: !!companyId,
  });

  const { data: holidays = [] } = useQuery<Holiday[]>({
    queryKey: [`/api/holidays/${companyId}`],
    enabled: !!companyId,
  });

  const { data: shifts = [] } = useQuery<Shift[]>({
    queryKey: [`/api/shifts/${companyId}`],
    enabled: !!companyId,
  });

  const { data: leavePolicies = [] } = useQuery<LeavePolicy[]>({
    queryKey: [`/api/leave-policies/${companyId}`],
    enabled: !!companyId,
  });

  // Department mutation
  const departmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const method = selectedItem ? 'PUT' : 'POST';
      const url = selectedItem ? `/api/departments/${selectedItem.id}` : '/api/departments';
      const response = await apiRequestWithAuth(method, url, { ...data, companyId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/departments/${companyId}`] });
      setShowDialog(false);
      setFormData({});
      toast({
        title: "Success",
        description: `Department ${selectedItem ? 'updated' : 'created'} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save department",
        variant: "destructive",
      });
    },
  });

  // Designation mutation
  const designationMutation = useMutation({
    mutationFn: async (data: any) => {
      const method = selectedItem ? 'PUT' : 'POST';
      const url = selectedItem ? `/api/designations/${selectedItem.id}` : '/api/designations';
      const response = await apiRequestWithAuth(method, url, { ...data, companyId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/designations/${companyId}`] });
      setShowDialog(false);
      setFormData({});
      toast({
        title: "Success",
        description: `Designation ${selectedItem ? 'updated' : 'created'} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save designation",
        variant: "destructive",
      });
    },
  });

  // Biometric Machine mutation
  const biometricMachineMutation = useMutation({
    mutationFn: async (data: any) => {
      const method = selectedItem ? 'PUT' : 'POST';
      const url = selectedItem ? `/api/biometric-machines/${selectedItem.id}` : '/api/biometric-machines';
      const response = await apiRequestWithAuth(method, url, { ...data, companyId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/biometric-machines/${companyId}`] });
      setShowDialog(false);
      setFormData({});
      toast({
        title: "Success",
        description: `Biometric Machine ${selectedItem ? 'updated' : 'created'} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save biometric machine",
        variant: "destructive",
      });
    },
  });

  // Shifts mutation
  const shiftMutation = useMutation({
    mutationFn: async (data: any) => {
      const method = selectedItem ? 'PUT' : 'POST';
      const url = selectedItem ? `/api/shifts/${selectedItem.id}` : '/api/shifts';
      const response = await apiRequestWithAuth(method, url, { ...data, companyId });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/shifts/${companyId}`] });
      setShowDialog(false);
      setFormData({});
      toast({
        title: "Success",
        description: `Shift ${selectedItem ? 'updated' : 'created'} successfully`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save shift",
        variant: "destructive",
      });
    },
  });

  // Machine Import Mutation
  const machineImportMutation = useMutation({
    mutationFn: async ({ machineId, data }: { machineId: number; data: any[] }) => {
      const response = await apiRequestWithAuth('POST', `/api/biometric-machines/${machineId}/import`, {
        data,
        startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days ago
        endDate: new Date().toISOString().split('T')[0] // today
      });
      return response.json();
    },
    onSuccess: (result) => {
      setImportProgress(prev => ({ ...prev, isImporting: false, results: result }));
      queryClient.invalidateQueries({ queryKey: [`/api/biometric-machines/${companyId}`] });
      toast({
        title: "Import Completed",
        description: `Imported ${result.summary.imported} records, updated ${result.summary.updated} records`,
      });
    },
    onError: (error: any) => {
      setImportProgress(prev => ({ ...prev, isImporting: false, errors: [error.message] }));
      toast({
        title: "Import Failed",
        description: error.message || "Failed to import machine data",
        variant: "destructive",
      });
    },
  });

  // Test Connection Mutation
  const testConnectionMutation = useMutation({
    mutationFn: async (machineId: number) => {
      const response = await apiRequestWithAuth('POST', `/api/biometric-machines/${machineId}/test-connection`, { companyId });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to test connection');
      }
      return response.json();
    },
    onSuccess: (data, machineId) => {
      setTestingConnection(prev => ({ ...prev, [machineId]: false }));
      setConnectionResults(prev => ({ ...prev, [machineId]: data }));
      toast({
        title: "Connection Successful",
        description: data.message || `Device reachable (${data.latency})`,
      });
    },
    onError: (error: any, machineId) => {
      setTestingConnection(prev => ({ ...prev, [machineId]: false }));
      setConnectionResults(prev => ({ ...prev, [machineId]: { success: false, message: error.message } }));
      toast({
        title: "Connection Failed",
        description: error.message || "Unable to reach device",
        variant: "destructive",
      });
    },
  });

  // Test connection handler
  const handleTestConnection = (machine: BiometricMachine) => {
    setTestingConnection(prev => ({ ...prev, [machine.id]: true }));
    setConnectionResults(prev => ({ ...prev, [machine.id]: undefined }));
    testConnectionMutation.mutate(machine.id);
  };

  // Permission checks after all hooks
  if (permissionLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking permissions...</p>
        </div>
      </div>
    );
  }
  
  if (!canAccessSettings) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Building2 className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-red-600 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">You don't have permission to access company settings.</p>
          <p className="text-sm text-gray-500">Request 'company_settings' permission from your administrator.</p>
        </div>
      </div>
    );
  }

  const handleOpenDialog = (type: string, item?: any) => {
    setDialogType(type);
    setSelectedItem(item);
    setFormData(item || {});
    setShowDialog(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    switch (dialogType) {
      case 'department':
        departmentMutation.mutate(formData);
        break;
      case 'designation':
        designationMutation.mutate(formData);
        break;
      case 'biometricMachine':
        biometricMachineMutation.mutate(formData);
        break;
      case 'shifts':
        shiftMutation.mutate(formData);
        break;
      // Add other cases as needed
      default:
        toast({
          title: "Success",
          description: `${dialogType} ${selectedItem ? 'updated' : 'created'} successfully`,
        });
        setShowDialog(false);
    }
  };

  // Handle file upload and parsing
  const handleFileUpload = async (file: File) => {
    setImportFile(file);
    setImportData([]);
    
    try {
      const text = await file.text();
      let parsedData: any[] = [];

      if (file.name.endsWith('.json')) {
        parsedData = JSON.parse(text);
      } else if (file.name.endsWith('.csv')) {
        // Parse CSV data
        const lines = text.split('\n');
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        
        parsedData = lines.slice(1)
          .filter(line => line.trim())
          .map(line => {
            const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
            const obj: any = {};
            headers.forEach((header, index) => {
              obj[header] = values[index] || '';
            });
            return obj;
          });
      }

      if (!Array.isArray(parsedData)) {
        throw new Error('Data must be an array of records');
      }

      setImportData(parsedData);
      toast({
        title: "File Loaded",
        description: `Loaded ${parsedData.length} records from ${file.name}`,
      });
    } catch (error: any) {
      toast({
        title: "File Parse Error",
        description: error.message || "Failed to parse file",
        variant: "destructive",
      });
    }
  };

  // Start import process
  const startImport = () => {
    if (!selectedMachine || !importData.length) return;
    
    setImportProgress({ isImporting: true, progress: 0 });
    machineImportMutation.mutate({ 
      machineId: selectedMachine.id, 
      data: importData 
    });
  };

  // Open import dialog for specific machine
  const openImportDialog = (machine: BiometricMachine) => {
    setSelectedMachine(machine);
    setImportFile(null);
    setImportData([]);
    setImportProgress({ isImporting: false, progress: 0 });
    setShowImportDialog(true);
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleDateString();
  };

  const renderDepartments = () => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Departments</CardTitle>
          <CardDescription>Manage organizational departments</CardDescription>
        </div>
        <Button onClick={() => handleOpenDialog('department')} className="bg-hr-primary hover:bg-hr-primary/90">
          <Plus className="mr-2 h-4 w-4" />
          Add Department
        </Button>
      </CardHeader>
      <CardContent>
        {departments.length === 0 ? (
          <div className="text-center py-8">
            <Building2 className="mx-auto h-12 w-12 text-gray-400" />
            <p className="mt-4 text-gray-600">No departments found</p>
            <Button onClick={() => handleOpenDialog('department')} className="mt-4">
              Create First Department
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Department Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Head of Department</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {departments.map((dept) => (
                <TableRow key={dept.id}>
                  <TableCell className="font-medium">{dept.name}</TableCell>
                  <TableCell>{dept.description}</TableCell>
                  <TableCell>{dept.headOfDepartment}</TableCell>
                  <TableCell>{formatDate(dept.createdAt)}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenDialog('department', dept)}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  const renderGenericTable = (
    title: string, 
    description: string, 
    data: any[], 
    columns: { key: string, label: string, render?: (value: any, item: any) => React.ReactNode }[],
    type: string,
    icon: React.ReactNode
  ) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            {icon}
            {title}
          </CardTitle>
          <CardDescription>{description}</CardDescription>
        </div>
        <Button onClick={() => handleOpenDialog(type)} className="bg-hr-primary hover:bg-hr-primary/90">
          <Plus className="mr-2 h-4 w-4" />
          Add {title.slice(0, -1)}
        </Button>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <div className="text-center py-8">
            <div className="mx-auto h-12 w-12 text-gray-400 mb-4">{icon}</div>
            <p className="text-gray-600">No {title.toLowerCase()} found</p>
            <Button onClick={() => handleOpenDialog(type)} className="mt-4">
              Create First {title.slice(0, -1)}
            </Button>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                {columns.map((col) => (
                  <TableHead key={col.key}>{col.label}</TableHead>
                ))}
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((item) => (
                <TableRow key={item.id}>
                  {columns.map((col) => (
                    <TableCell key={col.key}>
                      {col.render ? col.render(item[col.key], item) : item[col.key]}
                    </TableCell>
                  ))}
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenDialog(type, item)}>
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-red-600">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );

  const renderFormFields = () => {
    switch (dialogType) {
      case 'department':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Department Name</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Enter department name"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Enter department description"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="headOfDepartment">Head of Department</Label>
              <Input
                id="headOfDepartment"
                value={formData.headOfDepartment || ''}
                onChange={(e) => setFormData({...formData, headOfDepartment: e.target.value})}
                placeholder="Enter head of department"
              />
            </div>
          </>
        );
      
      case 'designation':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="title">Job Title</Label>
              <Input
                id="title"
                value={formData.title || ''}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                placeholder="Enter job title"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="departmentId">Department</Label>
              <Select value={formData.departmentId?.toString()} onValueChange={(value) => setFormData({...formData, departmentId: parseInt(value)})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept.id} value={dept.id.toString()}>{dept.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="level">Level</Label>
              <Select value={formData.level} onValueChange={(value) => setFormData({...formData, level: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Junior">Junior</SelectItem>
                  <SelectItem value="Mid">Mid</SelectItem>
                  <SelectItem value="Senior">Senior</SelectItem>
                  <SelectItem value="Lead">Lead</SelectItem>
                  <SelectItem value="Manager">Manager</SelectItem>
                  <SelectItem value="Director">Director</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Enter job description"
              />
            </div>
          </>
        );

      case 'branch':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Branch Name</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Enter branch name"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manager">Manager</Label>
                <Input
                  id="manager"
                  value={formData.manager || ''}
                  onChange={(e) => setFormData({...formData, manager: e.target.value})}
                  placeholder="Enter manager name"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={formData.address || ''}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Enter full address"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input
                  id="city"
                  value={formData.city || ''}
                  onChange={(e) => setFormData({...formData, city: e.target.value})}
                  placeholder="City"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state">State</Label>
                <Input
                  id="state"
                  value={formData.state || ''}
                  onChange={(e) => setFormData({...formData, state: e.target.value})}
                  placeholder="State"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="zipCode">ZIP Code</Label>
                <Input
                  id="zipCode"
                  value={formData.zipCode || ''}
                  onChange={(e) => setFormData({...formData, zipCode: e.target.value})}
                  placeholder="ZIP"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                value={formData.phone || ''}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                placeholder="Enter phone number"
              />
            </div>
          </>
        );

      case 'biometricMachine':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="serialNumber">Serial Number</Label>
                <Input
                  id="serialNumber"
                  value={formData.serialNumber || ''}
                  onChange={(e) => setFormData({...formData, serialNumber: e.target.value})}
                  placeholder="Enter serial number"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="model">Model</Label>
                <Input
                  id="model"
                  value={formData.model || ''}
                  onChange={(e) => setFormData({...formData, model: e.target.value})}
                  placeholder="Enter model name"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ipAddress">IP Address</Label>
                <Input
                  id="ipAddress"
                  value={formData.ipAddress || ''}
                  onChange={(e) => setFormData({...formData, ipAddress: e.target.value})}
                  placeholder="192.168.1.100"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="port">Port</Label>
                <Input
                  id="port"
                  type="number"
                  value={formData.port || ''}
                  onChange={(e) => setFormData({...formData, port: parseInt(e.target.value) || ''})}
                  placeholder="4370"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={formData.location || ''}
                onChange={(e) => setFormData({...formData, location: e.target.value})}
                placeholder="Main Entrance, Floor 2, etc."
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        );

      case 'holiday':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Holiday Name</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="New Year's Day, Christmas, etc."
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                value={formData.date || ''}
                onChange={(e) => setFormData({...formData, date: e.target.value})}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="national">National Holiday</SelectItem>
                  <SelectItem value="regional">Regional Holiday</SelectItem>
                  <SelectItem value="company">Company Holiday</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Optional description"
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="mandatory"
                checked={formData.mandatory || false}
                onChange={(e) => setFormData({...formData, mandatory: e.target.checked})}
              />
              <Label htmlFor="mandatory">Mandatory Holiday</Label>
            </div>
          </>
        );

      case 'leavePolicy':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Policy Name</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Annual Leave, Sick Leave, etc."
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Leave Type</Label>
              <Select value={formData.type} onValueChange={(value) => setFormData({...formData, type: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select leave type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="annual">Annual Leave</SelectItem>
                  <SelectItem value="sick">Sick Leave</SelectItem>
                  <SelectItem value="maternity">Maternity Leave</SelectItem>
                  <SelectItem value="paternity">Paternity Leave</SelectItem>
                  <SelectItem value="personal">Personal Leave</SelectItem>
                  <SelectItem value="emergency">Emergency Leave</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="allowedDays">Allowed Days per Year</Label>
              <Input
                id="allowedDays"
                type="number"
                value={formData.allowedDays || ''}
                onChange={(e) => setFormData({...formData, allowedDays: parseInt(e.target.value) || ''})}
                placeholder="21"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Policy description and rules"
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="carryForward"
                checked={formData.carryForward || false}
                onChange={(e) => setFormData({...formData, carryForward: e.target.checked})}
              />
              <Label htmlFor="carryForward">Allow Carry Forward to Next Year</Label>
            </div>
          </>
        );

      case 'location':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Location Name</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Conference Room A, Parking Lot, etc."
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="branchId">Branch</Label>
                <Select value={formData.branchId?.toString()} onValueChange={(value) => setFormData({...formData, branchId: parseInt(value)})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select branch" />
                  </SelectTrigger>
                  <SelectContent>
                    {branches.map((branch) => (
                      <SelectItem key={branch.id} value={branch.id.toString()}>{branch.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input
                id="address"
                value={formData.address || ''}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                placeholder="Detailed address of the location"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="capacity">Capacity</Label>
              <Input
                id="capacity"
                type="number"
                value={formData.capacity || ''}
                onChange={(e) => setFormData({...formData, capacity: parseInt(e.target.value) || ''})}
                placeholder="50"
              />
            </div>
          </>
        );

      case 'costCenter':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="code">Cost Center Code</Label>
                <Input
                  id="code"
                  value={formData.code || ''}
                  onChange={(e) => setFormData({...formData, code: e.target.value})}
                  placeholder="CC001, IT-001, etc."
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="IT Department, Marketing, etc."
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="budget">Budget</Label>
                <Input
                  id="budget"
                  value={formData.budget || ''}
                  onChange={(e) => setFormData({...formData, budget: e.target.value})}
                  placeholder="$50,000"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="manager">Manager</Label>
                <Input
                  id="manager"
                  value={formData.manager || ''}
                  onChange={(e) => setFormData({...formData, manager: e.target.value})}
                  placeholder="John Doe"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Purpose and scope of this cost center"
              />
            </div>
          </>
        );

      case 'shifts':
        return (
          <>
            <div className="space-y-2">
              <Label htmlFor="name">Shift Name</Label>
              <Input
                id="name"
                value={formData.name || ''}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="e.g., Morning Shift, Night Shift"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Brief description of this shift"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startTime">Start Time</Label>
                <Input
                  id="startTime"
                  type="time"
                  value={formData.startTime || ''}
                  onChange={(e) => setFormData({...formData, startTime: e.target.value})}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="endTime">End Time</Label>
                <Input
                  id="endTime"
                  type="time"
                  value={formData.endTime || ''}
                  onChange={(e) => setFormData({...formData, endTime: e.target.value})}
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="breakDuration">Break Duration (minutes)</Label>
                <Input
                  id="breakDuration"
                  type="number"
                  value={formData.breakDuration || ''}
                  onChange={(e) => setFormData({...formData, breakDuration: parseInt(e.target.value) || 0})}
                  placeholder="30"
                  min="0"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="colorCode">Color Code</Label>
                <Input
                  id="colorCode"
                  type="color"
                  value={formData.colorCode || '#3B82F6'}
                  onChange={(e) => setFormData({...formData, colorCode: e.target.value})}
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="isActive"
                checked={formData.isActive !== false}
                onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
                className="rounded border-gray-300"
              />
              <Label htmlFor="isActive">Active Shift</Label>
            </div>
          </>
        );

      default:
        return (
          <div className="space-y-4">
            <p className="text-gray-600">Form fields for {dialogType} will be implemented based on requirements.</p>
          </div>
        );
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Company Settings</h1>
          <p className="text-muted-foreground">Manage organizational structure and configuration</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="designations">Designations</TabsTrigger>
          <TabsTrigger value="locations">Locations</TabsTrigger>
          <TabsTrigger value="shifts">Shifts</TabsTrigger>
          <TabsTrigger value="systems">Systems</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="departments">
            {renderDepartments()}
          </TabsContent>

          <TabsContent value="designations">
            <div className="space-y-6">
              {renderGenericTable(
                "Designations",
                "Manage job titles and positions",
                designations,
                [
                  { key: "title", label: "Job Title" },
                  { 
                    key: "departmentId", 
                    label: "Department", 
                    render: (value) => departments.find(d => d.id === value)?.name || 'N/A'
                  },
                  { key: "level", label: "Level", render: (value) => <Badge variant="outline">{value}</Badge> },
                  { key: "description", label: "Description" }
                ],
                "designation",
                <Users className="h-5 w-5" />
              )}
            </div>
          </TabsContent>

          <TabsContent value="locations">
            <div className="space-y-6">
              {renderGenericTable(
                "Branches",
                "Manage office branches and locations",
                branches,
                [
                  { key: "name", label: "Branch Name" },
                  { key: "city", label: "City" },
                  { key: "state", label: "State" },
                  { key: "manager", label: "Manager" },
                  { key: "phone", label: "Contact" }
                ],
                "branch",
                <Building2 className="h-5 w-5" />
              )}
              
              {renderGenericTable(
                "Locations",
                "Manage specific locations within branches",
                locations,
                [
                  { key: "name", label: "Location Name" },
                  { key: "address", label: "Address" },
                  { 
                    key: "branchId", 
                    label: "Branch", 
                    render: (value) => branches.find(b => b.id === value)?.name || 'N/A'
                  },
                  { key: "capacity", label: "Capacity", render: (value) => `${value} people` }
                ],
                "location",
                <MapPin className="h-5 w-5" />
              )}
              
              {renderGenericTable(
                "Cost Centers",
                "Manage budget allocation and cost tracking",
                costCenters,
                [
                  { key: "code", label: "Code", render: (value) => <Badge variant="secondary">{value}</Badge> },
                  { key: "name", label: "Name" },
                  { key: "budget", label: "Budget" },
                  { key: "manager", label: "Manager" },
                  { key: "description", label: "Description" }
                ],
                "costCenter",
                <DollarSign className="h-5 w-5" />
              )}
            </div>
          </TabsContent>

          <TabsContent value="shifts">
            <div className="space-y-6">
              {renderGenericTable(
                "Shifts",
                "Manage work shifts and schedules",
                shifts,
                [
                  { key: 'name', label: 'Shift Name' },
                  { 
                    key: 'startTime', 
                    label: 'Start Time',
                    format: (value: string) => value
                  },
                  { 
                    key: 'endTime', 
                    label: 'End Time',
                    format: (value: string) => value
                  },
                  { 
                    key: 'totalHours', 
                    label: 'Duration',
                    format: (value: string) => value ? `${value} hrs` : '-'
                  },
                  {
                    key: 'isActive',
                    label: 'Status',
                    format: (value: boolean) => (
                      <Badge variant={value ? "default" : "secondary"}>
                        {value ? "Active" : "Inactive"}
                      </Badge>
                    )
                  },
                  {
                    key: 'colorCode',
                    label: 'Color',
                    format: (value: string) => value ? (
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-4 h-4 rounded border" 
                          style={{ backgroundColor: value }}
                        />
                        <span className="text-xs">{value}</span>
                      </div>
                    ) : '-'
                  }
                ],
                'shifts',
                <Clock className="h-5 w-5" />
              )}
            </div>
          </TabsContent>

          <TabsContent value="systems">
            <div className="space-y-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Fingerprint className="h-5 w-5" />
                      Biometric Machines
                    </CardTitle>
                    <CardDescription>Manage attendance tracking devices with IP and port configuration</CardDescription>
                  </div>
                  <Button onClick={() => handleOpenDialog('biometricMachine')} className="bg-hr-primary hover:bg-hr-primary/90">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Machine
                  </Button>
                </CardHeader>
                <CardContent>
                  {biometricMachines.length === 0 ? (
                    <div className="text-center py-8">
                      <Fingerprint className="mx-auto h-12 w-12 text-gray-400" />
                      <p className="mt-4 text-gray-600">No biometric machines found</p>
                      <Button onClick={() => handleOpenDialog('biometricMachine')} className="mt-4">
                        Create First Machine
                      </Button>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Serial Number</TableHead>
                          <TableHead>IP Address</TableHead>
                          <TableHead>Port</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Model</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Last Sync</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {biometricMachines.map((machine) => (
                          <TableRow key={machine.id}>
                            <TableCell>
                              <Badge variant="outline">{machine.serialNumber}</Badge>
                            </TableCell>
                            <TableCell>
                              <code className="bg-gray-100 px-2 py-1 rounded text-sm">{machine.ipAddress}</code>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary">{machine.port}</Badge>
                            </TableCell>
                            <TableCell>{machine.location}</TableCell>
                            <TableCell>{machine.model}</TableCell>
                            <TableCell>
                              <Badge variant={machine.status === 'active' ? 'default' : machine.status === 'inactive' ? 'secondary' : 'destructive'}>
                                {machine.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              {machine.lastSync ? formatDate(machine.lastSync) : 'Never'}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleTestConnection(machine)}
                                  disabled={!!testingConnection[machine.id]}
                                >
                                  {testingConnection[machine.id] ? (
                                    <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                                  ) : (
                                    <Link2 className="mr-1 h-3 w-3" />
                                  )}
                                  Test Connection
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => openImportDialog(machine)}
                                  disabled={machine.status !== 'active'}
                                >
                                  <Upload className="mr-1 h-3 w-3" />
                                  Import
                                </Button>
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <MoreVertical className="h-4 w-4" />
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent align="end">
                                    <DropdownMenuItem onClick={() => handleOpenDialog('biometricMachine', machine)}>
                                      <Edit className="mr-2 h-4 w-4" />
                                      Edit
                                    </DropdownMenuItem>
                                    <DropdownMenuItem className="text-red-600">
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      Delete
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
              
              {renderGenericTable(
                "Holidays",
                "Manage company and national holidays",
                holidays,
                [
                  { key: "name", label: "Holiday Name" },
                  { key: "date", label: "Date", render: (value) => formatDate(value) },
                  { 
                    key: "type", 
                    label: "Type", 
                    render: (value) => (
                      <Badge variant={value === 'national' ? 'default' : value === 'regional' ? 'secondary' : 'outline'}>
                        {value}
                      </Badge>
                    )
                  },
                  { 
                    key: "mandatory", 
                    label: "Mandatory", 
                    render: (value) => value ? <Badge variant="default">Yes</Badge> : <Badge variant="secondary">No</Badge>
                  }
                ],
                "holiday",
                <Calendar className="h-5 w-5" />
              )}
              
              {renderGenericTable(
                "Leave Policies",
                "Manage employee leave policies and allowances",
                leavePolicies,
                [
                  { key: "name", label: "Policy Name" },
                  { 
                    key: "type", 
                    label: "Type", 
                    render: (value) => <Badge variant="outline">{value}</Badge>
                  },
                  { key: "allowedDays", label: "Allowed Days", render: (value) => `${value} days/year` },
                  { 
                    key: "carryForward", 
                    label: "Carry Forward", 
                    render: (value) => value ? <Badge variant="default">Yes</Badge> : <Badge variant="secondary">No</Badge>
                  }
                ],
                "leavePolicy",
                <Clock className="h-5 w-5" />
              )}
            </div>
          </TabsContent>
        </div>
      </Tabs>

      {/* Generic Dialog for Forms */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {selectedItem ? `Edit ${dialogType}` : `Add New ${dialogType}`}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            {renderFormFields()}
            <div className="flex justify-end space-x-2 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowDialog(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="bg-hr-primary hover:bg-hr-primary/90"
                disabled={departmentMutation.isPending}
              >
                {departmentMutation.isPending ? 'Saving...' : (selectedItem ? 'Update' : 'Create')}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Machine Data Import Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Import Data from {selectedMachine?.serialNumber}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Machine Info */}
            {selectedMachine && (
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <Label className="text-gray-500">Serial Number</Label>
                      <p className="font-medium">{selectedMachine.serialNumber}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">IP Address</Label>
                      <p className="font-medium">{selectedMachine.ipAddress}:{selectedMachine.port}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Location</Label>
                      <p className="font-medium">{selectedMachine.location}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Last Sync</Label>
                      <p className="font-medium">
                        {selectedMachine.lastSync ? formatDate(selectedMachine.lastSync) : 'Never'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* File Upload Section */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Upload Attendance Data</CardTitle>
                <CardDescription>
                  Upload a CSV or JSON file containing attendance records from your biometric machine.
                  The file should include employee IDs, dates, and check-in/check-out times.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <input
                    type="file"
                    accept=".csv,.json"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file);
                    }}
                    className="hidden"
                    id="import-file"
                  />
                  <label htmlFor="import-file" className="cursor-pointer">
                    <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <p className="text-lg font-medium">Choose file to upload</p>
                    <p className="text-sm text-gray-500">
                      Supports CSV and JSON files up to 10MB
                    </p>
                  </label>
                </div>
                
                {importFile && (
                  <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
                    <FileText className="h-5 w-5 text-blue-600" />
                    <span className="font-medium">{importFile.name}</span>
                    <span className="text-sm text-gray-500">
                      ({(importFile.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Data Preview */}
            {importData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Data Preview</CardTitle>
                  <CardDescription>
                    Found {importData.length} records. Review the data format below.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="max-h-60 overflow-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          {Object.keys(importData[0] || {}).map((key) => (
                            <TableHead key={key}>{key}</TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {importData.slice(0, 5).map((record, index) => (
                          <TableRow key={index}>
                            {Object.values(record).map((value: any, idx) => (
                              <TableCell key={idx} className="max-w-32 truncate">
                                {String(value)}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    {importData.length > 5 && (
                      <p className="text-sm text-gray-500 mt-2 text-center">
                        Showing first 5 of {importData.length} records
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Import Progress/Results */}
            {importProgress.isImporting && (
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                    <span>Importing attendance data...</span>
                  </div>
                </CardContent>
              </Card>
            )}

            {importProgress.results && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-green-600">Import Completed</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">
                        {importProgress.results.summary.imported}
                      </p>
                      <p className="text-gray-600">New Records</p>
                    </div>
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">
                        {importProgress.results.summary.updated}
                      </p>
                      <p className="text-gray-600">Updated Records</p>
                    </div>
                    <div className="text-center p-3 bg-yellow-50 rounded-lg">
                      <p className="text-2xl font-bold text-yellow-600">
                        {importProgress.results.summary.skipped}
                      </p>
                      <p className="text-gray-600">Skipped Records</p>
                    </div>
                    <div className="text-center p-3 bg-red-50 rounded-lg">
                      <p className="text-2xl font-bold text-red-600">
                        {importProgress.results.summary.errorCount}
                      </p>
                      <p className="text-gray-600">Errors</p>
                    </div>
                  </div>
                  
                  {importProgress.results.validationErrors?.length > 0 && (
                    <div className="mt-4">
                      <Label className="text-red-600 font-medium">Validation Errors:</Label>
                      <div className="mt-2 space-y-1">
                        {importProgress.results.validationErrors.slice(0, 5).map((error: string, index: number) => (
                          <p key={index} className="text-sm text-red-600 bg-red-50 p-2 rounded">
                            {error}
                          </p>
                        ))}
                        {importProgress.results.validationErrors.length > 5 && (
                          <p className="text-sm text-gray-500">
                            ... and {importProgress.results.validationErrors.length - 5} more errors
                          </p>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {importProgress.errors && importProgress.errors.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg text-red-600 flex items-center gap-2">
                    <AlertCircle className="h-5 w-5" />
                    Import Failed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {importProgress.errors.map((error, index) => (
                      <p key={index} className="text-sm text-red-600 bg-red-50 p-2 rounded">
                        {error}
                      </p>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Dialog Actions */}
          <div className="flex justify-between items-center pt-4 border-t">
            <div className="text-sm text-gray-500">
              Expected format: employeeId, date, checkIn, checkOut (optional: faceVerified)
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => setShowImportDialog(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={startImport}
                disabled={!importData.length || importProgress.isImporting}
                className="bg-hr-primary hover:bg-hr-primary/90"
              >
                {importProgress.isImporting ? 'Importing...' : `Import ${importData.length} Records`}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}