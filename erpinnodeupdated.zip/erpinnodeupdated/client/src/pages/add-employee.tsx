import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth, usePermission } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, User, Home, FileText, Clock, DollarSign, Users, Building2, CreditCard, Shield, Calendar, CheckCircle, XCircle, IdCard } from "lucide-react";

interface EmployeeFormData {
  // Basic Information
  employeeName: string;
  email: string;
  phone: string;
  fatherName: string;
  isHusbandName: boolean;
  dateOfBirth: string;
  dateOfJoin: string;
  gender: string;
  
  // Work Information
  departmentId: string;
  designation: string;
  branchId: string;
  costCenterId: string;
  locationId: string;
  
  // Present Address
  presentAddress: string;
  presentState: string;
  presentDistrict: string;
  presentPinCode: string;
  // Permanent Address
  permanentAddress: string;
  permanentState: string;
  permanentDistrict: string;
  permanentPinCode: string;
  
  // Identity Documents
  aadharNo: string;
  panNo: string;
  
  // Banking Information
  bankAccountNo: string;
  ifscCode: string;
  
  // Compliance Information
  uanNo: string;
  esicNo: string;
  
  // Payroll Information
  payCode: string;
  payrollSetting: string;
  
  // Time Office Policy Information
  dutyStartTime: string;
  dutyEndTime: string;
  permissibleLateArrival: string;
  permissibleEarlyDeparture: string;
  firstWeeklyOffDay: string;
  secondWeeklyOffDay: string;
  overtimeApplicable: boolean;
  presentMarkingDuration: string;
  
  // Family Details
  familyDetails: string;
}

function AddEmployeeContent() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("personal");
  const user = authService.getUser();
  const companyId = user?.companyId;

  const [formData, setFormData] = useState<EmployeeFormData>({
    employeeName: '',
    email: '',
    phone: '',
    fatherName: '',
    isHusbandName: false,
    dateOfBirth: '',
    dateOfJoin: '',
    gender: '',
    departmentId: '',
    designation: '',
    branchId: '',
    costCenterId: '',
    locationId: '',
    presentAddress: '',
    presentState: '',
    presentDistrict: '',
    presentPinCode: '',
    permanentAddress: '',
    permanentState: '',
    permanentDistrict: '',
    permanentPinCode: '',
    aadharNo: '',
    panNo: '',
    bankAccountNo: '',
    ifscCode: '',
    uanNo: '',
    esicNo: '',
    payCode: '',
    payrollSetting: '',
    dutyStartTime: '',
    dutyEndTime: '',
    permissibleLateArrival: '',
    permissibleEarlyDeparture: '',
    firstWeeklyOffDay: '',
    secondWeeklyOffDay: '',
    overtimeApplicable: false,
    presentMarkingDuration: '',
    familyDetails: ''
  });

  const [isLookingUp, setIsLookingUp] = useState(false);
  const [showAadhaarVerificationModal, setShowAadhaarVerificationModal] = useState(true);
  const [aadhaarInput, setAadhaarInput] = useState('');
  const [selectedStateId, setSelectedStateId] = useState<string>('');
  const [selectedPermanentStateId, setSelectedPermanentStateId] = useState<string>('');

  // Aadhaar lookup mutation
  const aadhaarLookupMutation = useMutation({
    mutationFn: async (aadhaarNo: string) => {
      console.log('🔍🔍🔍 MUTATION FUNCTION CALLED - Starting Aadhaar lookup for:', aadhaarNo);
      try {
        const response = await apiRequestWithAuth('POST', '/api/admin/lookup-employee-by-aadhaar', {
          aadhaarNo: aadhaarNo
        });
        
        console.log('📡 API Response status:', response.status);
        
        if (!response.ok) {
          const errorText = await response.text();
          console.error('❌ API Error:', response.status, errorText);
          throw new Error(`API Error: ${response.status} - ${errorText}`);
        }
        
        const data = await response.json();
        console.log('✅ Lookup response:', data);
        return data;
      } catch (error) {
        console.error('❌ Lookup failed:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      if (data.found) {
        const { employeeProfile, kycDetails, userEmail } = data;
        // Auto-fill form data directly
        handleAadhaarApprovalDirectly(employeeProfile, kycDetails, userEmail);
        setShowAadhaarVerificationModal(false);
        toast({
          title: "Employee Data Found",
          description: "Form has been pre-filled with existing employee data.",
        });
      } else {
        setShowAadhaarVerificationModal(false);
        toast({
          title: "New Employee",
          description: "No existing profile found. Please fill in all details.",
        });
      }
      setIsLookingUp(false);
    },
    onError: (error: any) => {
      setIsLookingUp(false);
      toast({
        title: "Lookup Failed",
        description: error.message || "Failed to lookup employee data",
        variant: "destructive"
      });
    }
  });

  // Handle Aadhaar input (formatting only)
  const handleAadhaarChange = (value: string) => {
    // Format Aadhaar as user types (1234 5678 9012)
    const cleanValue = value.replace(/\s/g, '');
    const formattedValue = cleanValue.replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
    setFormData(prev => ({ ...prev, aadharNo: formattedValue }));
  };

  // Handle Aadhaar input in modal
  const handleModalAadhaarInput = (value: string) => {
    const cleanValue = value.replace(/\s/g, '');
    const formattedValue = cleanValue.replace(/(\d{4})(\d{4})(\d{4})/, '$1 $2 $3');
    setAadhaarInput(formattedValue);
  };

  // Handle verification from modal
  const handleModalVerifyAadhaar = () => {
    console.log('🔘 VERIFY BUTTON CLICKED - Aadhaar Input:', aadhaarInput);
    const cleanValue = aadhaarInput.replace(/\s/g, '');
    console.log('🧹 Clean Aadhaar Value:', cleanValue, 'Length:', cleanValue.length);
    
    if (cleanValue.length !== 12) {
      console.log('❌ Invalid Aadhaar length, showing error toast');
      toast({
        title: "Invalid Aadhaar",
        description: "Please enter a valid 12-digit Aadhaar number",
        variant: "destructive"
      });
      return;
    }
    
    console.log('✅ Valid Aadhaar, triggering mutation...');
    setFormData(prev => ({ ...prev, aadharNo: aadhaarInput }));
    setIsLookingUp(true);
    aadhaarLookupMutation.mutate(cleanValue);
  };

  // Generic input handler for other fields
  const handleInputChange = (field: keyof EmployeeFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  // Copy present address to permanent address
  const copyPresentToPermanent = () => {
    setFormData(prev => ({
      ...prev,
      permanentAddress: prev.presentAddress,
      permanentState: prev.presentState,
      permanentDistrict: prev.presentDistrict,
      permanentPinCode: prev.presentPinCode
    }));
    setSelectedPermanentStateId(selectedStateId);
  };

  // Direct approval function for modal verification
  const handleAadhaarApprovalDirectly = (employeeProfile: any, kycDetails: any, userEmail?: string) => {
    // Format date of birth for input field (YYYY-MM-DD for date input)
    let formattedDob = '';
    if (employeeProfile.dateOfBirth) {
      try {
        const dobDate = new Date(employeeProfile.dateOfBirth);
        formattedDob = dobDate.toISOString().split('T')[0]; // YYYY-MM-DD format
      } catch (e) {
        console.error('Error formatting DOB:', e);
      }
    }
    
    setFormData(prev => ({
      ...prev,
      employeeName: employeeProfile.fullName || '',
      email: userEmail || '', // Use actual user email from signup
      phone: employeeProfile.phone || '',
      fatherName: employeeProfile.fatherName || employeeProfile.fatherHusbandName || '',
      dateOfBirth: formattedDob,
      gender: employeeProfile.gender || '',
      presentAddress: employeeProfile.presentAddress || employeeProfile.address || '',
      permanentAddress: employeeProfile.permanentAddress || employeeProfile.address || '',
      aadharNo: kycDetails?.aadharNo || employeeProfile.aadhaarNo || '',
      panNo: kycDetails?.panNo || employeeProfile.panNo || '',
      bankAccountNo: kycDetails?.bankAccountNo || '',
      ifscCode: kycDetails?.ifscCode || '',
      uanNo: kycDetails?.uanNo || '',
      esicNo: kycDetails?.esicNo || ''
    }));
    setActiveTab('personal');
  };

  // Fetch departments
  const { data: departments = [] } = useQuery<any[]>({
    queryKey: [`/api/departments/${companyId}`],
    enabled: !!companyId,
  });

  // Fetch designations
  const { data: designations = [] } = useQuery<any[]>({
    queryKey: [`/api/designations/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/designations/${companyId}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Fetch states
  const { data: states = [] } = useQuery<any[]>({
    queryKey: ['/api/states'],
  });

  // Fetch districts based on selected present address state
  const { data: districts = [] } = useQuery<any[]>({
    queryKey: [`/api/districts/${selectedStateId}`],
    enabled: !!selectedStateId,
  });

  // Fetch districts based on selected permanent address state
  const { data: permanentDistricts = [] } = useQuery<any[]>({
    queryKey: [`/api/districts/${selectedPermanentStateId}`],
    enabled: !!selectedPermanentStateId,
  });

  // Mock data for other dropdowns (you can replace with real API calls)
  const branches = [
    { id: '1', name: 'Headquarters' },
    { id: '2', name: 'West Coast Office' },
    { id: '3', name: 'Regional Branch' },
  ];

  const costCenters = [
    { id: '1', name: 'IT Department', code: 'CC001' },
    { id: '2', name: 'HR Department', code: 'CC002' },
    { id: '3', name: 'Finance Department', code: 'CC003' },
  ];

  const locations = [
    { id: '1', name: 'Floor 1 - Reception' },
    { id: '2', name: 'Floor 3 - Development' },
    { id: '3', name: 'Floor 2 - Administration' },
  ];

  const payrollSettings = [
    { id: 'monthly', name: 'Monthly Salary' },
    { id: 'hourly', name: 'Hourly Wages' },
    { id: 'contract', name: 'Contract Based' },
  ];

  const timeOfficePolicies = [
    { id: 'standard', name: 'Standard 9-5' },
    { id: 'flexible', name: 'Flexible Hours' },
    { id: 'shift', name: 'Shift Based' },
    { id: 'remote', name: 'Remote Work' },
  ];

  const createEmployeeMutation = useMutation({
    mutationFn: async (data: EmployeeFormData) => {
      // Create simplified employee data matching the actual database schema
      const employeeData = {
        companyId: companyId,
        userId: user?.id || 1, // Use current user ID
        employeeId: data.payCode || `EMP${Date.now()}`,
        fullName: data.employeeName, // Required field
        fatherHusbandName: data.fatherName || '',
        email: data.email || data.employeeName.toLowerCase().replace(/\s+/g, '.') + '@company.com',
        phone: data.phone || '',
        departmentId: data.departmentId ? parseInt(data.departmentId) : undefined,
        position: data.designation || '', // Map designation to position for backend compatibility
        address: data.presentAddress || data.permanentAddress || '',
        aadhaarNo: data.aadharNo ? data.aadharNo.replace(/\s/g, '') : '',  // Add Aadhaar number
        panNo: data.panNo || '',
        dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth) : undefined,
        gender: data.gender || undefined,
        hireDate: data.dateOfJoin ? new Date(data.dateOfJoin) : undefined, // Use hireDate from dateOfJoin
        status: 'active' as const,
      };

      console.log('Sending employee data:', employeeData);
      
      const response = await apiRequestWithAuth('POST', '/api/employees', employeeData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/employees/${companyId}`] });
      toast({
        title: "Success",
        description: "Employee created successfully",
      });
      setLocation('/admin/employees');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create employee",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.employeeName || !formData.email || !formData.dateOfJoin || !formData.gender) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields (Name, Email, Date of Joining, Gender)",
        variant: "destructive",
      });
      return;
    }

    // Validate Aadhaar number (mandatory)
    const cleanAadhaar = formData.aadharNo.replace(/\s/g, '');
    if (!cleanAadhaar || cleanAadhaar.length !== 12) {
      toast({
        title: "Aadhaar Required",
        description: "Please provide a valid 12-digit Aadhaar number to proceed with employee registration.",
        variant: "destructive",
      });
      // Switch to identity tab to show the error
      setActiveTab('identity');
      return;
    }

    createEmployeeMutation.mutate(formData);
  };



  return (
    <div className="space-y-6">
      {/* Aadhaar Verification Modal */}
      <Dialog open={showAadhaarVerificationModal} onOpenChange={setShowAadhaarVerificationModal}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-600" />
              Aadhaar Verification
            </DialogTitle>
            <DialogDescription>
              Enter your 12-digit Aadhaar number to verify your identity before creating an employee profile.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="aadhaar-input">Aadhaar Number *</Label>
              <Input
                id="aadhaar-input"
                value={aadhaarInput}
                onChange={(e) => handleModalAadhaarInput(e.target.value)}
                placeholder="xxxx xxxx xxxx"
                maxLength={14}
                className="h-12 border-2 focus:border-blue-500 font-mono tracking-wider"
                disabled={isLookingUp}
              />
              <p className="text-xs text-gray-500">
                Enter your 12-digit Aadhaar number (spaces will be added automatically)
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowAadhaarVerificationModal(false);
                setAadhaarInput('');
              }}
              disabled={isLookingUp}
            >
              Cancel
            </Button>
            <Button
              type="button"
              onClick={handleModalVerifyAadhaar}
              disabled={isLookingUp || aadhaarInput.replace(/\s/g, '').length !== 12}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isLookingUp ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Verifying...
                </>
              ) : (
                'Verify Aadhaar'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="flex items-center gap-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocation('/admin/employees')}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Employees
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Add New Employee</h1>
          <p className="text-muted-foreground">Complete employee information form</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-7 bg-gray-100 p-1 rounded-lg">
            <TabsTrigger 
              value="personal" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <User className="h-4 w-4" />
              Personal
            </TabsTrigger>
            <TabsTrigger 
              value="employment" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Building2 className="h-4 w-4" />
              Employment
            </TabsTrigger>
            <TabsTrigger 
              value="address" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Home className="h-4 w-4" />
              Address
            </TabsTrigger>
            <TabsTrigger 
              value="identity" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Shield className="h-4 w-4" />
              Identity
            </TabsTrigger>
            <TabsTrigger 
              value="payroll" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <DollarSign className="h-4 w-4" />
              Payroll
            </TabsTrigger>
            <TabsTrigger 
              value="timeoffice" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Clock className="h-4 w-4" />
              Time Office
            </TabsTrigger>
            <TabsTrigger 
              value="family" 
              className="flex items-center gap-1 text-xs px-1 py-3 data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Users className="h-4 w-4" />
              Family
            </TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal" className="space-y-6">
            <Card className="border-l-4 border-l-hr-primary">
              <CardHeader className="bg-gradient-to-r from-hr-primary/5 to-transparent">
                <CardTitle className="flex items-center gap-3 text-hr-primary">
                  <User className="h-6 w-6" />
                  Personal Information
                </CardTitle>
                <CardDescription className="text-gray-600">Basic personal details and identification</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="employeeName" className="text-sm font-semibold text-gray-700">
                    Employee Full Name *
                  </Label>
                  <Input
                    id="employeeName"
                    value={formData.employeeName}
                    onChange={(e) => handleInputChange('employeeName', e.target.value)}
                    placeholder="Enter complete full name"
                    className="h-12 border-2 focus:border-hr-primary"
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <Label htmlFor="email" className="text-sm font-semibold text-gray-700">
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    placeholder="Enter email address"
                    className="h-12 border-2 focus:border-hr-primary"
                    required
                  />
                </div>
                
                <div className="space-y-3">
                  <Label htmlFor="phone" className="text-sm font-semibold text-gray-700">
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    placeholder="Enter phone number"
                    className="h-12 border-2 focus:border-hr-primary"
                  />
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-semibold text-gray-700">
                      {formData.isHusbandName ? "Husband Name" : "Father Name"}
                    </Label>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isHusbandName"
                        checked={formData.isHusbandName}
                        onCheckedChange={(checked) => handleInputChange('isHusbandName', checked as boolean)}
                      />
                      <Label htmlFor="isHusbandName" className="text-xs text-gray-600">Use Husband Name</Label>
                    </div>
                  </div>
                  <Input
                    id="fatherName"
                    value={formData.fatherName}
                    onChange={(e) => handleInputChange('fatherName', e.target.value)}
                    placeholder={formData.isHusbandName ? "Enter husband's name" : "Enter father's name"}
                    className="h-12 border-2 focus:border-hr-primary"
                  />
                </div>
              </div>

              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="dateOfBirth" className="text-sm font-semibold text-gray-700">
                    Date of Birth
                  </Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                    className="h-12 border-2 focus:border-hr-primary"
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="dateOfJoin" className="text-sm font-semibold text-gray-700">
                    Date of Joining *
                  </Label>
                  <Input
                    id="dateOfJoin"
                    type="date"
                    value={formData.dateOfJoin}
                    onChange={(e) => handleInputChange('dateOfJoin', e.target.value)}
                    className="h-12 border-2 focus:border-hr-primary"
                    required
                  />
                </div>
              </div>

              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="gender" className="text-sm font-semibold text-gray-700">
                    Gender *
                  </Label>
                  <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-hr-primary">
                      <SelectValue placeholder="Choose gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Prefer not to say</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="payCode" className="text-sm font-semibold text-gray-700">
                    Employee Pay Code *
                  </Label>
                  <Input
                    id="payCode"
                    value={formData.payCode}
                    onChange={(e) => handleInputChange('payCode', e.target.value)}
                    placeholder="Enter employee pay code"
                    className="h-12 border-2 focus:border-hr-primary"
                    required
                  />
                  <p className="text-xs text-gray-500">Unique identifier for payroll processing</p>
                </div>
              </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Employment Details Tab */}
          <TabsContent value="employment" className="space-y-6">
            <Card className="border-l-4 border-l-blue-500">
              <CardHeader className="bg-gradient-to-r from-blue-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-blue-700">
                  <Building2 className="h-6 w-6" />
                  Employment Details
                </CardTitle>
                <CardDescription className="text-gray-600">Department, position, and workplace assignment</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="departmentId" className="text-sm font-semibold text-gray-700">
                    Department
                  </Label>
                  <Select value={formData.departmentId} onValueChange={(value) => handleInputChange('departmentId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Choose department" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments.map((dept: any) => (
                        <SelectItem key={dept.id} value={dept.id.toString()}>{dept.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="designation" className="text-sm font-semibold text-gray-700">
                    Designation
                  </Label>
                  <Select value={formData.designation} onValueChange={(value) => handleInputChange('designation', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select job title" />
                    </SelectTrigger>
                    <SelectContent>
                      {designations.map((designation) => (
                        <SelectItem key={designation.id} value={designation.id}>{designation.title}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="branchId" className="text-sm font-semibold text-gray-700">
                    Branch/Office
                  </Label>
                  <Select value={formData.branchId} onValueChange={(value) => handleInputChange('branchId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select office branch" />
                    </SelectTrigger>
                    <SelectContent>
                      {branches.map((branch) => (
                        <SelectItem key={branch.id} value={branch.id}>{branch.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="costCenterId" className="text-sm font-semibold text-gray-700">
                    Cost Center
                  </Label>
                  <Select value={formData.costCenterId} onValueChange={(value) => handleInputChange('costCenterId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select cost center" />
                    </SelectTrigger>
                    <SelectContent>
                      {costCenters.map((center) => (
                        <SelectItem key={center.id} value={center.id}>
                          {center.code} - {center.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="locationId" className="text-sm font-semibold text-gray-700">
                    Work Location
                  </Label>
                  <Select value={formData.locationId} onValueChange={(value) => handleInputChange('locationId', value)}>
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500">
                      <SelectValue placeholder="Select work location" />
                    </SelectTrigger>
                    <SelectContent>
                      {locations.map((location) => (
                        <SelectItem key={location.id} value={location.id}>{location.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Address Information Tab */}
          <TabsContent value="address" className="space-y-6">
            <Card className="border-l-4 border-l-green-500">
              <CardHeader className="bg-gradient-to-r from-green-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-green-700">
                  <Home className="h-6 w-6" />
                  Address Information
                </CardTitle>
                <CardDescription className="text-gray-600">Current and permanent residential addresses</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Present Address Section */}
              <div className="space-y-4 p-6 bg-blue-50 rounded-lg border-2 border-blue-200">
                <h3 className="font-semibold text-lg text-blue-800 mb-4">Present Address</h3>
                
                <div className="space-y-3">
                  <Label htmlFor="presentAddress" className="text-sm font-semibold text-gray-700">
                    Address *
                  </Label>
                  <Textarea
                    id="presentAddress"
                    value={formData.presentAddress}
                    onChange={(e) => handleInputChange('presentAddress', e.target.value)}
                    placeholder="Enter complete current residential address with landmark"
                    className="min-h-[100px] border-2 focus:border-blue-500 resize-none bg-white"
                    rows={4}
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="presentState" className="text-sm font-semibold text-gray-700">
                    State *
                  </Label>
                  <Select 
                    value={formData.presentState} 
                    onValueChange={(value) => {
                      handleInputChange('presentState', value);
                      setSelectedStateId(value);
                      handleInputChange('presentDistrict', ''); // Reset district when state changes
                    }}
                  >
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500 bg-white">
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      {states.map((state: any) => (
                        <SelectItem key={state.id} value={state.id.toString()}>
                          {state.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="presentDistrict" className="text-sm font-semibold text-gray-700">
                    District *
                  </Label>
                  <Select 
                    value={formData.presentDistrict} 
                    onValueChange={(value) => handleInputChange('presentDistrict', value)}
                    disabled={!selectedStateId}
                  >
                    <SelectTrigger className="h-12 border-2 focus:border-blue-500 bg-white">
                      <SelectValue placeholder={selectedStateId ? "Select district" : "First select a state"} />
                    </SelectTrigger>
                    <SelectContent>
                      {districts.map((district: any) => (
                        <SelectItem key={district.id} value={district.id.toString()}>
                          {district.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="presentPinCode" className="text-sm font-semibold text-gray-700">
                    Pin Code *
                  </Label>
                  <Input
                    id="presentPinCode"
                    value={formData.presentPinCode}
                    onChange={(e) => handleInputChange('presentPinCode', e.target.value)}
                    placeholder="Enter 6-digit pin code"
                    maxLength={6}
                    className="h-12 border-2 focus:border-blue-500 bg-white"
                  />
                </div>
              </div>

              {/* Permanent Address Section */}
              <div className="space-y-4 p-6 bg-green-50 rounded-lg border-2 border-green-200">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-lg text-green-800">Permanent Address</h3>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={copyPresentToPermanent}
                    className="text-xs border-green-600 text-green-700 hover:bg-green-100"
                  >
                    Copy from Present
                  </Button>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="permanentAddress" className="text-sm font-semibold text-gray-700">
                    Address *
                  </Label>
                  <Textarea
                    id="permanentAddress"
                    value={formData.permanentAddress}
                    onChange={(e) => handleInputChange('permanentAddress', e.target.value)}
                    placeholder="Enter permanent address (if different from present)"
                    className="min-h-[100px] border-2 focus:border-green-500 resize-none bg-white"
                    rows={4}
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="permanentState" className="text-sm font-semibold text-gray-700">
                    State *
                  </Label>
                  <Select 
                    value={formData.permanentState} 
                    onValueChange={(value) => {
                      handleInputChange('permanentState', value);
                      setSelectedPermanentStateId(value);
                      handleInputChange('permanentDistrict', ''); // Reset district when state changes
                    }}
                  >
                    <SelectTrigger className="h-12 border-2 focus:border-green-500 bg-white">
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      {states.map((state: any) => (
                        <SelectItem key={state.id} value={state.id.toString()}>
                          {state.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="permanentDistrict" className="text-sm font-semibold text-gray-700">
                    District *
                  </Label>
                  <Select 
                    value={formData.permanentDistrict} 
                    onValueChange={(value) => handleInputChange('permanentDistrict', value)}
                    disabled={!selectedPermanentStateId}
                  >
                    <SelectTrigger className="h-12 border-2 focus:border-green-500 bg-white">
                      <SelectValue placeholder={selectedPermanentStateId ? "Select district" : "First select a state"} />
                    </SelectTrigger>
                    <SelectContent>
                      {permanentDistricts.map((district: any) => (
                        <SelectItem key={district.id} value={district.id.toString()}>
                          {district.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="permanentPinCode" className="text-sm font-semibold text-gray-700">
                    Pin Code *
                  </Label>
                  <Input
                    id="permanentPinCode"
                    value={formData.permanentPinCode}
                    onChange={(e) => handleInputChange('permanentPinCode', e.target.value)}
                    placeholder="Enter 6-digit pin code"
                    maxLength={6}
                    className="h-12 border-2 focus:border-green-500 bg-white"
                  />
                </div>
              </div>
            </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Identity & Financial Information Tab */}
          <TabsContent value="identity" className="space-y-6">
            <Card className="border-l-4 border-l-purple-500">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-purple-700">
                  <Shield className="h-6 w-6" />
                  Identity & Financial Information
                </CardTitle>
                <CardDescription className="text-gray-600">Government documents, banking details, and compliance information</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="space-y-8">
              {/* Identity Documents */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Identity Documents</h4>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="aadharNo" className="text-sm font-semibold text-gray-700">
                      Aadhaar Number *
                    </Label>
                    <Input
                      id="aadharNo"
                      value={formData.aadharNo}
                      onChange={(e) => handleAadhaarChange(e.target.value)}
                      placeholder="1234 5678 9012"
                      maxLength={14}
                      className="h-12 border-2 focus:border-purple-500 font-mono tracking-wider"
                      required
                      readOnly
                    />
                    <p className="text-xs text-gray-500">Verified via initial Aadhaar check</p>
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="panNo" className="text-sm font-semibold text-gray-700">
                      PAN Number
                    </Label>
                    <Input
                      id="panNo"
                      value={formData.panNo}
                      onChange={(e) => handleInputChange('panNo', e.target.value.toUpperCase())}
                      placeholder="ABCDE1234F"
                      maxLength={10}
                      className="h-12 border-2 focus:border-purple-500 font-mono tracking-wider uppercase"
                    />
                  </div>
                </div>
              </div>

              {/* Banking Details */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Banking Details</h4>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="bankAccountNo" className="text-sm font-semibold text-gray-700">
                      Bank Account Number
                    </Label>
                    <Input
                      id="bankAccountNo"
                      value={formData.bankAccountNo}
                      onChange={(e) => handleInputChange('bankAccountNo', e.target.value)}
                      placeholder="Enter account number"
                      className="h-12 border-2 focus:border-purple-500 font-mono"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="ifscCode" className="text-sm font-semibold text-gray-700">
                      IFSC Code
                    </Label>
                    <Input
                      id="ifscCode"
                      value={formData.ifscCode}
                      onChange={(e) => handleInputChange('ifscCode', e.target.value.toUpperCase())}
                      placeholder="ABCD0123456"
                      maxLength={11}
                      className="h-12 border-2 focus:border-purple-500 font-mono tracking-wider uppercase"
                    />
                  </div>
                </div>
              </div>

              {/* Compliance Information */}
              <div>
                <h4 className="font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Compliance Information</h4>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label htmlFor="uanNo" className="text-sm font-semibold text-gray-700">
                      UAN Number (Provident Fund)
                    </Label>
                    <Input
                      id="uanNo"
                      value={formData.uanNo}
                      onChange={(e) => handleInputChange('uanNo', e.target.value.replace(/\D/g, ''))}
                      placeholder="123456789012"
                      maxLength={12}
                      className="h-12 border-2 focus:border-purple-500 font-mono"
                    />
                  </div>

                  <div className="space-y-3">
                    <Label htmlFor="esicNo" className="text-sm font-semibold text-gray-700">
                      ESIC Number
                    </Label>
                    <Input
                      id="esicNo"
                      value={formData.esicNo}
                      onChange={(e) => handleInputChange('esicNo', e.target.value)}
                      placeholder="1234567890"
                      className="h-12 border-2 focus:border-purple-500 font-mono"
                    />
                  </div>
                </div>
              </div>
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Payroll Information Tab */}
          <TabsContent value="payroll" className="space-y-6">
            <Card className="border-l-4 border-l-orange-500">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-orange-700">
                  <DollarSign className="h-6 w-6" />
                  Payroll Settings
                </CardTitle>
                <CardDescription className="text-gray-600">Compensation structure and payroll configuration</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <Label htmlFor="payrollSetting" className="text-sm font-semibold text-gray-700">
                      Payroll Setting *
                    </Label>
                    <Select value={formData.payrollSetting} onValueChange={(value) => handleInputChange('payrollSetting', value)}>
                      <SelectTrigger className="h-12 border-2 focus:border-orange-500">
                        <SelectValue placeholder="Choose payroll type" />
                      </SelectTrigger>
                      <SelectContent>
                        {payrollSettings.map((setting) => (
                          <SelectItem key={setting.id} value={setting.id}>{setting.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Time Office Policy Tab */}
          <TabsContent value="timeoffice" className="space-y-6">
            <Card className="border-l-4 border-l-indigo-500">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-indigo-700">
                  <Clock className="h-6 w-6" />
                  Time Office Policy
                </CardTitle>
                <CardDescription className="text-gray-600">Work schedule, attendance rules, and time management policies</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Duty Timing */}
                  <div className="space-y-6">
                    <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2">Work Timing</h4>
                    <div className="space-y-3">
                      <Label htmlFor="dutyStartTime" className="text-sm font-semibold text-gray-700">
                        Duty Start Time *
                      </Label>
                      <Input
                        id="dutyStartTime"
                        type="time"
                        value={formData.dutyStartTime}
                        onChange={(e) => handleInputChange('dutyStartTime', e.target.value)}
                        className="h-12 border-2 focus:border-indigo-500"
                        required
                      />
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="dutyEndTime" className="text-sm font-semibold text-gray-700">
                        Duty End Time *
                      </Label>
                      <Input
                        id="dutyEndTime"
                        type="time"
                        value={formData.dutyEndTime}
                        onChange={(e) => handleInputChange('dutyEndTime', e.target.value)}
                        className="h-12 border-2 focus:border-indigo-500"
                        required
                      />
                    </div>
                  </div>

                  {/* Permissible Timing */}
                  <div className="space-y-6">
                    <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2">Flexibility Rules</h4>
                    <div className="space-y-3">
                      <Label htmlFor="permissibleLateArrival" className="text-sm font-semibold text-gray-700">
                        Permissible Late Arrival (minutes)
                      </Label>
                      <Input
                        id="permissibleLateArrival"
                        type="number"
                        min="0"
                        max="120"
                        value={formData.permissibleLateArrival}
                        onChange={(e) => handleInputChange('permissibleLateArrival', e.target.value)}
                        placeholder="30"
                        className="h-12 border-2 focus:border-indigo-500"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="permissibleEarlyDeparture" className="text-sm font-semibold text-gray-700">
                        Permissible Early Departure (minutes)
                      </Label>
                      <Input
                        id="permissibleEarlyDeparture"
                        type="number"
                        min="0"
                        max="120"
                        value={formData.permissibleEarlyDeparture}
                        onChange={(e) => handleInputChange('permissibleEarlyDeparture', e.target.value)}
                        placeholder="15"
                        className="h-12 border-2 focus:border-indigo-500"
                      />
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="presentMarkingDuration" className="text-sm font-semibold text-gray-700">
                        Present Marking Duration (hours)
                      </Label>
                      <Input
                        id="presentMarkingDuration"
                        type="number"
                        min="1"
                        max="12"
                        step="0.5"
                        value={formData.presentMarkingDuration}
                        onChange={(e) => handleInputChange('presentMarkingDuration', e.target.value)}
                        placeholder="4"
                        className="h-12 border-2 focus:border-indigo-500"
                      />
                      <p className="text-xs text-gray-500">Minimum hours for half-day marking</p>
                    </div>
                  </div>

                  {/* Weekly Offs & OT */}
                  <div className="space-y-6">
                    <h4 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2">Weekly Offs & Overtime</h4>
                    <div className="space-y-3">
                      <Label htmlFor="firstWeeklyOffDay" className="text-sm font-semibold text-gray-700">
                        First Weekly Off Day *
                      </Label>
                      <Select value={formData.firstWeeklyOffDay} onValueChange={(value) => handleInputChange('firstWeeklyOffDay', value)}>
                        <SelectTrigger className="h-12 border-2 focus:border-indigo-500">
                          <SelectValue placeholder="Select day" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="sunday">Sunday</SelectItem>
                          <SelectItem value="monday">Monday</SelectItem>
                          <SelectItem value="tuesday">Tuesday</SelectItem>
                          <SelectItem value="wednesday">Wednesday</SelectItem>
                          <SelectItem value="thursday">Thursday</SelectItem>
                          <SelectItem value="friday">Friday</SelectItem>
                          <SelectItem value="saturday">Saturday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <Label htmlFor="secondWeeklyOffDay" className="text-sm font-semibold text-gray-700">
                        Second Weekly Off Day
                      </Label>
                      <Select value={formData.secondWeeklyOffDay} onValueChange={(value) => handleInputChange('secondWeeklyOffDay', value)}>
                        <SelectTrigger className="h-12 border-2 focus:border-indigo-500">
                          <SelectValue placeholder="Select day (optional)" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          <SelectItem value="sunday">Sunday</SelectItem>
                          <SelectItem value="monday">Monday</SelectItem>
                          <SelectItem value="tuesday">Tuesday</SelectItem>
                          <SelectItem value="wednesday">Wednesday</SelectItem>
                          <SelectItem value="thursday">Thursday</SelectItem>
                          <SelectItem value="friday">Friday</SelectItem>
                          <SelectItem value="saturday">Saturday</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          id="overtimeApplicable"
                          checked={formData.overtimeApplicable}
                          onCheckedChange={(checked) => handleInputChange('overtimeApplicable', checked as boolean)}
                          className="border-2 border-indigo-500"
                        />
                        <Label htmlFor="overtimeApplicable" className="text-sm font-semibold text-gray-700">
                          Overtime Applicable
                        </Label>
                      </div>
                      <p className="text-xs text-gray-500 pl-7">
                        Enable overtime calculation for extra working hours
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Family & Emergency Contact Tab */}
          <TabsContent value="family" className="space-y-6">
            <Card className="border-l-4 border-l-pink-500">
              <CardHeader className="bg-gradient-to-r from-pink-50 to-transparent">
                <CardTitle className="flex items-center gap-3 text-pink-700">
                  <Users className="h-6 w-6" />
                  Family & Emergency Contact
                </CardTitle>
                <CardDescription className="text-gray-600">Family member information and emergency contact details</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
            <div className="space-y-3">
              <Label htmlFor="familyDetails" className="text-sm font-semibold text-gray-700">
                Family Details & Emergency Contact
              </Label>
              <Textarea
                id="familyDetails"
                value={formData.familyDetails}
                onChange={(e) => handleInputChange('familyDetails', e.target.value)}
                placeholder="Enter family member details, emergency contact person name, relationship, phone number, address, etc."
                className="min-h-[150px] border-2 focus:border-pink-500 resize-none"
                rows={6}
              />
              <p className="text-xs text-gray-500 mt-2">
                Include: Emergency contact name, relationship, phone number, alternate contact details, family member information for benefits/insurance purposes
              </p>
              </div>
            </CardContent>
          </Card>
          </TabsContent>

          {/* Submit Actions - Always visible */}
          <div className="bg-gray-50 p-8 rounded-lg border border-gray-200 mt-8">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
              <div className="text-sm text-gray-600">
                <p className="font-medium">Ready to create employee profile?</p>
                <p>All information will be saved securely in the system.</p>
              </div>
              <div className="flex space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation('/admin/employees')}
                  className="px-8 py-3 border-2 hover:bg-gray-100"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="px-8 py-3 bg-hr-primary hover:bg-hr-primary/90 text-white font-semibold shadow-lg"
                  disabled={createEmployeeMutation.isPending}
                >
                  {createEmployeeMutation.isPending ? (
                    <>
                      <Clock className="mr-2 h-4 w-4 animate-spin" />
                      Creating Employee...
                    </>
                  ) : (
                    <>
                      <User className="mr-2 h-4 w-4" />
                      Create Employee Profile
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </Tabs>
      </form>
    </div>
  );
}

export default function AddEmployee() {
  const { hasPermission: canCreateEmployee, loading: permissionLoading } = usePermission('employee_create');
  
  if (permissionLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Checking permissions...</p>
        </div>
      </div>
    );
  }
  
  if (!canCreateEmployee) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Shield className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-red-600 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">You don't have permission to create employees.</p>
          <p className="text-sm text-gray-500">Request 'employee_create' permission from your administrator.</p>
        </div>
      </div>
    );
  }

  return <AddEmployeeContent />;
}