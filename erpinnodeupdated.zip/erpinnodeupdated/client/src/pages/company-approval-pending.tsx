import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, CheckCircle, Building2, Mail, Phone, MapPin } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Link } from "wouter";

export default function CompanyApprovalPending() {
  const { user } = useAuth();

  const { data: company } = useQuery({
    queryKey: [`/api/companies/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200"><Clock className="w-3 h-3 mr-1" />Pending Approval</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (!company) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-hr-background to-hr-background/80 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-hr-primary/10 p-4 rounded-full">
              <Building2 className="h-12 w-12 text-hr-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-hr-text-primary">
            Company Registration Status
          </h1>
          <p className="text-hr-text-secondary max-w-2xl mx-auto">
            Your company registration has been submitted and is currently under review by our system administrators.
          </p>
        </div>

        {/* Status Card */}
        <Card className="shadow-lg border-0">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">Company Details</CardTitle>
              {getStatusBadge(company.status)}
            </div>
            <CardDescription>
              Review your submitted company information below
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Company Information */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-hr-text-primary mb-3">Basic Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Building2 className="w-4 h-4 text-hr-text-secondary" />
                      <div>
                        <p className="text-sm text-hr-text-secondary">Company Name</p>
                        <p className="font-medium">{company.name}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-hr-text-secondary" />
                      <div>
                        <p className="text-sm text-hr-text-secondary">Email</p>
                        <p className="font-medium">{company.email}</p>
                      </div>
                    </div>
                    {company.phone && (
                      <div className="flex items-center gap-3">
                        <Phone className="w-4 h-4 text-hr-text-secondary" />
                        <div>
                          <p className="text-sm text-hr-text-secondary">Phone</p>
                          <p className="font-medium">{company.phone}</p>
                        </div>
                      </div>
                    )}
                    {company.address && (
                      <div className="flex items-center gap-3">
                        <MapPin className="w-4 h-4 text-hr-text-secondary" />
                        <div>
                          <p className="text-sm text-hr-text-secondary">Address</p>
                          <p className="font-medium">{company.address}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold text-hr-text-primary mb-3">Legal Information</h3>
                  <div className="space-y-3">
                    {company.type && (
                      <div>
                        <p className="text-sm text-hr-text-secondary">Company Type</p>
                        <p className="font-medium capitalize">{company.type.replace('_', ' ')}</p>
                      </div>
                    )}
                    {company.gstPan && (
                      <div>
                        <p className="text-sm text-hr-text-secondary">GST/PAN</p>
                        <p className="font-medium">{company.gstPan}</p>
                      </div>
                    )}
                    {company.pfNo && (
                      <div>
                        <p className="text-sm text-hr-text-secondary">PF Number</p>
                        <p className="font-medium">{company.pfNo}</p>
                      </div>
                    )}
                    {company.esicNo && (
                      <div>
                        <p className="text-sm text-hr-text-secondary">ESIC Number</p>
                        <p className="font-medium">{company.esicNo}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Status Message */}
            {company.status === 'pending' && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-yellow-800">Approval Pending</h4>
                    <p className="text-sm text-yellow-700 mt-1">
                      Your company registration is currently being reviewed by our system administrators. 
                      This process typically takes 1-2 business days. You will receive an email notification once approved.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {company.status === 'approved' && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-green-800">Company Approved!</h4>
                    <p className="text-sm text-green-700 mt-1">
                      Congratulations! Your company has been approved and verified. You can now access all administrative features.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {company.status === 'rejected' && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className="w-5 h-5 bg-red-600 rounded-full flex items-center justify-center mt-0.5">
                    <span className="text-white text-xs">✗</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-red-800">Registration Rejected</h4>
                    <p className="text-sm text-red-700 mt-1">
                      Unfortunately, your company registration has been rejected. Please contact support for more information.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-4 pt-4">
              {company.profileComplete && company.status === 'pending' && (
                <Button disabled variant="outline" className="flex-1">
                  <Clock className="w-4 h-4 mr-2" />
                  Waiting for Approval
                </Button>
              )}
              
              {company.status === 'approved' && (
                <Link href="/" className="flex-1">
                  <Button className="w-full bg-hr-primary hover:bg-hr-primary/90">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Access Dashboard
                  </Button>
                </Link>
              )}

              {!company.profileComplete && (
                <Link href="/company-profile-setup" className="flex-1">
                  <Button className="w-full bg-hr-primary hover:bg-hr-primary/90">
                    Complete Profile
                  </Button>
                </Link>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}