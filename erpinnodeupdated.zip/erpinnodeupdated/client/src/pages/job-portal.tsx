import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { authService, apiRequestWithAuth } from "@/lib/auth";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { MapPin, Clock, DollarSign, Search, Filter, Calendar, Download, MessageCircle } from "lucide-react";
import { type Job } from "@shared/schema";

export default function JobPortal() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [locationFilter, setLocationFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [salaryOffer, setSalaryOffer] = useState("");
  const [showNegotiationDialog, setShowNegotiationDialog] = useState(false);
  const [selectedInterview, setSelectedInterview] = useState<any | null>(null);
  
  const user = authService.getUser();

  // Fetch public jobs (available jobs)
  const { data: publicJobs = [], isLoading: loadingJobs } = useQuery<Job[]>({
    queryKey: ['/api/jobs/public'],
    queryFn: async () => {
      const response = await fetch('/api/jobs/public');
      return response.json();
    },
  });

  // Fetch user's job applications
  const { data: myApplications = [], isLoading: loadingApplications } = useQuery({
    queryKey: ['/api/job-applications/my'],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', '/api/job-applications/my');
      return response.json();
    },
    enabled: !!user?.id,
  });

  // Fetch interviews
  const { data: interviews = [], isLoading: loadingInterviews } = useQuery({
    queryKey: ['/api/interviews/my'],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', '/api/interviews/my');
      return response.json();
    },
    enabled: !!user?.id,
  });

  // Apply for job mutation
  const applyJobMutation = useMutation({
    mutationFn: async (jobId: number) => {
      const response = await apiRequestWithAuth('POST', '/api/job-applications', {
        body: JSON.stringify({ jobId }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/job-applications/my'] });
      toast({
        title: "Success",
        description: "Application submitted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit application",
        variant: "destructive",
      });
    },
  });

  // Salary negotiation mutation
  const negotiateSalaryMutation = useMutation({
    mutationFn: async ({ interviewId, offerAmount }: { interviewId: number; offerAmount: string }) => {
      const response = await apiRequestWithAuth('POST', `/api/interviews/${interviewId}/negotiate`, {
        body: JSON.stringify({ offerAmount }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/interviews/my'] });
      setShowNegotiationDialog(false);
      setSalaryOffer("");
      setSelectedInterview(null);
      toast({
        title: "Success",
        description: "Salary negotiation submitted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit salary negotiation",
        variant: "destructive",
      });
    },
  });

  // Download offer letter function
  const downloadOfferLetter = async (interviewId: number, jobTitle: string) => {
    try {
      const response = await apiRequestWithAuth('GET', `/api/interviews/${interviewId}/offer-letter`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = url;
      a.download = `${jobTitle.replace(/\s+/g, '_')}_Offer_Letter.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download offer letter",
        variant: "destructive",
      });
    }
  };

  const handleNegotiateSalary = (interview: any) => {
    setSelectedInterview(interview);
    setShowNegotiationDialog(true);
  };

  const submitSalaryNegotiation = () => {
    if (selectedInterview && salaryOffer) {
      negotiateSalaryMutation.mutate({
        interviewId: selectedInterview.id,
        offerAmount: salaryOffer,
      });
    }
  };

  // Filter available jobs
  const filteredJobs = publicJobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLocation = !locationFilter || locationFilter === 'all' || job.location?.toLowerCase().includes(locationFilter.toLowerCase());
    const matchesType = !typeFilter || typeFilter === 'all' || job.employmentType?.toLowerCase() === typeFilter.toLowerCase();
    return matchesSearch && matchesLocation && matchesType;
  });

  const formatDate = (date: string | Date | null) => {
    if (!date) return 'N/A';
    return new Date(date).toLocaleDateString();
  };

  const formatSalary = (min: string | number | null, max: string | number | null) => {
    const minVal = min ? String(min) : null;
    const maxVal = max ? String(max) : null;
    if (!minVal && !maxVal) return 'Not specified';
    if (minVal && maxVal) return `$${minVal} - $${maxVal}`;
    if (minVal) return `From $${minVal}`;
    if (maxVal) return `Up to $${maxVal}`;
    return 'Not specified';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      case 'reviewing':
        return 'bg-blue-100 text-blue-700';
      case 'interviewed':
        return 'bg-purple-100 text-purple-700';
      case 'accepted':
        return 'bg-green-100 text-green-700';
      case 'rejected':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const isAlreadyApplied = (jobId: number) => {
    return myApplications.some((app: any) => app.jobId === jobId);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Job Portal</h1>
        <p className="text-muted-foreground">Explore opportunities and manage your applications</p>
      </div>

      <Tabs defaultValue="available" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="available">Available Jobs</TabsTrigger>
          <TabsTrigger value="applications">My Applications</TabsTrigger>
          <TabsTrigger value="interviews">Interviews</TabsTrigger>
        </TabsList>

        {/* Tab 1: Available Jobs */}
        <TabsContent value="available" className="space-y-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search jobs by title or description..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Select value={locationFilter} onValueChange={setLocationFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  <SelectItem value="remote">Remote</SelectItem>
                  <SelectItem value="onsite">On-site</SelectItem>
                  <SelectItem value="hybrid">Hybrid</SelectItem>
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Job Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="full-time">Full-time</SelectItem>
                  <SelectItem value="part-time">Part-time</SelectItem>
                  <SelectItem value="contract">Contract</SelectItem>
                  <SelectItem value="freelance">Freelance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {loadingJobs ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Loading jobs...</p>
            </div>
          ) : filteredJobs.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <p className="text-muted-foreground">
                  {searchQuery || locationFilter || typeFilter ? 'No jobs match your criteria.' : 'No job openings available.'}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredJobs.map((job) => (
                <Card key={job.id} className="shadow-sm hover:shadow-md transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg">{job.title}</CardTitle>
                    <CardDescription className="line-clamp-2">{job.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <MapPin size={16} />
                      <span>{job.location || 'Not specified'}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <DollarSign size={16} />
                      <span>{formatSalary(job.salaryMin, job.salaryMax)}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <Clock size={16} />
                      <span>{job.employmentType || 'Full-time'}</span>
                    </div>
                    {job.postedAt && (
                      <p className="text-xs text-muted-foreground">
                        Posted: {formatDate(job.postedAt)}
                      </p>
                    )}
                    <div className="pt-2">
                      {isAlreadyApplied(job.id) ? (
                        <Button variant="outline" disabled className="w-full">
                          Already Applied
                        </Button>
                      ) : (
                        <Button 
                          onClick={() => applyJobMutation.mutate(job.id)}
                          disabled={applyJobMutation.isPending}
                          className="w-full"
                        >
                          {applyJobMutation.isPending ? 'Applying...' : 'Apply Now'}
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Tab 2: My Applications */}
        <TabsContent value="applications" className="space-y-6">
          {loadingApplications ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Loading applications...</p>
            </div>
          ) : myApplications.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <p className="text-muted-foreground">No job applications yet. Start applying to jobs!</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {myApplications.map((application: any) => (
                <Card key={application.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{application.job?.title || 'Job Title'}</CardTitle>
                        <CardDescription>Applied on {formatDate(application.appliedAt)}</CardDescription>
                      </div>
                      <Badge className={getStatusColor(application.status)}>
                        {application.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <MapPin size={16} />
                        <span>{application.job?.location || 'Not specified'}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                        <DollarSign size={16} />
                        <span>{formatSalary(application.job?.salaryMin, application.job?.salaryMax)}</span>
                      </div>
                      {application.notes && (
                        <p className="text-sm text-muted-foreground mt-2">
                          Notes: {application.notes}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Tab 3: Interviews */}
        <TabsContent value="interviews" className="space-y-6">
          {loadingInterviews ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">Loading interviews...</p>
            </div>
          ) : interviews.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <p className="text-muted-foreground">No interviews scheduled yet.</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {interviews.map((interview: any) => (
                <Card key={interview.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{interview.job?.title || 'Interview'}</CardTitle>
                        <CardDescription>
                          <div className="flex items-center space-x-2">
                            <Calendar size={16} />
                            <span>{formatDate(interview.scheduledAt)}</span>
                          </div>
                        </CardDescription>
                      </div>
                      <Badge className={getStatusColor(interview.status)}>
                        {interview.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-sm space-y-1">
                        <p><strong>Type:</strong> {interview.type || 'Not specified'}</p>
                        <p><strong>Duration:</strong> {interview.duration || 'Not specified'}</p>
                        {interview.location && (
                          <p><strong>Location:</strong> {interview.location}</p>
                        )}
                        {interview.notes && (
                          <p><strong>Notes:</strong> {interview.notes}</p>
                        )}
                      </div>
                      
                      <div className="flex gap-2 pt-2">
                        {interview.status === 'scheduled' && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleNegotiateSalary(interview)}
                          >
                            <MessageCircle size={16} className="mr-2" />
                            Negotiate Salary
                          </Button>
                        )}
                        
                        {(interview.status === 'completed' || interview.status === 'offered') && (
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => downloadOfferLetter(interview.id, interview.job?.title || 'Job_Offer')}
                          >
                            <Download size={16} className="mr-2" />
                            Download Offer Letter
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Salary Negotiation Dialog */}
      <Dialog open={showNegotiationDialog} onOpenChange={setShowNegotiationDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Salary Negotiation</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Current offer: {selectedInterview ? formatSalary(selectedInterview.job?.salaryMin, selectedInterview.job?.salaryMax) : 'Not specified'}
            </p>
            <div className="space-y-2">
              <label className="text-sm font-medium">Your Expected Salary</label>
              <Input 
                placeholder="Enter your expected salary amount..."
                value={salaryOffer}
                onChange={(e) => setSalaryOffer(e.target.value)}
                type="number"
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={submitSalaryNegotiation}
                disabled={!salaryOffer || negotiateSalaryMutation.isPending}
                className="flex-1"
              >
                {negotiateSalaryMutation.isPending ? 'Submitting...' : 'Submit Counter Offer'}
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowNegotiationDialog(false);
                  setSalaryOffer("");
                  setSelectedInterview(null);
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}