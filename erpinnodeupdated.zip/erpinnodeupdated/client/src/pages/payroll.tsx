import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { Plus, Eye, DollarSign, Users, Calendar, CheckCircle2, XCircle, Clock, Download, FileText, Send } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface MonthlyPayroll {
  id: number;
  month: number;
  year: number;
  status: 'draft' | 'finalized';
  recordCount: number;
  totalAmount: number;
  createdAt: string;
  finalizedAt?: string;
}

interface PayrollRecord {
  id: number;
  employeeCode: string;
  employeeName: string;
  department: string;
  presentDays: number;
  payableDays: number;
  grossSalary: string;
  totalDeductions: string;
  netSalary: string;
  paymentStatus: 'unpaid' | 'paid' | 'partially_paid';
  paidAmount?: string;
  paymentDate?: string;
  paymentMethod?: string;
}

interface Payslip {
  id: number;
  payrollRecordId: number;
  employeeId: number;
  employeeName: string;
  employeeCode: string;
  payslipNumber: string;
  month: number;
  year: number;
  status: 'generated' | 'viewed' | 'downloaded' | 'delivered';
  grossPay?: number;
  netPay?: number;
  totalDeductions?: number;
  totalEarnings?: number;
  createdAt: string;
  viewedAt?: string;
  downloadedAt?: string;
  emailedAt?: string;
  pdfPath?: string;
}

export default function PayrollPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedPayroll, setSelectedPayroll] = useState<MonthlyPayroll | null>(null);
  const [generateDialogOpen, setGenerateDialogOpen] = useState(false);
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<PayrollRecord | null>(null);
  const [filterMonth, setFilterMonth] = useState<number | null>(null);
  const [filterYear, setFilterYear] = useState<number | null>(null);
  const [generateForm, setGenerateForm] = useState({
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear()
  });
  const [paymentForm, setPaymentForm] = useState({
    status: 'paid',
    amount: '',
    method: 'bank_transfer',
    reference: ''
  });
  const [activeTab, setActiveTab] = useState('overview');
  const [generatePayslipDialogOpen, setGeneratePayslipDialogOpen] = useState(false);

  // Get current user's company ID using proper auth hook
  const { user, isAuthenticated } = useAuth();
  const userLoading = false; // No loading state needed for localStorage-based auth

  const companyId = user?.companyId;

  // Fetch monthly payrolls
  const { data: payrolls = [], isLoading: payrollsLoading, refetch: refetchPayrolls, error: payrollsError } = useQuery<MonthlyPayroll[]>({
    queryKey: ['payroll-monthly', companyId],
    queryFn: async () => {
      if (!companyId) throw new Error('No company ID');
      const response = await apiRequest('GET', `/api/payroll/monthly/${companyId}`);
      return response.json();
    },
    enabled: !!companyId
  });


  // Fetch payroll records for selected payroll
  const { data: payrollRecords = [], isLoading: recordsLoading } = useQuery<PayrollRecord[]>({
    queryKey: [`/api/payroll/records/${selectedPayroll?.id}`],
    enabled: !!selectedPayroll,
  });

  // Fetch payslips for selected payroll
  const { data: payslips = [], isLoading: payslipsLoading, refetch: refetchPayslips } = useQuery<Payslip[]>({
    queryKey: ['payslips', selectedPayroll?.id],
    queryFn: async () => {
      if (!selectedPayroll?.id) throw new Error('No payroll selected');
      const response = await apiRequest('GET', `/api/payslips/${selectedPayroll.id}`);
      return response.json();
    },
    enabled: !!selectedPayroll && selectedPayroll.status === 'finalized',
  });

  // Generate payroll mutation
  const generatePayrollMutation = useMutation({
    mutationFn: async (data: { month: number; year: number }) => {
      const response = await apiRequest('POST', '/api/payroll/generate', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Payroll generated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['payroll-monthly', companyId] });
      setGenerateDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate payroll",
        variant: "destructive",
      });
    },
  });

  // Finalize payroll mutation
  const finalizePayrollMutation = useMutation({
    mutationFn: async (payrollId: number) => {
      const response = await apiRequest('PUT', `/api/payroll/finalize/${payrollId}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Payroll finalized successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['payroll-monthly', companyId] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to finalize payroll",
        variant: "destructive",
      });
    },
  });

  // Delete payroll mutation
  const deletePayrollMutation = useMutation({
    mutationFn: async (payrollId: number) => {
      const response = await apiRequest('DELETE', `/api/payroll/monthly/${payrollId}`);
      // For delete operations, we don't need to parse JSON response
      if (!response.ok) {
        throw new Error('Failed to delete payroll');
      }
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Payroll deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['payroll-monthly', companyId] });
      setSelectedPayroll(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete payroll",
        variant: "destructive",
      });
    },
  });

  // Update payment status mutation
  const updatePaymentMutation = useMutation({
    mutationFn: async (data: {
      recordId: number;
      status: string;
      amount?: number;
      method?: string;
      reference?: string;
    }) => {
      const response = await apiRequest('PUT', `/api/payroll/payment/${data.recordId}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Payment status updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/payroll/records/${selectedPayroll?.id}`] });
      setPaymentDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update payment status",
        variant: "destructive",
      });
    },
  });

  // Generate payslips mutation
  const generatePayslipsMutation = useMutation({
    mutationFn: async (payrollId: number) => {
      const response = await apiRequest('POST', '/api/payslips/generate', { payrollId });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: `Generated ${data.payslips?.length || 0} payslips successfully`,
      });
      refetchPayslips();
      setGeneratePayslipDialogOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to generate payslips",
        variant: "destructive",
      });
    },
  });

  const handleGeneratePayroll = () => {
    generatePayrollMutation.mutate(generateForm);
  };

  const handleFinalizePayroll = (payrollId: number) => {
    finalizePayrollMutation.mutate(payrollId);
  };

  const handleDeletePayroll = (payrollId: number) => {
    if (confirm('Are you sure you want to delete this payroll? This action cannot be undone.')) {
      deletePayrollMutation.mutate(payrollId);
    }
  };

  const handleUpdatePayment = () => {
    if (!selectedRecord) return;
    
    updatePaymentMutation.mutate({
      recordId: selectedRecord.id,
      status: paymentForm.status,
      amount: paymentForm.status === 'paid' ? parseFloat(paymentForm.amount) : undefined,
      method: paymentForm.status === 'paid' ? paymentForm.method : undefined,
      reference: paymentForm.status === 'paid' ? paymentForm.reference : undefined,
    });
  };

  const handleGeneratePayslips = () => {
    if (!selectedPayroll) return;
    generatePayslipsMutation.mutate(selectedPayroll.id);
  };

  const handleDownloadPayslip = async (payslipId: number) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/payslips/download/${payslipId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (!response.ok) throw new Error('Failed to download payslip');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `payslip_${payslipId}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Success",
        description: "Payslip downloaded successfully",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to download payslip",
        variant: "destructive",
      });
    }
  };

  const openPaymentDialog = (record: PayrollRecord) => {
    setSelectedRecord(record);
    setPaymentForm({
      status: record.paymentStatus,
      amount: record.paidAmount || record.netSalary,
      method: record.paymentMethod || 'bank_transfer',
      reference: ''
    });
    setPaymentDialogOpen(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'draft':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Draft</Badge>;
      case 'finalized':
        return <Badge variant="default"><CheckCircle2 className="w-3 h-3 mr-1" />Finalized</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPaymentStatusBadge = (status: string) => {
    switch (status) {
      case 'unpaid':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Unpaid</Badge>;
      case 'paid':
        return <Badge variant="default"><CheckCircle2 className="w-3 h-3 mr-1" />Paid</Badge>;
      case 'partially_paid':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Partial</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getPayslipStatusBadge = (status: string) => {
    switch (status) {
      case 'generated':
        return <Badge variant="secondary"><FileText className="w-3 h-3 mr-1" />Generated</Badge>;
      case 'viewed':
        return <Badge variant="default"><Eye className="w-3 h-3 mr-1" />Viewed</Badge>;
      case 'downloaded':
        return <Badge variant="default"><Download className="w-3 h-3 mr-1" />Downloaded</Badge>;
      case 'delivered':
        return <Badge variant="default"><Send className="w-3 h-3 mr-1" />Delivered</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatCurrency = (amount: string | number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(typeof amount === 'string' ? parseFloat(amount) : amount);
  };

  const getMonthName = (month: number) => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return months[month - 1];
  };

  const handleExportToExcel = () => {
    if (!companyId) {
      toast({
        title: "Error",
        description: "Company ID not found. Please try again.",
        variant: "destructive",
      });
      return;
    }
    
    const year = filterYear || new Date().getFullYear();
    const month = filterMonth || new Date().getMonth() + 1;
    const token = localStorage.getItem('token');
    const url = `/api/payroll/export/${companyId}/${year}/${month}`;
    
    // Create a temporary link with auth header
    fetch(url, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    .then(response => response.blob())
    .then(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `payroll_${year}_${month}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    })
    .catch(error => {
      toast({
        title: "Error",
        description: "Failed to export payroll data",
        variant: "destructive",
      });
    });
  };

  // Ensure payrolls is an array before filtering
  const payrollsArray = Array.isArray(payrolls) ? payrolls : [];
  
  // Filter payrolls based on month/year selection
  const filteredPayrolls = payrollsArray.filter((payroll: MonthlyPayroll) => {
    if (filterMonth && payroll.month !== filterMonth) return false;
    if (filterYear && payroll.year !== filterYear) return false;
    return true;
  });

  // Get unique years and months for filter dropdowns
  const availableYears = Array.from(new Set(payrollsArray.map((p: MonthlyPayroll) => p.year))).sort((a, b) => b - a);
  const availableMonths = Array.from(new Set(payrollsArray.map((p: MonthlyPayroll) => p.month))).sort((a, b) => a - b);

  if (payrollsLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-sm text-gray-600">Loading payroll data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Monthly Payroll</h1>
          <p className="text-gray-600">Manage monthly payroll generation and payment tracking</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={handleExportToExcel} 
            variant="outline"
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export to Excel
          </Button>
          <Dialog open={generateDialogOpen} onOpenChange={setGenerateDialogOpen}>
            <Button onClick={() => refetchPayrolls()} variant="outline" className="mr-2">
              Refresh Data
            </Button>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Generate Payroll
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Generate Monthly Payroll</DialogTitle>
                <DialogDescription>
                  Select the month and year for payroll generation
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="month">Month</Label>
                    <Select value={generateForm.month.toString()} onValueChange={(value) => setGenerateForm(prev => ({ ...prev, month: parseInt(value) }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 12 }, (_, i) => (
                          <SelectItem key={i + 1} value={(i + 1).toString()}>
                            {getMonthName(i + 1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="year">Year</Label>
                    <Input
                      type="number"
                      value={generateForm.year}
                      onChange={(e) => setGenerateForm(prev => ({ ...prev, year: parseInt(e.target.value) }))}
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setGenerateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleGeneratePayroll} disabled={generatePayrollMutation.isPending}>
                    {generatePayrollMutation.isPending ? 'Generating...' : 'Generate'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs value={selectedPayroll ? activeTab : "overview"} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview" onClick={() => setSelectedPayroll(null)}>
            Payroll Overview
          </TabsTrigger>
          {selectedPayroll && (
            <>
              <TabsTrigger value="records">
                {getMonthName(selectedPayroll.month)} {selectedPayroll.year} Records
              </TabsTrigger>
              {selectedPayroll.status === 'finalized' && (
                <TabsTrigger value="payslips">
                  Payslips
                </TabsTrigger>
              )}
            </>
          )}
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Payrolls</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{filteredPayrolls.length}</div>
                <p className="text-xs text-muted-foreground">
                  Monthly payroll runs
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(filteredPayrolls.reduce((sum: number, p: MonthlyPayroll) => sum + p.totalAmount, 0))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Across all payrolls
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Records</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {filteredPayrolls.reduce((sum: number, p: MonthlyPayroll) => sum + p.recordCount, 0)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Employee records
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Monthly Payrolls</CardTitle>
              <CardDescription>
                Generated payroll runs by month and year
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <Select value={filterYear?.toString() || 'all'} onValueChange={(value) => setFilterYear(value === 'all' ? null : parseInt(value))}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Filter by year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Years</SelectItem>
                      {availableYears.map((year) => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={filterMonth?.toString() || 'all'} onValueChange={(value) => setFilterMonth(value === 'all' ? null : parseInt(value))}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Filter by month" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Months</SelectItem>
                      {availableMonths.map((month) => (
                        <SelectItem key={month} value={month.toString()}>
                          {getMonthName(month)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Period</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Records</TableHead>
                      <TableHead>Total Amount</TableHead>
                      <TableHead>Generated Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayrolls.map((payroll) => (
                      <TableRow key={payroll.id}>
                        <TableCell className="font-medium">
                          {getMonthName(payroll.month)} {payroll.year}
                        </TableCell>
                        <TableCell>
                          {getStatusBadge(payroll.status)}
                        </TableCell>
                        <TableCell>{payroll.recordCount}</TableCell>
                        <TableCell>{formatCurrency(payroll.totalAmount)}</TableCell>
                        <TableCell>{new Date(payroll.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedPayroll(payroll);
                                setActiveTab('records');
                              }}
                            >
                              <Eye className="w-4 h-4 mr-1" />
                              View Records
                            </Button>
                            {payroll.status === 'draft' && (
                              <>
                                <Button 
                                  variant="default" 
                                  size="sm"
                                  onClick={() => handleFinalizePayroll(payroll.id)}
                                  disabled={finalizePayrollMutation.isPending}
                                >
                                  Finalize
                                </Button>
                                <Button 
                                  variant="destructive" 
                                  size="sm"
                                  onClick={() => handleDeletePayroll(payroll.id)}
                                  disabled={deletePayrollMutation.isPending}
                                >
                                  Delete
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="records" className="space-y-6">
          {selectedPayroll && (
            <Card>
              <CardHeader>
                <CardTitle>
                  Payroll Records - {getMonthName(selectedPayroll.month)} {selectedPayroll.year}
                </CardTitle>
                <CardDescription>
                  Individual employee payroll records for this period
                </CardDescription>
              </CardHeader>
              <CardContent>
                {recordsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="mt-2 text-sm text-gray-600">Loading records...</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Present Days</TableHead>
                        <TableHead>Payable Days</TableHead>
                        <TableHead>Gross Salary</TableHead>
                        <TableHead>Deductions</TableHead>
                        <TableHead>Net Salary</TableHead>
                        <TableHead>Payment Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {payrollRecords.map((record) => (
                        <TableRow key={record.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{record.employeeName}</div>
                              <div className="text-sm text-gray-500">{record.employeeCode}</div>
                            </div>
                          </TableCell>
                          <TableCell>{record.department}</TableCell>
                          <TableCell>{record.presentDays}</TableCell>
                          <TableCell>{record.payableDays}</TableCell>
                          <TableCell>{formatCurrency(record.grossSalary)}</TableCell>
                          <TableCell>{formatCurrency(record.totalDeductions)}</TableCell>
                          <TableCell className="font-medium">{formatCurrency(record.netSalary)}</TableCell>
                          <TableCell>{getPaymentStatusBadge(record.paymentStatus)}</TableCell>
                          <TableCell>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => openPaymentDialog(record)}
                            >
                              Update Payment
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="payslips" className="space-y-6">
          {selectedPayroll && (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>
                      Payslips - {getMonthName(selectedPayroll.month)} {selectedPayroll.year}
                    </CardTitle>
                    <CardDescription>
                      Generated payslips for employees in this payroll period
                    </CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {payslips.length === 0 && (
                      <Dialog open={generatePayslipDialogOpen} onOpenChange={setGeneratePayslipDialogOpen}>
                        <DialogTrigger asChild>
                          <Button>
                            <FileText className="w-4 h-4 mr-2" />
                            Generate Payslips
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Generate Payslips</DialogTitle>
                            <DialogDescription>
                              Generate payslips for all employees in {getMonthName(selectedPayroll.month)} {selectedPayroll.year} payroll.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <p className="text-sm text-gray-600">
                              This will generate payslips for all {payrollRecords.length} employees in this payroll period.
                            </p>
                            <div className="flex justify-end space-x-2">
                              <Button variant="outline" onClick={() => setGeneratePayslipDialogOpen(false)}>
                                Cancel
                              </Button>
                              <Button 
                                onClick={handleGeneratePayslips} 
                                disabled={generatePayslipsMutation.isPending}
                              >
                                {generatePayslipsMutation.isPending ? 'Generating...' : 'Generate Payslips'}
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {payslipsLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="mt-2 text-sm text-gray-600">Loading payslips...</p>
                  </div>
                ) : payslips.length === 0 ? (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No Payslips Generated</h3>
                    <p className="text-gray-600 mb-4">
                      Generate payslips for all employees in this payroll period.
                    </p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Employee</TableHead>
                        <TableHead>Payslip Number</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Generated Date</TableHead>
                        <TableHead>Last Activity</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {payslips.map((payslip) => (
                        <TableRow key={payslip.id}>
                          <TableCell>
                            <div>
                              <div className="font-medium">{payslip.employeeName}</div>
                              <div className="text-sm text-gray-500">{payslip.employeeCode}</div>
                            </div>
                          </TableCell>
                          <TableCell className="font-mono text-sm">{payslip.payslipNumber}</TableCell>
                          <TableCell>{getPayslipStatusBadge(payslip.status)}</TableCell>
                          <TableCell>{new Date(payslip.createdAt).toLocaleDateString()}</TableCell>
                          <TableCell>
                            {payslip.emailedAt && (
                              <div className="text-sm text-gray-600">
                                Emailed: {new Date(payslip.emailedAt).toLocaleDateString()}
                              </div>
                            )}
                            {payslip.downloadedAt && (
                              <div className="text-sm text-gray-600">
                                Downloaded: {new Date(payslip.downloadedAt).toLocaleDateString()}
                              </div>
                            )}
                            {payslip.viewedAt && (
                              <div className="text-sm text-gray-600">
                                Viewed: {new Date(payslip.viewedAt).toLocaleDateString()}
                              </div>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleDownloadPayslip(payslip.id)}
                              >
                                <Download className="w-4 h-4 mr-1" />
                                Download
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Payment Status Dialog */}
      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Payment Status</DialogTitle>
            <DialogDescription>
              Update payment status for {selectedRecord?.employeeName}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Payment Status</Label>
              <Select value={paymentForm.status} onValueChange={(value) => setPaymentForm(prev => ({ ...prev, status: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="unpaid">Unpaid</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="partially_paid">Partially Paid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {paymentForm.status === 'paid' && (
              <>
                <div>
                  <Label>Amount Paid</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={paymentForm.amount}
                    onChange={(e) => setPaymentForm(prev => ({ ...prev, amount: e.target.value }))}
                  />
                </div>
                <div>
                  <Label>Payment Method</Label>
                  <Select value={paymentForm.method} onValueChange={(value) => setPaymentForm(prev => ({ ...prev, method: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="cheque">Cheque</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Payment Reference</Label>
                  <Input
                    value={paymentForm.reference}
                    onChange={(e) => setPaymentForm(prev => ({ ...prev, reference: e.target.value }))}
                    placeholder="Transaction ID, Cheque Number, etc."
                  />
                </div>
              </>
            )}

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setPaymentDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleUpdatePayment} disabled={updatePaymentMutation.isPending}>
                {updatePaymentMutation.isPending ? 'Updating...' : 'Update'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}