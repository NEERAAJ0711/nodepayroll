import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  ArrowLeft, Plus, Eye, Calendar, CheckCircle, XCircle, Search, Download, 
  Clock, User, Briefcase, Phone, Mail, MapPin, FileText, Star
} from "lucide-react";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";

export default function RecruitmentDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedApplications, setSelectedApplications] = useState<number[]>([]);

  const { data: jobs = [] } = useQuery({
    queryKey: [`/api/jobs/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: jobApplications = [] } = useQuery({
    queryKey: [`/api/job-applications/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: interviews = [] } = useQuery({
    queryKey: [`/api/interviews/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const { data: jobOffers = [] } = useQuery({
    queryKey: [`/api/job-offers/${user?.companyId}`],
    enabled: !!user?.companyId,
  });

  const updateApplicationMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: string }) => {
      return await apiRequest('PUT', `/api/job-applications/${id}/status`, { status });
    },
    onSuccess: () => {
      toast({ title: "Application status updated successfully!" });
      queryClient.invalidateQueries({ queryKey: [`/api/job-applications/${user?.companyId}`] });
    },
    onError: () => {
      toast({ title: "Failed to update application status", variant: "destructive" });
    },
  });

  const scheduleInterviewMutation = useMutation({
    mutationFn: async (interviewData: any) => {
      return await apiRequest('POST', '/api/interviews', interviewData);
    },
    onSuccess: () => {
      toast({ title: "Interview scheduled successfully!" });
      queryClient.invalidateQueries({ queryKey: [`/api/interviews/${user?.companyId}`] });
    },
    onError: () => {
      toast({ title: "Failed to schedule interview", variant: "destructive" });
    },
  });

  const createOfferMutation = useMutation({
    mutationFn: async (offerData: any) => {
      return await apiRequest('POST', '/api/job-offers', offerData);
    },
    onSuccess: () => {
      toast({ title: "Job offer created successfully!" });
      queryClient.invalidateQueries({ queryKey: [`/api/job-offers/${user?.companyId}`] });
    },
    onError: () => {
      toast({ title: "Failed to create job offer", variant: "destructive" });
    },
  });

  const activeJobs = jobs.filter((job: any) => job.status === 'active');
  const newApplications = jobApplications.filter((app: any) => app.status === 'applied');
  const underReview = jobApplications.filter((app: any) => app.status === 'under_review');
  const todayInterviews = interviews.filter((int: any) => 
    new Date(int.scheduledAt).toDateString() === new Date().toDateString()
  );

  // Candidate search functionality
  const handleCandidateSearch = () => {
    if (!searchQuery.trim()) {
      toast({ title: "Please enter search criteria", variant: "destructive" });
      return;
    }
    
    const filteredCandidates = jobApplications.filter((app: any) => 
      app.applicantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.applicantEmail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (app.coverLetter && app.coverLetter.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    
    toast({ 
      title: `Found ${filteredCandidates.length} candidates`, 
      description: `Matching search criteria: "${searchQuery}"` 
    });
  };

  const handleDownloadResumes = () => {
    const candidatesWithResumes = jobApplications.filter((app: any) => app.resume);
    if (candidatesWithResumes.length === 0) {
      toast({ title: "No resumes available to download", variant: "destructive" });
      return;
    }
    
    toast({ 
      title: `Downloading ${candidatesWithResumes.length} resumes`, 
      description: "Resume files will be prepared for download" 
    });
  };

  // Bulk actions functionality
  const handleBulkAccept = () => {
    if (selectedApplications.length === 0) {
      toast({ title: "No applications selected", variant: "destructive" });
      return;
    }
    
    selectedApplications.forEach(id => {
      updateApplicationMutation.mutate({ id, status: 'accepted' });
    });
    
    setSelectedApplications([]);
    toast({ title: `Accepted ${selectedApplications.length} applications` });
  };

  const handleBulkReject = () => {
    if (selectedApplications.length === 0) {
      toast({ title: "No applications selected", variant: "destructive" });
      return;
    }
    
    selectedApplications.forEach(id => {
      updateApplicationMutation.mutate({ id, status: 'rejected' });
    });
    
    setSelectedApplications([]);
    toast({ title: `Rejected ${selectedApplications.length} applications` });
  };

  const filteredApplications = selectedStatus === 'all' 
    ? jobApplications 
    : jobApplications.filter((app: any) => app.status === selectedStatus);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/admin">
          <Button variant="outline" size="sm">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Recruitment Center</h1>
          <p className="text-muted-foreground">
            Complete recruitment management system
          </p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-hr-primary">{activeJobs.length}</div>
            <p className="text-xs text-muted-foreground">
              {jobs.filter((j: any) => j.status === 'draft').length} in draft
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">New Applications</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{newApplications.length}</div>
            <p className="text-xs text-muted-foreground">
              {underReview.length} under review
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Interviews</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{todayInterviews.length}</div>
            <p className="text-xs text-muted-foreground">
              {interviews.filter((int: any) => int.status === 'scheduled').length} scheduled
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Offers</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{jobOffers.filter((offer: any) => offer.status === 'pending').length}</div>
            <p className="text-xs text-muted-foreground">
              {jobOffers.filter((offer: any) => offer.status === 'accepted').length} accepted
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Actions */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-hr-primary" />
              Post New Job
            </CardTitle>
            <CardDescription>Create and publish job openings</CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/jobs">
              <Button className="w-full bg-hr-primary hover:bg-hr-primary/90">
                <Plus className="mr-2 h-4 w-4" />
                Create Job Posting
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-blue-600" />
              Candidate Search
            </CardTitle>
            <CardDescription>Find and download candidate resumes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex gap-2">
              <Input 
                placeholder="Search by name, email, skills..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleCandidateSearch()}
              />
              <Button size="sm" variant="outline" onClick={handleCandidateSearch}>
                <Search className="h-4 w-4" />
              </Button>
            </div>
            <Button className="w-full" variant="outline" onClick={handleDownloadResumes}>
              <Download className="mr-2 h-4 w-4" />
              Download All Resumes ({jobApplications.filter((app: any) => app.resume).length})
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-green-600" />
              Quick Actions
            </CardTitle>
            <CardDescription>Bulk operations and shortcuts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button 
              className="w-full justify-start" 
              size="sm" 
              variant="outline"
              onClick={handleBulkAccept}
              disabled={selectedApplications.length === 0}
            >
              <CheckCircle className="mr-2 h-4 w-4" />
              Bulk Accept ({selectedApplications.length} selected)
            </Button>
            <Button 
              className="w-full justify-start" 
              size="sm" 
              variant="outline"
              onClick={handleBulkReject}
              disabled={selectedApplications.length === 0}
            >
              <XCircle className="mr-2 h-4 w-4" />
              Bulk Reject ({selectedApplications.length} selected)
            </Button>
            <Link href="/jobs">
              <Button className="w-full justify-start" size="sm" variant="outline">
                <Briefcase className="mr-2 h-4 w-4" />
                Manage Job Postings
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      {/* Recruitment Pipeline */}
      <Card>
        <CardHeader>
          <CardTitle>Recruitment Pipeline</CardTitle>
          <CardDescription>Track applications through the hiring process</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedStatus} onValueChange={setSelectedStatus}>
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="all">All ({jobApplications.length})</TabsTrigger>
              <TabsTrigger value="applied">New ({newApplications.length})</TabsTrigger>
              <TabsTrigger value="under_review">Review ({underReview.length})</TabsTrigger>
              <TabsTrigger value="interviewed">Interviewed</TabsTrigger>
              <TabsTrigger value="offered">Offered</TabsTrigger>
              <TabsTrigger value="hired">Hired</TabsTrigger>
            </TabsList>
            
            <TabsContent value={selectedStatus} className="mt-6">
              <div className="space-y-4">
                {filteredApplications.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No applications found
                  </div>
                ) : (
                  filteredApplications.map((application: any) => (
                    <Card key={application.id} className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-hr-primary/10 flex items-center justify-center">
                              <User className="h-5 w-5 text-hr-primary" />
                            </div>
                            <div>
                              <h3 className="font-semibold">{application.applicantName}</h3>
                              <p className="text-sm text-muted-foreground">{application.applicantEmail}</p>
                            </div>
                            <Badge variant={
                              application.status === 'applied' ? 'default' :
                              application.status === 'under_review' ? 'secondary' :
                              application.status === 'hired' ? 'default' : 'outline'
                            }>
                              {application.status.replace('_', ' ')}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Briefcase className="h-3 w-3" />
                              {jobs.find((job: any) => job.id === application.jobId)?.title}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              Applied {new Date(application.appliedAt).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm" variant="outline">
                                <Eye className="mr-1 h-3 w-3" />
                                View
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Application Details</DialogTitle>
                                <DialogDescription>
                                  {application.applicantName} - {jobs.find((job: any) => job.id === application.jobId)?.title}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Cover Letter</Label>
                                  <p className="text-sm mt-1">{application.coverLetter || "No cover letter provided"}</p>
                                </div>
                                <div>
                                  <Label>Resume</Label>
                                  <Button size="sm" variant="outline" className="mt-1">
                                    <Download className="mr-1 h-3 w-3" />
                                    Download Resume
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>

                          <Select 
                            value={application.status} 
                            onValueChange={(status) => updateApplicationMutation.mutate({ id: application.id, status })}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="applied">Applied</SelectItem>
                              <SelectItem value="under_review">Under Review</SelectItem>
                              <SelectItem value="interviewed">Interviewed</SelectItem>
                              <SelectItem value="offered">Offered</SelectItem>
                              <SelectItem value="hired">Hired</SelectItem>
                              <SelectItem value="rejected">Rejected</SelectItem>
                            </SelectContent>
                          </Select>

                          <Dialog>
                            <DialogTrigger asChild>
                              <Button size="sm">
                                <Calendar className="mr-1 h-3 w-3" />
                                Schedule
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Schedule Interview</DialogTitle>
                                <DialogDescription>
                                  Schedule an interview for {application.applicantName}
                                </DialogDescription>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Date & Time</Label>
                                  <Input type="datetime-local" />
                                </div>
                                <div>
                                  <Label>Duration (minutes)</Label>
                                  <Input type="number" defaultValue="60" />
                                </div>
                                <div>
                                  <Label>Location/Link</Label>
                                  <Input placeholder="Meeting room or video link" />
                                </div>
                              </div>
                              <DialogFooter>
                                <Button>Schedule Interview</Button>
                              </DialogFooter>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}