import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Users, Building2, Shield, Activity, TrendingUp, AlertCircle } from "lucide-react";

export default function SystemAdminDashboard() {
  const { data: companies = [] } = useQuery({
    queryKey: ['/api/admin/companies'],
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['/api/users'],
  });

  const { data: permissionRequests = [] } = useQuery({
    queryKey: ['/api/permission-requests'],
  });

  const { data: activities = [] } = useQuery({
    queryKey: ['/api/activities'],
  });

  const totalUsers = allUsers.length;
  const activeCompanies = companies.filter((c: any) => c.status === 'active').length;
  const pendingRequests = permissionRequests.filter((r: any) => r.status === 'pending').length;
  const recentActivities = activities.slice(0, 10);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">System Administration</h1>
          <p className="text-muted-foreground">
            Manage all companies, users, and system-wide settings
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/admin/companies">
            <Button>
              <Building2 className="mr-2 h-4 w-4" />
              Manage Companies
            </Button>
          </Link>
          <Link href="/admin/users">
            <Button variant="outline">
              <Users className="mr-2 h-4 w-4" />
              Manage Users
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Companies</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{companies.length}</div>
            <p className="text-xs text-muted-foreground">
              {activeCompanies} active
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalUsers}</div>
            <p className="text-xs text-muted-foreground">
              Across all companies
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Requests</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingRequests}</div>
            <p className="text-xs text-muted-foreground">
              Permission requests
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">System Health</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">Healthy</div>
            <p className="text-xs text-muted-foreground">
              All systems operational
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Companies Overview
            </CardTitle>
            <CardDescription>
              Quick overview of all registered companies
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {companies.slice(0, 5).map((company: any) => (
              <div key={company.id} className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{company.name}</p>
                  <p className="text-sm text-muted-foreground">{company.email}</p>
                </div>
                <Badge variant={company.status === 'active' ? 'default' : 'secondary'}>
                  {company.status}
                </Badge>
              </div>
            ))}
            {companies.length > 5 && (
              <div className="text-center">
                <Link href="/admin/companies">
                  <Button variant="outline" size="sm">
                    View All Companies
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Permission Requests
            </CardTitle>
            <CardDescription>
              Recent permission requests requiring review
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingRequests > 0 ? (
              permissionRequests
                .filter((r: any) => r.status === 'pending')
                .slice(0, 5)
                .map((request: any) => (
                  <div key={request.id} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{request.permissionType.replace('_', ' ')}</p>
                      <p className="text-sm text-muted-foreground">
                        User ID: {request.userId}
                      </p>
                    </div>
                    <Badge variant="outline">Pending</Badge>
                  </div>
                ))
            ) : (
              <p className="text-center text-muted-foreground py-4">
                No pending permission requests
              </p>
            )}
            {pendingRequests > 5 && (
              <div className="text-center">
                <Link href="/admin/permissions">
                  <Button variant="outline" size="sm">
                    View All Requests
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Recent System Activity
            </CardTitle>
            <CardDescription>
              Latest actions performed across all companies
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentActivities.length > 0 ? (
              recentActivities.map((activity: any) => (
                <div key={activity.id} className="flex items-start justify-between border-l-2 border-blue-500 pl-4">
                  <div>
                    <p className="font-medium">{activity.action.replace('_', ' ')}</p>
                    <p className="text-sm text-muted-foreground">{activity.details}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(activity.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <Badge variant="outline" className="ml-2">
                    {activity.entityType}
                  </Badge>
                </div>
              ))
            ) : (
              <p className="text-center text-muted-foreground py-4">
                No recent activities
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}