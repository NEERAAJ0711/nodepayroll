import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Shield, Users, Settings, FileText, CheckCircle, XCircle, Clock, Plus, Trash2, Edit } from 'lucide-react';

interface Permission {
  id: number;
  name: string;
  description: string;
  category: string;
  module: string;
  isActive: boolean;
  createdAt: string;
}

interface PermissionRequest {
  id: number;
  userId: number;
  companyId: number;
  permissionType: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedBy: number;
  reviewedBy?: number;
  reviewedAt?: string;
  level1ReviewerId?: number;
  level1ReviewedAt?: string;
  level1Comments?: string;
  level2ReviewerId?: number;
  level2ReviewedAt?: string;
  level2Comments?: string;
  finalReviewerId?: number;
  finalReviewedAt?: string;
  finalComments?: string;
  createdAt: string;
  updatedAt: string;
}

interface UserPermission {
  id: number;
  userId: number;
  permissionId: number;
  companyId: number;
  grantedBy: number;
  grantedAt: string;
  isActive: boolean;
  reason?: string;
}

interface User {
  id: number;
  username: string;
  email: string;
  role: string;
  companyId: number;
  isActive: boolean;
}

export default function PermissionManagement() {
  const [activeTab, setActiveTab] = useState('permissions');
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [newPermissionDialog, setNewPermissionDialog] = useState(false);
  const [newRequestDialog, setNewRequestDialog] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get current user from localStorage
  const [currentUser, setCurrentUser] = useState<any>(null);
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      setCurrentUser({ id: payload.userId, role: payload.role, companyId: payload.companyId });
    }
  }, []);

  // Fetch permissions (with proper error handling for employees)
  const { data: permissions = [], isLoading: permissionsLoading } = useQuery<Permission[]>({
    queryKey: ['/api/permissions/enhanced'],
    retry: false,
    enabled: currentUser?.role !== 'employee', // Only load for non-employees
  });

  // Fetch permission requests
  const { data: permissionRequests = [], isLoading: requestsLoading } = useQuery<PermissionRequest[]>({
    queryKey: ['/api/permission-requests'],
    staleTime: 0, // Always consider data stale
  });

  // Fetch users for permission assignment
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['/api/users'],
  });

  // Fetch user permissions for selected user
  const { data: userPermissions = [], isLoading: userPermissionsLoading } = useQuery<UserPermission[]>({
    queryKey: ['/api/user-permissions', selectedUser],
    enabled: !!selectedUser,
  });

  // Create permission mutation
  const createPermissionMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/permissions/enhanced', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/permissions/enhanced'] });
      setNewPermissionDialog(false);
      toast({ title: 'Success', description: 'Permission created successfully' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to create permission', variant: 'destructive' });
    },
  });

  // Create permission request mutation
  const createRequestMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await fetch('/api/permission-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        const error = await response.text();
        throw new Error(error);
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/permission-requests'] });
      queryClient.refetchQueries({ queryKey: ['/api/permission-requests'] });
      setNewRequestDialog(false);
      toast({ title: 'Success', description: 'Permission request submitted successfully!' });
    },
    onError: (error: any) => {
      console.error('Permission request error:', error);
      toast({ title: 'Error', description: 'Failed to create permission request', variant: 'destructive' });
    },
  });

  // Approve permission request mutation
  const approveRequestMutation = useMutation({
    mutationFn: async ({ id, comments }: { id: number; comments?: string }) => {
      const response = await fetch(`/api/permission-requests/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ status: 'approved', reviewNotes: comments }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to approve request');
      }
      
      return response.json();
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['/api/permission-requests'] });
      await queryClient.refetchQueries({ queryKey: ['/api/permission-requests'] });
      toast({ title: 'Success', description: 'Permission request approved - Status updated!' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to approve request', variant: 'destructive' });
    },
  });

  // Reject permission request mutation
  const rejectRequestMutation = useMutation({
    mutationFn: async ({ id, comments }: { id: number; comments?: string }) => {
      const response = await fetch(`/api/permission-requests/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify({ status: 'rejected', reviewNotes: comments }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to reject request');
      }
      
      return response.json();
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['/api/permission-requests'] });
      await queryClient.refetchQueries({ queryKey: ['/api/permission-requests'] });
      toast({ title: 'Success', description: 'Permission request rejected - Status updated!' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to reject request', variant: 'destructive' });
    },
  });

  // Grant user permission mutation
  const grantPermissionMutation = useMutation({
    mutationFn: async (data: any) => {
      console.log('Granting permission:', data);
      const response = await apiRequest('POST', '/api/user-permissions', data);
      return response.json();
    },
    onSuccess: (result) => {
      console.log('Permission granted successfully:', result);
      queryClient.invalidateQueries({ queryKey: ['/api/user-permissions', selectedUser] });
      toast({ title: 'Success', description: 'Permission granted successfully' });
    },
    onError: (error) => {
      console.error('Failed to grant permission:', error);
      toast({ title: 'Error', description: 'Failed to grant permission', variant: 'destructive' });
    },
  });

  // Revoke user permission mutation
  const revokePermissionMutation = useMutation({
    mutationFn: async ({ userId, permissionId }: { userId: number; permissionId: number }) => {
      const response = await apiRequest('DELETE', `/api/user-permissions/${userId}/${permissionId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user-permissions', selectedUser] });
      toast({ title: 'Success', description: 'Permission revoked successfully' });
    },
    onError: () => {
      toast({ title: 'Error', description: 'Failed to revoke permission', variant: 'destructive' });
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const categories = [...new Set(permissions.map((p: Permission) => p.category))];
  const filteredPermissions = permissions.filter((permission: Permission) => {
    const matchesCategory = selectedCategory === 'all' || permission.category === selectedCategory;
    const matchesSearch = permission.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         permission.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  if (!currentUser) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Permission Management</h1>
          <p className="text-muted-foreground">
            {currentUser.role === 'employee' ? 'Request additional permissions from your administrator' : 'Manage user permissions and approval workflows'}
          </p>
        </div>
        <div className="flex gap-2">
          {currentUser.role === 'system_admin' && (
            <Dialog open={newPermissionDialog} onOpenChange={setNewPermissionDialog}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  New Permission
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Permission</DialogTitle>
                  <DialogDescription>
                    Define a new permission that can be assigned to users.
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  createPermissionMutation.mutate({
                    name: formData.get('name'),
                    description: formData.get('description'),
                    category: formData.get('category'),
                    module: formData.get('module'),
                    isActive: true,
                  });
                }}>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Permission Name</Label>
                      <Input id="name" name="name" required />
                    </div>
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Input id="description" name="description" required />
                    </div>
                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Input id="category" name="category" required />
                    </div>
                    <div>
                      <Label htmlFor="module">Module</Label>
                      <Input id="module" name="module" required />
                    </div>
                    <Button type="submit" disabled={createPermissionMutation.isPending}>
                      Create Permission
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          )}
          <Button 
            variant="outline" 
            className="bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
            onClick={() => {
              console.log('Request Permission button clicked!');
              setNewRequestDialog(true);
            }}
          >
            <FileText className="w-4 h-4 mr-2" />
            Request New Permission
          </Button>
          
          <Dialog open={newRequestDialog} onOpenChange={setNewRequestDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Request Permission</DialogTitle>
                <DialogDescription>
                  Submit a request for additional permissions.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const permissionType = formData.get('permissionType') as string;
                const reason = formData.get('reason') as string;
                
                if (!permissionType || !reason) {
                  toast({ title: "Error", description: "Please fill all fields", variant: "destructive" });
                  return;
                }
                
                createRequestMutation.mutate({
                  permissionType,
                  reason,
                });
              }}>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="permissionType">Permission Type</Label>
                    <Select name="permissionType" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select permission type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="employee_edit">Employee Edit - Edit employee information</SelectItem>
                        <SelectItem value="employee_create">Employee Create - Create new employee records</SelectItem>
                        <SelectItem value="employee_delete">Employee Delete - Delete employee records</SelectItem>
                        <SelectItem value="job_create">Job Create - Create new job postings</SelectItem>
                        <SelectItem value="job_edit">Job Edit - Edit existing job postings</SelectItem>
                        <SelectItem value="job_delete">Job Delete - Delete job postings</SelectItem>
                        <SelectItem value="department_create">Department Create - Create new departments</SelectItem>
                        <SelectItem value="department_edit">Department Edit - Edit department information</SelectItem>
                        <SelectItem value="company_settings">Company Settings - Access company settings</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="reason">Reason for Request</Label>
                    <Input id="reason" name="reason" required />
                  </div>
                  <Button 
                    type="submit" 
                    disabled={createRequestMutation.isPending}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    {createRequestMutation.isPending ? 'Submitting...' : 'Submit Permission Request'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Show different content based on user role */}
      {currentUser.role === 'employee' ? (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>My Permission Requests</CardTitle>
              <CardDescription>
                Track your submitted permission requests and their status
              </CardDescription>
            </CardHeader>
            <CardContent>
              {requestsLoading ? (
                <div>Loading requests...</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Permission Type</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {permissionRequests.map((request: PermissionRequest) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-medium">{request.permissionType}</TableCell>
                        <TableCell>{request.reason}</TableCell>
                        <TableCell>{getStatusBadge(request.status)}</TableCell>
                        <TableCell>{new Date(request.createdAt).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      ) : (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="permissions" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            Permissions
          </TabsTrigger>
          <TabsTrigger value="requests" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Requests
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            User Permissions
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Templates
          </TabsTrigger>
        </TabsList>

        <TabsContent value="permissions">
          <Card>
            <CardHeader>
              <CardTitle>System Permissions</CardTitle>
              <CardDescription>
                Manage all available permissions in the system
              </CardDescription>
              <div className="flex gap-4 items-center">
                <Input
                  placeholder="Search permissions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="max-w-sm"
                />
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {permissionsLoading ? (
                <div>Loading permissions...</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Module</TableHead>
                      <TableHead>Status</TableHead>
                      {currentUser.role === 'system_admin' && <TableHead>Actions</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPermissions.map((permission: Permission) => (
                      <TableRow key={permission.id}>
                        <TableCell className="font-medium">{permission.name}</TableCell>
                        <TableCell>{permission.description}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{permission.category}</Badge>
                        </TableCell>
                        <TableCell>{permission.module}</TableCell>
                        <TableCell>
                          <Badge variant={permission.isActive ? 'default' : 'secondary'}>
                            {permission.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        </TableCell>
                        {currentUser.role === 'system_admin' && (
                          <TableCell>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline">
                                <Edit className="w-3 h-3" />
                              </Button>
                              <Button size="sm" variant="outline">
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="requests">
          <Card>
            <CardHeader>
              <CardTitle>Permission Requests</CardTitle>
              <CardDescription>
                Review and manage permission requests from users
              </CardDescription>
            </CardHeader>
            <CardContent>
              {requestsLoading ? (
                <div>Loading requests...</div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Permission Type</TableHead>
                      <TableHead>Requested By</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created</TableHead>
                      {currentUser.role !== 'employee' && <TableHead>Actions</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {permissionRequests.map((request: PermissionRequest) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-medium">{request.permissionType}</TableCell>
                        <TableCell>User #{request.requestedBy}</TableCell>
                        <TableCell>{request.reason}</TableCell>
                        <TableCell>{getStatusBadge(request.status)}</TableCell>
                        <TableCell>{new Date(request.createdAt).toLocaleDateString()}</TableCell>
                        {currentUser.role !== 'employee' && (
                          <TableCell>
                            {request.status === 'pending' && (
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  onClick={() => approveRequestMutation.mutate({
                                    id: request.id,
                                    comments: 'Approved by admin'
                                  })}
                                  disabled={approveRequestMutation.isPending}
                                >
                                  <CheckCircle className="w-3 h-3 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => rejectRequestMutation.mutate({
                                    id: request.id,
                                    comments: 'Rejected by admin'
                                  })}
                                  disabled={rejectRequestMutation.isPending}
                                >
                                  <XCircle className="w-3 h-3 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        )}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Users</CardTitle>
                <CardDescription>Select a user to manage their permissions</CardDescription>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div>Loading users...</div>
                ) : (
                  <div className="space-y-2">
                    {users.map((user: User) => (
                      <div
                        key={user.id}
                        className={`p-3 border rounded-lg cursor-pointer transition-all duration-200 ${
                          selectedUser === user.id 
                            ? 'bg-blue-50 border-blue-300 shadow-sm' 
                            : 'hover:bg-gray-50 hover:border-gray-300'
                        }`}
                        onClick={() => setSelectedUser(user.id)}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="font-medium text-gray-900">{user.username}</p>
                            <p className="text-sm text-gray-600">{user.email}</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge 
                              variant="outline" 
                              className={user.role === 'admin' ? 'border-orange-200 text-orange-700' : 'border-blue-200 text-blue-700'}
                            >
                              {user.role}
                            </Badge>
                            {selectedUser === user.id && (
                              <div className="w-2 h-2 bg-blue-500 rounded-full" />
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>User Permissions</CardTitle>
                <CardDescription>
                  {selectedUser ? 'Manage permissions for selected user' : 'Select a user to view permissions'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedUser ? (
                  <div className="space-y-4">
                    {currentUser.role !== 'employee' && (
                      <div className="space-y-3">
                        <div className="flex gap-2">
                          <Select
                            onValueChange={(permissionId) => {
                              console.log('Selected permission ID:', permissionId);
                              console.log('Available permissions:', permissions);
                              console.log('Selected user:', selectedUser);
                              
                              const permission = permissions.find((p: Permission) => p.id === parseInt(permissionId));
                              console.log('Found permission:', permission);
                              
                              if (permission && selectedUser) {
                                const grantData = {
                                  userId: selectedUser,
                                  permissionId: permission.id,
                                  reason: 'Granted by admin'
                                };
                                console.log('About to grant permission with data:', grantData);
                                grantPermissionMutation.mutate(grantData);
                              } else {
                                console.error('Missing permission or selectedUser:', { permission, selectedUser });
                              }
                            }}
                            disabled={grantPermissionMutation.isPending}
                          >
                            <SelectTrigger className="flex-1">
                              <SelectValue placeholder={grantPermissionMutation.isPending ? "Granting permission..." : "Grant permission..."} />
                            </SelectTrigger>
                            <SelectContent>
                              {permissions.map((permission: Permission) => (
                                <SelectItem key={permission.id} value={permission.id.toString()}>
                                  <div className="flex flex-col">
                                    <span className="font-medium">{permission.name}</span>
                                    <span className="text-xs text-muted-foreground">{permission.description}</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Select a permission from the dropdown above to grant it to the selected user.
                        </p>
                      </div>
                    )}
                    
                    {userPermissionsLoading ? (
                      <div className="flex justify-center py-8">
                        <div className="text-center">
                          <div className="animate-pulse text-sm text-muted-foreground">Loading user permissions...</div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        <div className="text-sm font-medium text-gray-700">Current Permissions:</div>
                        {userPermissions.map((userPermission: UserPermission) => {
                          const permission = permissions.find((p: Permission) => p.id === userPermission.permissionId);
                          return (
                            <div key={userPermission.id} className="flex justify-between items-center p-3 border rounded-lg bg-green-50 border-green-200">
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <CheckCircle className="w-4 h-4 text-green-600" />
                                  <p className="font-medium text-gray-900">{permission?.name}</p>
                                </div>
                                <p className="text-sm text-gray-600 ml-6">{permission?.description}</p>
                                <p className="text-xs text-gray-500 ml-6">
                                  Granted on {new Date(userPermission.grantedAt).toLocaleDateString()}
                                </p>
                              </div>
                              {currentUser.role !== 'employee' && (
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => revokePermissionMutation.mutate({
                                    userId: selectedUser,
                                    permissionId: userPermission.permissionId
                                  })}
                                  disabled={revokePermissionMutation.isPending}
                                  className="ml-3"
                                >
                                  {revokePermissionMutation.isPending ? (
                                    <div className="w-3 h-3 animate-spin border border-white border-t-transparent rounded-full" />
                                  ) : (
                                    <Trash2 className="w-3 h-3" />
                                  )}
                                </Button>
                              )}
                            </div>
                          );
                        })}
                        {userPermissions.length === 0 && (
                          <div className="text-center py-8 border-2 border-dashed border-gray-200 rounded-lg">
                            <Shield className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                            <p className="text-muted-foreground font-medium">No permissions assigned to this user</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              Use the dropdown above to grant permissions
                            </p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    Select a user from the list to view and manage their permissions.
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="templates">
          <Card>
            <CardHeader>
              <CardTitle>Permission Templates</CardTitle>
              <CardDescription>
                Create and manage permission templates for quick assignment
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                Permission templates feature coming soon...
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        </Tabs>
      )}
    </div>
  );
}