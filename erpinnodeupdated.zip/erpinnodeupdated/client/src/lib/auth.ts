import { apiRequest } from "./queryClient";
import { type LoginData, type User } from "@shared/schema";
import { useState, useEffect } from "react";

interface AuthResponse {
  user: User;
  token: string;
}

interface AuthUser {
  id: number;
  email: string;
  username: string;
  role: 'system_admin' | 'admin' | 'employee';
  companyId: number | null;
}

class AuthService {
  private tokenKey = 'token';
  private userKey = 'user';

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  getUser(): AuthUser | null {
    const userData = localStorage.getItem(this.userKey);
    return userData ? JSON.parse(userData) : null;
  }

  setAuth(response: AuthResponse): void {
    localStorage.setItem(this.tokenKey, response.token);
    localStorage.setItem(this.userKey, JSON.stringify(response.user));
  }

  clearAuth(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
  }

  async login(credentials: LoginData): Promise<AuthResponse> {
    const response = await apiRequest('POST', '/api/auth/login', credentials);
    const data = await response.json();
    this.setAuth(data);
    return data;
  }

  async logout(): Promise<void> {
    this.clearAuth();
  }

  async getCurrentUser(): Promise<AuthUser> {
    const response = await apiRequest('GET', '/api/auth/me');
    const data = await response.json();
    return data.user;
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  hasRole(roles: string[]): boolean {
    const user = this.getUser();
    return user ? roles.includes(user.role) : false;
  }

  canAccessCompany(companyId: number): boolean {
    const user = this.getUser();
    if (!user) return false;
    if (user.role === 'system_admin') return true;
    return user.companyId === companyId;
  }

  // Check if user has specific permission (checking user_permissions table)
  async hasPermission(permissionType: string): Promise<boolean> {
    const user = this.getUser();
    if (!user) return false;
    
    // System admins have all permissions
    if (user.role === 'system_admin') return true;
    
    try {
      // Check user_permissions table for granted and active permissions
      const response = await fetch(`/api/user-permissions/${user.id}/check/${permissionType}`, {
        headers: {
          'Authorization': `Bearer ${this.getToken()}`,
        },
      });
      
      if (!response.ok) return false;
      
      const result = await response.json();
      return result.hasPermission || false;
    } catch (error) {
      console.error('Error checking permissions:', error);
      return false;
    }
  }
}

export const authService = new AuthService();

// Add authorization header to requests
const originalApiRequest = apiRequest;
export const apiRequestWithAuth = async (method: string, url: string, data?: unknown): Promise<Response> => {
  const token = authService.getToken();
  const headers: HeadersInit = data ? { "Content-Type": "application/json" } : {};
  
  if (token) {
    // Clean the token to ensure it doesn't have any extra characters
    const cleanToken = token.trim();
    headers["Authorization"] = `Bearer ${cleanToken}`;
    
    // Debug logging for job creation
    if (url.includes('/api/jobs') && method === 'POST') {
      console.log('Job creation request - Token length:', cleanToken.length);
      console.log('Job creation request - Token starts with:', cleanToken.substring(0, 20));
    }
  }

  const response = await fetch(url, {
    method,
    headers,
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  // Try to refresh token on auth failure for critical operations
  if (response.status === 401 && !response.url.includes('/login')) {
    console.log('Authentication failed for:', method, url);
    
    // For job creation, try to refresh current user and retry once
    if (url.includes('/api/jobs') && method === 'POST') {
      try {
        console.log('Attempting to refresh user session...');
        const refreshResponse = await fetch('/api/auth/me', {
          headers: { "Authorization": `Bearer ${authService.getToken()}` }
        });
        
        if (refreshResponse.ok) {
          console.log('Session refresh successful, retrying job creation...');
          // Retry the original request once
          const retryResponse = await fetch(url, {
            method,
            headers,
            body: data ? JSON.stringify(data) : undefined,
            credentials: "include",
          });
          
          if (retryResponse.ok) {
            return retryResponse;
          }
        }
      } catch (refreshError) {
        console.error('Session refresh failed:', refreshError);
      }
    }
    
    console.log('Final authentication failure, clearing auth');
    authService.clearAuth();
    window.location.href = '/login';
    return response;
  }

  if (!response.ok) {
    const text = (await response.text()) || response.statusText;
    throw new Error(`${response.status}: ${text}`);
  }

  return response;
};



// Hook for React components
export const useAuth = () => {
  const user = authService.getUser();
  const token = authService.getToken();
  const isAuthenticated = !!user && !!token;
  
  return {
    user,
    token,
    isAuthenticated,
    login: authService.login,
    logout: authService.logout,
    hasPermission: authService.hasPermission,
  };
};

// Permission checking hook for React components
export const usePermission = (permissionType: string) => {
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const { user } = useAuth();
  
  useEffect(() => {
    const checkPermission = async () => {
      if (!user) {
        setHasPermission(false);
        setLoading(false);
        return;
      }
      
      try {
        const permission = await authService.hasPermission(permissionType);
        setHasPermission(permission);
      } catch (error) {
        console.error('Permission check failed:', error);
        setHasPermission(false);
      } finally {
        setLoading(false);
      }
    };
    
    checkPermission();
  }, [permissionType, user]);
  
  return { hasPermission, loading };
};
