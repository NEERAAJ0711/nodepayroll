import { useLocation } from "wouter";
import { authService } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { apiRequestWithAuth } from "@/lib/auth";
import { Skeleton } from "@/components/ui/skeleton";
import DashboardLayout from "./dashboard-layout";
import AadhaarVerification from "@/pages/aadhaar-verification";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string[];
}

export default function ProtectedRoute({ children, requiredRoles }: ProtectedRouteProps) {
  const [, setLocation] = useLocation();

  // Check if user is authenticated
  if (!authService.isAuthenticated()) {
    setLocation('/login');
    return null;
  }

  // Verify token with server
  const { data: currentUser, isLoading, error } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', '/api/auth/me');
      return response.json();
    },
    retry: false,
  });

  // Check employee profile for Aadhaar verification (only for employees)
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/employee/profile'],
    enabled: !!currentUser?.user && currentUser.user.role === 'employee',
    retry: false,
  });

  // Also fetch KYC details to check Aadhaar
  const { data: kycDetails, isLoading: kycLoading } = useQuery({
    queryKey: ['/api/employee/kyc'],
    enabled: !!currentUser?.user && currentUser.user.role === 'employee' && !!profile?.id,
    retry: false,
  });

  if (isLoading || (currentUser?.user?.role === 'employee' && (profileLoading || kycLoading))) {
    return (
      <div className="min-h-screen bg-hr-background flex items-center justify-center">
        <div className="space-y-4">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-4 w-24" />
        </div>
      </div>
    );
  }

  if (error) {
    setLocation('/login');
    return null;
  }

  // Check role permissions
  if (requiredRoles && !authService.hasRole(requiredRoles)) {
    return (
      <div className="min-h-screen bg-hr-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-hr-text-primary">Access Denied</h2>
          <p className="text-hr-neutral mt-2">You don't have permission to access this page.</p>
        </div>
      </div>
    );
  }

  // Check if employee has verified Aadhaar (mandatory for all employees)
  if (currentUser?.user?.role === 'employee' && profile) {
    // Check KYC details for Aadhaar number
    const hasValidAadhaar = kycDetails && (kycDetails as any).aadharNo && (kycDetails as any).aadharNo.length === 12;
    if (!hasValidAadhaar) {
      return <AadhaarVerification />;
    }
  }

  return (
    <DashboardLayout>
      {children}
    </DashboardLayout>
  );
}
