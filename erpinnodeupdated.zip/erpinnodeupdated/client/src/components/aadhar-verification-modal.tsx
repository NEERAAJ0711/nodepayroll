import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Shield, CheckCircle } from "lucide-react";

interface AadharVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AadharVerificationModal({
  isOpen,
  onClose,
}: AadharVerificationModalProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [aadharNumber, setAadharNumber] = useState("");
  const [isVerified, setIsVerified] = useState(false);

  // Format Aadhar number with spaces (XXXX XXXX XXXX)
  const formatAadhar = (value: string) => {
    const cleaned = value.replace(/\s/g, "");
    const formatted = cleaned.replace(/(.{4})/g, "$1 ").trim();
    return formatted.substring(0, 14); // Limit to 12 digits + 2 spaces
  };

  const validateAadhar = (aadhar: string) => {
    const cleaned = aadhar.replace(/\s/g, "");
    return /^\d{12}$/.test(cleaned);
  };

  // Mock Aadhar verification API
  const verifyAadharMutation = useMutation({
    mutationFn: async (aadharNo: string) => {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock verification logic - in real implementation, this would call government API
      const cleaned = aadharNo.replace(/\s/g, "");
      
      // For demo: accept any 12-digit number, reject invalid formats
      if (!validateAadhar(aadharNo)) {
        throw new Error("Invalid Aadhar number format");
      }
      
      // Mock some random verification failures for demo
      if (cleaned === "000000000000" || cleaned === "111111111111") {
        throw new Error("Aadhar number not found in government database");
      }
      
      return {
        verified: true,
        name: "John Doe", // Mock name from Aadhar
        address: "Mock Address from Aadhar Database",
        dateOfBirth: "1990-01-01"
      };
    },
    onSuccess: (data) => {
      setIsVerified(true);
      toast({
        title: "Aadhar Verified Successfully",
        description: `Welcome ${data.name}! You can now proceed with employee registration.`,
      });
      
      // Auto-redirect after 2 seconds
      setTimeout(() => {
        onClose();
        setLocation('/admin/add-employee');
      }, 2000);
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateAadhar(aadharNumber)) {
      toast({
        title: "Invalid Aadhar Number",
        description: "Please enter a valid 12-digit Aadhar number",
        variant: "destructive",
      });
      return;
    }
    
    verifyAadharMutation.mutate(aadharNumber);
  };

  const handleAadharChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatAadhar(e.target.value);
    setAadharNumber(formatted);
  };

  const handleClose = () => {
    setAadharNumber("");
    setIsVerified(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isVerified ? (
              <CheckCircle className="h-5 w-5 text-green-600" />
            ) : (
              <Shield className="h-5 w-5 text-blue-600" />
            )}
            Aadhar Verification
          </DialogTitle>
          <DialogDescription>
            {isVerified
              ? "Your Aadhar has been successfully verified. Redirecting to employee registration..."
              : "Enter your 12-digit Aadhar number to verify your identity before creating an employee profile."
            }
          </DialogDescription>
        </DialogHeader>

        {!isVerified && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="aadhar">Aadhar Number *</Label>
              <Input
                id="aadhar"
                value={aadharNumber}
                onChange={handleAadharChange}
                placeholder="XXXX XXXX XXXX"
                maxLength={14}
                className="text-center text-lg tracking-wider font-mono"
                disabled={verifyAadharMutation.isPending}
                required
              />
              <p className="text-xs text-gray-500">
                Enter your 12-digit Aadhar number (spaces will be added automatically)
              </p>
            </div>

            <DialogFooter className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={verifyAadharMutation.isPending}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={verifyAadharMutation.isPending || !validateAadhar(aadharNumber)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {verifyAadharMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  "Verify Aadhar"
                )}
              </Button>
            </DialogFooter>
          </form>
        )}

        {isVerified && (
          <div className="text-center py-6">
            <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-green-700 mb-2">
              Verification Successful!
            </h3>
            <p className="text-gray-600 mb-4">
              Your identity has been verified. You will be redirected to the employee registration form shortly.
            </p>
            <div className="flex justify-center">
              <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}