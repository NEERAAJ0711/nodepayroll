import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Loader2, Calculator, Eye, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequestWithAuth } from '@/lib/auth';

interface SalaryStructureFormProps {
  companyId: number;
  employeeId: number;
  initialData?: any;
  onSave?: (data: any) => void;
}

interface SalaryComponent {
  componentKey: string;
  displayName: string;
  isTaxable: boolean;
  isEmployerCost: boolean;
  amount: number;
  calculatedFromPercentage: boolean;
}

interface SalaryCalculationResult {
  mode: 'gross' | 'ctc' | 'earning_heads';
  ctcValue: number;
  grossValue: number;
  components: SalaryComponent[];
  employerCosts: SalaryComponent[];
  configSnapshot: string;
}

type SalaryMode = 'gross' | 'ctc' | 'earning_heads';

export default function SalaryStructureForm({ companyId, employeeId, initialData, onSave }: SalaryStructureFormProps) {
  const { toast } = useToast();
  
  // Form state
  const [selectedMode, setSelectedMode] = useState<SalaryMode>('gross');
  const [grossAmount, setGrossAmount] = useState('');
  const [ctcAmount, setCtcAmount] = useState('');
  const [earningHeads, setEarningHeads] = useState<Record<string, string>>({});
  const [complianceSettings, setComplianceSettings] = useState({
    epfEnabled: true,
    esicEnabled: true,
    lwfEnabled: true,
    otEnabled: false,
    vpfEnabled: false,
    tdsEnabled: false,
    ptEnabled: false,
    bonusEnabled: true,
    pfLimit: false,
    pfLimitHigher: false,
    bonusMonthly: false,
  });

  // Additional fields for compliance values
  const [complianceValues, setComplianceValues] = useState({
    vpfPercentage: '',
    tdsPercentage: '',
    ptAmount: '',
  });

  // Real-time calculation preview
  const [previewData, setPreviewData] = useState<SalaryCalculationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  // Load salary components configuration
  const { data: salaryComponents } = useQuery({
    queryKey: ['/api/salary-components'],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', '/api/salary-components');
      return response.json();
    },
  });

  // Load company salary component configuration
  const { data: companyConfig } = useQuery({
    queryKey: [`/api/company-salary-config/${companyId}`, selectedMode],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/company-salary-config/${companyId}?entryMode=${selectedMode}`);
      return response.json();
    },
    enabled: !!companyId,
  });

  // Salary calculation preview mutation
  const calculatePreviewMutation = useMutation({
    mutationFn: async (data: { mode: SalaryMode; amount?: number; components?: any[] }) => {
      const payload = data.mode === 'earning_heads' 
        ? { mode: data.mode, components: data.components, compliance: complianceSettings, complianceValues: complianceValues }
        : { mode: data.mode, amount: data.amount, compliance: complianceSettings, complianceValues: complianceValues };
      
      const response = await apiRequestWithAuth('POST', `/api/salary-calculation/preview/${companyId}`, payload);
      return response.json();
    },
    onSuccess: (result) => {
      setPreviewData(result);
      setIsCalculating(false);
    },
    onError: (error: any) => {
      console.error('Calculation error:', error);
      toast({
        title: "Calculation Error",
        description: error.message || "Failed to calculate salary preview",
        variant: "destructive",
      });
      setIsCalculating(false);
    }
  });

  // Initialize form with existing data
  useEffect(() => {
    if (initialData) {
      setSelectedMode(initialData.entryType || 'gross');
      setGrossAmount(initialData.grossValue?.toString() || '');
      setCtcAmount(initialData.ctcValue?.toString() || '');
      
      // Load earning heads from initial data
      const heads: Record<string, string> = {};
      if (initialData.earningHead1) heads.basic = initialData.earningHead1.toString();
      if (initialData.earningHead2) heads.hra = initialData.earningHead2.toString();
      if (initialData.earningHead3) heads.conveyance = initialData.earningHead3.toString();
      if (initialData.earningHead4) heads.other = initialData.earningHead4.toString();
      setEarningHeads(heads);

      setComplianceSettings({
        epfEnabled: initialData.epfEnabled ?? true,
        esicEnabled: initialData.esicEnabled ?? true,
        lwfEnabled: initialData.lwfEnabled ?? true,
        otEnabled: initialData.otEnabled ?? false,
        vpfEnabled: initialData.vpfEnabled ?? false,
        tdsEnabled: initialData.tdsEnabled ?? false,
        ptEnabled: initialData.ptEnabled ?? false,
        bonusEnabled: initialData.bonusEnabled ?? true,
        pfLimit: initialData.pfLimit ?? false,
        pfLimitHigher: initialData.pfLimitHigher ?? false,
        bonusMonthly: initialData.bonusMonthly ?? false,
      });
      setComplianceValues({
        vpfPercentage: initialData.vpfPercentage?.toString() || '',
        tdsPercentage: initialData.tdsPercentage?.toString() || '',
        ptAmount: initialData.ptAmount?.toString() || '',
      });
    }
  }, [initialData]);

  // Trigger calculation when relevant data changes
  useEffect(() => {
    const triggerCalculation = () => {
      if (selectedMode === 'gross' && grossAmount && !isNaN(parseFloat(grossAmount))) {
        setIsCalculating(true);
        calculatePreviewMutation.mutate({ mode: 'gross', amount: parseFloat(grossAmount) });
      } else if (selectedMode === 'ctc' && ctcAmount && !isNaN(parseFloat(ctcAmount))) {
        setIsCalculating(true);
        calculatePreviewMutation.mutate({ mode: 'ctc', amount: parseFloat(ctcAmount) });
      } else if (selectedMode === 'earning_heads') {
        const components = Object.entries(earningHeads)
          .filter(([_, amount]) => amount && !isNaN(parseFloat(amount)))
          .map(([key, amount]) => ({ componentKey: key, amount: parseFloat(amount) }));
        
        if (components.length > 0) {
          setIsCalculating(true);
          calculatePreviewMutation.mutate({ mode: 'earning_heads', components });
        }
      }
    };

    const timeoutId = setTimeout(triggerCalculation, 500); // Debounce calculations
    return () => clearTimeout(timeoutId);
  }, [selectedMode, grossAmount, ctcAmount, earningHeads, complianceSettings, complianceValues]);

  const handleSave = async () => {
    if (!previewData) {
      toast({
        title: "Error",
        description: "Please calculate the salary structure first",
        variant: "destructive",
      });
      return;
    }

    const salaryData = {
      entryType: selectedMode,
      ctcValue: previewData.ctcValue.toString(),
      grossValue: previewData.grossValue.toString(),
      // Map components back to legacy format for now
      earningHead1: previewData.components.find(c => c.componentKey === 'basic')?.amount?.toString() || '0',
      earningHead2: previewData.components.find(c => c.componentKey === 'hra')?.amount?.toString() || '0',
      earningHead3: previewData.components.find(c => c.componentKey === 'conveyance')?.amount?.toString() || '0',
      earningHead4: previewData.components.find(c => c.componentKey === 'other')?.amount?.toString() || '0',
      epfEmployeeAmount: previewData.components.find(c => c.componentKey === 'epf_employee')?.amount?.toString() || '0',
      esicEmployeeAmount: previewData.components.find(c => c.componentKey === 'esic_employee')?.amount?.toString() || '0',
      lwfEmployeeAmount: previewData.components.find(c => c.componentKey === 'lwf_employee')?.amount?.toString() || '0',
      ...complianceSettings,
      // Include new compliance values
      vpfPercentage: complianceValues.vpfPercentage ? parseFloat(complianceValues.vpfPercentage) : null,
      tdsPercentage: complianceValues.tdsPercentage ? parseFloat(complianceValues.tdsPercentage) : null,
      ptAmount: complianceValues.ptAmount ? parseFloat(complianceValues.ptAmount) : null,
    };

    if (onSave) {
      onSave(salaryData);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      {/* Integrated Salary Entry Mode & Input */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calculator className="w-5 h-5" />
            Salary Structure Configuration
          </CardTitle>
          <CardDescription>
            Choose your entry method and configure the salary details
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            
            {/* Mode Selection - Visual Cards */}
            <div className="space-y-3">
              <h4 className="text-sm font-semibold text-foreground">Entry Mode</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Gross Mode Card */}
                <div 
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    selectedMode === 'gross' 
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedMode('gross')}
                  data-testid="mode-gross"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <div className={`w-4 h-4 rounded-full border-2 ${
                      selectedMode === 'gross' ? 'border-blue-500 bg-blue-500' : 'border-gray-300'
                    }`}>
                      {selectedMode === 'gross' && <div className="w-2 h-2 bg-white rounded-full m-0.5"></div>}
                    </div>
                    <span className="font-medium">Gross Mode</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    System calculates CTC and components from gross salary amount
                  </p>
                </div>

                {/* CTC Mode Card */}
                <div 
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    selectedMode === 'ctc' 
                      ? 'border-green-500 bg-green-50 dark:bg-green-950/20' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedMode('ctc')}
                  data-testid="mode-ctc"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <div className={`w-4 h-4 rounded-full border-2 ${
                      selectedMode === 'ctc' ? 'border-green-500 bg-green-500' : 'border-gray-300'
                    }`}>
                      {selectedMode === 'ctc' && <div className="w-2 h-2 bg-white rounded-full m-0.5"></div>}
                    </div>
                    <span className="font-medium">CTC Mode</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    System calculates gross and components from total CTC amount
                  </p>
                </div>

                {/* Earning Heads Mode Card */}
                <div 
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    selectedMode === 'earning_heads' 
                      ? 'border-purple-500 bg-purple-50 dark:bg-purple-950/20' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedMode('earning_heads')}
                  data-testid="mode-earning-heads"
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <div className={`w-4 h-4 rounded-full border-2 ${
                      selectedMode === 'earning_heads' ? 'border-purple-500 bg-purple-500' : 'border-gray-300'
                    }`}>
                      {selectedMode === 'earning_heads' && <div className="w-2 h-2 bg-white rounded-full m-0.5"></div>}
                    </div>
                    <span className="font-medium">Earning Heads</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Enter individual amounts, system calculates totals
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Input Fields based on Selected Mode */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold text-foreground">Salary Input</h4>
                <Badge variant="outline" className="text-xs">
                  {selectedMode === 'gross' && 'Gross Mode'}
                  {selectedMode === 'ctc' && 'CTC Mode'}
                  {selectedMode === 'earning_heads' && 'Earning Heads Mode'}
                </Badge>
              </div>

              {/* Gross Mode Input */}
              {selectedMode === 'gross' && (
                <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/20">
                  <div className="max-w-md space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <Label htmlFor="gross-amount" className="text-sm font-medium">Gross Salary Amount</Label>
                    </div>
                    <Input
                      id="gross-amount"
                      type="number"
                      value={grossAmount}
                      onChange={(e) => setGrossAmount(e.target.value)}
                      placeholder="Enter gross salary amount (e.g., 50000)"
                      data-testid="input-gross-amount"
                      className="text-lg font-semibold"
                    />
                    <p className="text-xs text-muted-foreground">
                      The system will automatically calculate CTC and deduction components based on this gross amount.
                    </p>
                  </div>
                </div>
              )}

              {/* CTC Mode Input */}
              {selectedMode === 'ctc' && (
                <div className="p-4 border rounded-lg bg-green-50 dark:bg-green-950/20">
                  <div className="max-w-md space-y-3">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <Label htmlFor="ctc-amount" className="text-sm font-medium">Cost to Company (CTC) Amount</Label>
                    </div>
                    <Input
                      id="ctc-amount"
                      type="number"
                      value={ctcAmount}
                      onChange={(e) => setCtcAmount(e.target.value)}
                      placeholder="Enter total CTC amount (e.g., 600000)"
                      data-testid="input-ctc-amount"
                      className="text-lg font-semibold"
                    />
                    <p className="text-xs text-muted-foreground">
                      The system will calculate gross salary and all components from this total CTC amount.
                    </p>
                  </div>
                </div>
              )}

              {/* Earning Heads Mode Input */}
              {selectedMode === 'earning_heads' && (
                <div className="p-4 border rounded-lg bg-purple-50 dark:bg-purple-950/20">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                      <Label className="text-sm font-medium">Individual Earning Components</Label>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="basic-salary" className="text-sm">Basic Salary *</Label>
                        <Input
                          id="basic-salary"
                          type="number"
                          value={earningHeads.basic || ''}
                          onChange={(e) => setEarningHeads(prev => ({ ...prev, basic: e.target.value }))}
                          placeholder="e.g., 25000"
                          data-testid="input-basic-salary"
                          className="font-medium"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="hra" className="text-sm">House Rent Allowance (HRA)</Label>
                        <Input
                          id="hra"
                          type="number"
                          value={earningHeads.hra || ''}
                          onChange={(e) => setEarningHeads(prev => ({ ...prev, hra: e.target.value }))}
                          placeholder="e.g., 12500"
                          data-testid="input-hra"
                          className="font-medium"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="conveyance" className="text-sm">Conveyance Allowance</Label>
                        <Input
                          id="conveyance"
                          type="number"
                          value={earningHeads.conveyance || ''}
                          onChange={(e) => setEarningHeads(prev => ({ ...prev, conveyance: e.target.value }))}
                          placeholder="e.g., 1600"
                          data-testid="input-conveyance"
                          className="font-medium"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="other" className="text-sm">Other Allowances</Label>
                        <Input
                          id="other"
                          type="number"
                          value={earningHeads.other || ''}
                          onChange={(e) => setEarningHeads(prev => ({ ...prev, other: e.target.value }))}
                          placeholder="e.g., 5000"
                          data-testid="input-other"
                          className="font-medium"
                        />
                      </div>
                    </div>
                    
                    {/* Quick Total Display */}
                    {(earningHeads.basic || earningHeads.hra || earningHeads.conveyance || earningHeads.other) && (
                      <div className="mt-4 p-3 bg-white dark:bg-gray-800 border rounded-lg">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">Gross Total (estimated):</span>
                          <span className="text-lg font-bold text-purple-600">
                            ₹{(
                              (parseFloat(earningHeads.basic) || 0) +
                              (parseFloat(earningHeads.hra) || 0) +
                              (parseFloat(earningHeads.conveyance) || 0) +
                              (parseFloat(earningHeads.other) || 0)
                            ).toLocaleString('en-IN')}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          * Final amounts may vary after applying compliance deductions
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Actions */}
            <div className="flex items-center justify-between pt-4 border-t">
              <div className="text-xs text-muted-foreground">
                {selectedMode === 'gross' && grossAmount && `Gross: ₹${parseFloat(grossAmount).toLocaleString('en-IN')}`}
                {selectedMode === 'ctc' && ctcAmount && `CTC: ₹${parseFloat(ctcAmount).toLocaleString('en-IN')}`}
                {selectedMode === 'earning_heads' && (earningHeads.basic || earningHeads.hra) && 'Multiple components entered'}
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setGrossAmount('');
                  setCtcAmount('');
                  setEarningHeads({});
                }}
                className="text-xs"
              >
                Clear All
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>


      {/* Compliance Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Compliance Settings</CardTitle>
          <CardDescription>Configure applicable compliance and deduction components</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 sm:grid-cols-1 lg:grid-cols-2">
            
            {/* Statutory Contributions */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-foreground border-b pb-2">Statutory Contributions</h4>
              
              {/* EPF Section */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Employee Provident Fund (EPF)</Label>
                    <Switch
                      checked={complianceSettings.epfEnabled}
                      onCheckedChange={(checked) => 
                        setComplianceSettings(prev => ({ ...prev, epfEnabled: checked }))
                      }
                      data-testid="switch-epfEnabled"
                    />
                  </div>
                  
                  {complianceSettings.epfEnabled && (
                    <div className="grid gap-3 sm:grid-cols-2 pl-4 border-l-2 border-blue-200">
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={complianceSettings.pfLimit}
                          onCheckedChange={(checked) => 
                            setComplianceSettings(prev => ({ ...prev, pfLimit: checked }))
                          }
                          data-testid="switch-pfLimit"
                        />
                        <Label className="text-xs">PF Limit</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={complianceSettings.pfLimitHigher}
                          onCheckedChange={(checked) => 
                            setComplianceSettings(prev => ({ ...prev, pfLimitHigher: checked }))
                          }
                          data-testid="switch-pfLimitHigher"
                        />
                        <Label className="text-xs">PF Limit Higher</Label>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* ESIC */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Employee State Insurance (ESIC)</Label>
                  <Switch
                    checked={complianceSettings.esicEnabled}
                    onCheckedChange={(checked) => 
                      setComplianceSettings(prev => ({ ...prev, esicEnabled: checked }))
                    }
                    data-testid="switch-esicEnabled"
                  />
                </div>
              </div>

              {/* LWF */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Labour Welfare Fund (LWF)</Label>
                  <Switch
                    checked={complianceSettings.lwfEnabled}
                    onCheckedChange={(checked) => 
                      setComplianceSettings(prev => ({ ...prev, lwfEnabled: checked }))
                    }
                    data-testid="switch-lwfEnabled"
                  />
                </div>
              </div>

              {/* OT */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Overtime (OT)</Label>
                  <Switch
                    checked={complianceSettings.otEnabled}
                    onCheckedChange={(checked) => 
                      setComplianceSettings(prev => ({ ...prev, otEnabled: checked }))
                    }
                    data-testid="switch-otEnabled"
                  />
                </div>
              </div>
            </div>

            {/* Additional Deductions & Benefits */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold text-foreground border-b pb-2">Additional Deductions & Benefits</h4>
              
              {/* VPF */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Voluntary Provident Fund (VPF)</Label>
                    <Switch
                      checked={complianceSettings.vpfEnabled}
                      onCheckedChange={(checked) => 
                        setComplianceSettings(prev => ({ ...prev, vpfEnabled: checked }))
                      }
                      data-testid="switch-vpfEnabled"
                    />
                  </div>
                  
                  {complianceSettings.vpfEnabled && (
                    <div className="pl-4 border-l-2 border-green-200">
                      <Label htmlFor="vpf-percentage" className="text-xs font-medium">VPF Percentage</Label>
                      <Input
                        id="vpf-percentage"
                        type="number"
                        value={complianceValues.vpfPercentage}
                        onChange={(e) => setComplianceValues(prev => ({ ...prev, vpfPercentage: e.target.value }))}
                        placeholder="Enter VPF %"
                        data-testid="input-vpf-percentage"
                        className="mt-1 text-sm"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* TDS */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Tax Deducted at Source (TDS)</Label>
                    <Switch
                      checked={complianceSettings.tdsEnabled}
                      onCheckedChange={(checked) => 
                        setComplianceSettings(prev => ({ ...prev, tdsEnabled: checked }))
                      }
                      data-testid="switch-tdsEnabled"
                    />
                  </div>
                  
                  {complianceSettings.tdsEnabled && (
                    <div className="pl-4 border-l-2 border-orange-200">
                      <Label htmlFor="tds-percentage" className="text-xs font-medium">TDS Percentage</Label>
                      <Input
                        id="tds-percentage"
                        type="number"
                        value={complianceValues.tdsPercentage}
                        onChange={(e) => setComplianceValues(prev => ({ ...prev, tdsPercentage: e.target.value }))}
                        placeholder="Enter TDS %"
                        data-testid="input-tds-percentage"
                        className="mt-1 text-sm"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* PT */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Professional Tax (PT)</Label>
                    <Switch
                      checked={complianceSettings.ptEnabled}
                      onCheckedChange={(checked) => 
                        setComplianceSettings(prev => ({ ...prev, ptEnabled: checked }))
                      }
                      data-testid="switch-ptEnabled"
                    />
                  </div>
                  
                  {complianceSettings.ptEnabled && (
                    <div className="pl-4 border-l-2 border-purple-200">
                      <Label htmlFor="pt-amount" className="text-xs font-medium">PT Amount</Label>
                      <Input
                        id="pt-amount"
                        type="number"
                        value={complianceValues.ptAmount}
                        onChange={(e) => setComplianceValues(prev => ({ ...prev, ptAmount: e.target.value }))}
                        placeholder="Enter PT amount"
                        data-testid="input-pt-amount"
                        className="mt-1 text-sm"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Bonus */}
              <div className="p-4 border rounded-lg bg-muted/20">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">Bonus</Label>
                    <Switch
                      checked={complianceSettings.bonusEnabled}
                      onCheckedChange={(checked) => 
                        setComplianceSettings(prev => ({ ...prev, bonusEnabled: checked }))
                      }
                      data-testid="switch-bonusEnabled"
                    />
                  </div>
                  
                  {complianceSettings.bonusEnabled && (
                    <div className="pl-4 border-l-2 border-yellow-200">
                      <div className="flex items-center space-x-2">
                        <Switch
                          checked={complianceSettings.bonusMonthly}
                          onCheckedChange={(checked) => 
                            setComplianceSettings(prev => ({ ...prev, bonusMonthly: checked }))
                          }
                          data-testid="switch-bonusMonthly"
                        />
                        <Label className="text-xs font-medium">Monthly Payment</Label>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Real-time Calculation Preview */}
      {(isCalculating || previewData) && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Salary Structure Preview
              {isCalculating && <Loader2 className="w-4 h-4 animate-spin" />}
            </CardTitle>
            <CardDescription>Real-time calculation based on your inputs</CardDescription>
          </CardHeader>
          <CardContent>
            {isCalculating ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin" />
                <span className="ml-2">Calculating salary structure...</span>
              </div>
            ) : previewData ? (
              <div className="space-y-6">
                {/* Summary */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg">
                    <p className="text-sm text-muted-foreground">Gross Salary</p>
                    <p className="text-xl font-bold" data-testid="preview-gross">
                      {formatCurrency(previewData.grossValue)}
                    </p>
                  </div>
                  <div className="p-4 bg-red-50 dark:bg-red-950/20 rounded-lg">
                    <p className="text-sm text-muted-foreground">Total Deductions</p>
                    <p className="text-xl font-bold" data-testid="preview-deductions">
                      {formatCurrency(previewData.deductions?.reduce((sum, d) => sum + d.amount, 0) || 0)}
                    </p>
                  </div>
                  <div className="p-4 bg-orange-50 dark:bg-orange-950/20 rounded-lg">
                    <p className="text-sm text-muted-foreground">Net Take Home</p>
                    <p className="text-xl font-bold" data-testid="preview-net-pay">
                      {formatCurrency(previewData.netPay || previewData.grossValue)}
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 dark:bg-green-950/20 rounded-lg">
                    <p className="text-sm text-muted-foreground">Cost to Company (CTC)</p>
                    <p className="text-xl font-bold" data-testid="preview-ctc">
                      {formatCurrency(previewData.ctcValue)}
                    </p>
                  </div>
                </div>

                <Separator />

                {/* Detailed Breakdown */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  {/* Employee Components */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-green-700 dark:text-green-300">
                      Employee Components (Earnings)
                    </h4>
                    <div className="space-y-2">
                      {previewData.components.map((component) => (
                        <div key={component.componentKey} 
                             className="flex justify-between items-center py-2 border-b"
                             data-testid={`component-${component.componentKey}`}>
                          <div>
                            <span className="text-sm">{component.displayName}</span>
                            {component.calculatedFromPercentage && (
                              <Badge variant="secondary" className="ml-2 text-xs">Auto</Badge>
                            )}
                          </div>
                          <span className="font-medium">{formatCurrency(component.amount)}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Employee Deductions */}
                  {previewData.deductions && previewData.deductions.length > 0 && (
                    <div className="space-y-4">
                      <h4 className="font-semibold text-red-700 dark:text-red-300">
                        Employee Deductions
                      </h4>
                      <div className="space-y-2">
                        {previewData.deductions.map((deduction) => (
                          <div key={deduction.componentKey} 
                               className="flex justify-between items-center py-2 border-b"
                               data-testid={`deduction-${deduction.componentKey}`}>
                            <div>
                              <span className="text-sm">{deduction.displayName}</span>
                              {deduction.calculatedFromPercentage && (
                                <Badge variant="secondary" className="ml-2 text-xs">Auto</Badge>
                              )}
                            </div>
                            <span className="font-medium text-red-600">-{formatCurrency(deduction.amount)}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Employer Costs */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-blue-700 dark:text-blue-300">
                      Employer Costs
                    </h4>
                    <div className="space-y-2">
                      {previewData.employerCosts.map((cost) => (
                        <div key={cost.componentKey} 
                             className="flex justify-between items-center py-2 border-b"
                             data-testid={`employer-cost-${cost.componentKey}`}>
                          <div>
                            <span className="text-sm">{cost.displayName}</span>
                            {cost.calculatedFromPercentage && (
                              <Badge variant="secondary" className="ml-2 text-xs">Auto</Badge>
                            )}
                          </div>
                          <span className="font-medium">{formatCurrency(cost.amount)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}

      {/* Save Button */}
      <div className="flex justify-end">
        <Button 
          onClick={handleSave} 
          disabled={!previewData || isCalculating}
          className="flex items-center gap-2"
          data-testid="button-save-salary"
        >
          <Save className="w-4 h-4" />
          Save Salary Structure
        </Button>
      </div>
    </div>
  );
}