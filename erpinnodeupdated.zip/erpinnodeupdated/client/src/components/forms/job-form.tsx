import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { insertJobSchema, type InsertJob, type Job, type Department } from "@shared/schema";
import { authService, apiRequestWithAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

// Form schema that matches the form inputs but transforms to database format
const jobFormSchema = z.object({
  companyId: z.number(),
  title: z.string().min(1, "Job title is required"),
  description: z.string().min(1, "Job description is required"),
  departmentId: z.string().optional().transform(val => 
    val && val !== '' ? parseInt(val) : null
  ),
  requirements: z.string().optional(),
  salaryMin: z.string().optional(),
  salaryMax: z.string().optional(),
  location: z.string().optional(),
  employmentType: z.string().default('full-time'),
  status: z.string().default('draft'),
  postedAt: z.string().optional(),
  closingDate: z.string().optional(),
});

type JobFormData = z.infer<typeof jobFormSchema>;

interface JobFormProps {
  job?: Job | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function JobForm({ job, onSuccess, onCancel }: JobFormProps) {
  const { toast } = useToast();
  const user = authService.getUser();
  const companyId = user?.companyId!;

  // Fetch departments for dropdown
  const { data: departments = [] } = useQuery<Department[]>({
    queryKey: [`/api/departments/${companyId}`],
    queryFn: async () => {
      const response = await apiRequestWithAuth('GET', `/api/departments/${companyId}`);
      return response.json();
    },
  });

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<JobFormData>({
    resolver: zodResolver(jobFormSchema),
    defaultValues: job ? {
      ...job,
      departmentId: job.departmentId?.toString() || '',
      salaryMin: job.salaryMin || '',
      salaryMax: job.salaryMax || '',
      postedAt: job.postedAt ? new Date(job.postedAt).toISOString().split('T')[0] : '',
      closingDate: job.closingDate ? new Date(job.closingDate).toISOString().split('T')[0] : '',
    } : {
      companyId,
      title: '',
      description: '',
      requirements: '',
      salaryMin: '',
      salaryMax: '',
      location: '',
      employmentType: 'full-time',
      status: 'draft',
      departmentId: '',
      postedAt: '',
      closingDate: '',
    },
  });

  const createJobMutation = useMutation({
    mutationFn: async (data: JobFormData) => {
      console.log('Form data:', data);
      console.log('User:', user);
      console.log('Token:', authService.getToken());
      
      const processedData = {
        companyId: data.companyId,
        title: data.title,
        description: data.description,
        departmentId: data.departmentId || null,
        requirements: data.requirements || null,
        salaryMin: data.salaryMin && data.salaryMin.trim() !== '' ? data.salaryMin : null,
        salaryMax: data.salaryMax && data.salaryMax.trim() !== '' ? data.salaryMax : null,
        location: data.location || null,
        employmentType: data.employmentType || 'full-time',
        status: data.status || 'draft',
        postedAt: data.postedAt ? new Date(data.postedAt) : null,
        closingDate: data.closingDate ? new Date(data.closingDate) : null,
        postedBy: user?.id,
      };
      
      console.log('Processed data:', processedData);
      
      const response = await apiRequestWithAuth('POST', '/api/jobs', processedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Job posted successfully",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateJobMutation = useMutation({
    mutationFn: async (data: JobFormData) => {
      const processedData = {
        companyId: data.companyId,
        title: data.title,
        description: data.description,
        departmentId: data.departmentId || null,
        requirements: data.requirements || null,
        salaryMin: data.salaryMin && data.salaryMin.trim() !== '' ? data.salaryMin : null,
        salaryMax: data.salaryMax && data.salaryMax.trim() !== '' ? data.salaryMax : null,
        location: data.location || null,
        employmentType: data.employmentType || 'full-time',
        status: data.status || 'draft',
        postedAt: data.postedAt ? new Date(data.postedAt) : null,
        closingDate: data.closingDate ? new Date(data.closingDate) : null,
        postedBy: user?.id,
      };
      
      const response = await apiRequestWithAuth('PUT', `/api/jobs/${job!.id}`, processedData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Job updated successfully",
      });
      onSuccess();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: JobFormData) => {
    if (job) {
      updateJobMutation.mutate(data);
    } else {
      createJobMutation.mutate(data);
    }
  };

  const isPending = createJobMutation.isPending || updateJobMutation.isPending;

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="title">Job Title *</Label>
          <Input
            id="title"
            {...register("title")}
            placeholder="Senior Software Engineer"
            disabled={isPending}
          />
          {errors.title && (
            <p className="text-sm text-hr-accent">{errors.title.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="departmentId">Department</Label>
          <Select
            value={watch("departmentId")?.toString() || ""}
            onValueChange={(value) => setValue("departmentId", value ? parseInt(value) : undefined)}
            disabled={isPending}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select department" />
            </SelectTrigger>
            <SelectContent>
              {departments.map((dept) => (
                <SelectItem key={dept.id} value={dept.id.toString()}>
                  {dept.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            {...register("location")}
            placeholder="New York, NY"
            disabled={isPending}
          />
          {errors.location && (
            <p className="text-sm text-hr-accent">{errors.location.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="employmentType">Employment Type</Label>
          <Select
            value={watch("employmentType") || "full-time"}
            onValueChange={(value) => setValue("employmentType", value)}
            disabled={isPending}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="full-time">Full-time</SelectItem>
              <SelectItem value="part-time">Part-time</SelectItem>
              <SelectItem value="contract">Contract</SelectItem>
              <SelectItem value="temporary">Temporary</SelectItem>
              <SelectItem value="internship">Internship</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="salaryMin">Minimum Salary</Label>
          <Input
            id="salaryMin"
            type="number"
            {...register("salaryMin")}
            placeholder="50000"
            disabled={isPending}
          />
          {errors.salaryMin && (
            <p className="text-sm text-hr-accent">{errors.salaryMin.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="salaryMax">Maximum Salary</Label>
          <Input
            id="salaryMax"
            type="number"
            {...register("salaryMax")}
            placeholder="80000"
            disabled={isPending}
          />
          {errors.salaryMax && (
            <p className="text-sm text-hr-accent">{errors.salaryMax.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="postedAt">Posted Date</Label>
          <Input
            id="postedAt"
            type="date"
            {...register("postedAt")}
            disabled={isPending}
          />
          {errors.postedAt && (
            <p className="text-sm text-hr-accent">{errors.postedAt.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="closingDate">Closing Date</Label>
          <Input
            id="closingDate"
            type="date"
            {...register("closingDate")}
            disabled={isPending}
          />
          {errors.closingDate && (
            <p className="text-sm text-hr-accent">{errors.closingDate.message}</p>
          )}
        </div>

        <div className="space-y-2 md:col-span-2">
          <Label htmlFor="status">Status</Label>
          <Select
            value={watch("status") || "draft"}
            onValueChange={(value) => setValue("status", value as any)}
            disabled={isPending}
          >
            <SelectTrigger className="md:w-1/2">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="description">Job Description *</Label>
          <Textarea
            id="description"
            {...register("description")}
            placeholder="Provide a detailed description of the role, responsibilities, and what makes this position exciting..."
            rows={6}
            disabled={isPending}
          />
          {errors.description && (
            <p className="text-sm text-hr-accent">{errors.description.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="requirements">Requirements</Label>
          <Textarea
            id="requirements"
            {...register("requirements")}
            placeholder="List the required qualifications, skills, experience, and education for this position..."
            rows={4}
            disabled={isPending}
          />
          {errors.requirements && (
            <p className="text-sm text-hr-accent">{errors.requirements.message}</p>
          )}
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onCancel} disabled={isPending}>
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={isPending}
          className="bg-hr-primary hover:bg-hr-primary/90"
        >
          {isPending
            ? job
              ? "Updating..."
              : "Creating..."
            : job
            ? "Update Job"
            : "Post Job"
          }
        </Button>
      </div>
    </form>
  );
}
